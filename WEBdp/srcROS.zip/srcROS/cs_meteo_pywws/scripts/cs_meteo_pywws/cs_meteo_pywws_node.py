#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""pywws weather station support for COEX charging station"""

from threading import Lock

# ROS modules
import rospy

from pywws.weatherstation import WeatherStation

from cs_meteo_msgs.msg import Rain, Wind, WindDirection

from sensor_msgs.msg import FluidPressure, Temperature, RelativeHumidity

from std_msgs.msg import Header

# Main function
if __name__ == '__main__':
    # Initialize the node, name it, set log verbosity level
    rospy.init_node('meteo_pywws', log_level=rospy.INFO)
    rospy.logdebug('Node initialized')

    node_topic_prefix = rospy.get_param('~prefix', default='')

    if not isinstance(node_topic_prefix, str):
        raise EnvironmentError('Node topic prefix parameter value has to be a string!')

    rospy.logdebug('Node topic prefix: %s', node_topic_prefix)

    refresh_time = rospy.get_param('~refresh_time', 48)

    if not isinstance(refresh_time, int):
        raise EnvironmentError('Refresh time parameter value has to be an integer!')

    rospy.logdebug('Refresh time: %s', refresh_time)

    if refresh_time < 1:
        raise EnvironmentError('Refresh time can\'t be less than 1 s!')

    rain_interval = rospy.get_param('~rain_interval', 60 * 60)

    if not isinstance(rain_interval, int):
        raise EnvironmentError('Rain interval parameter value has to be an integer!')

    rospy.logdebug('Rain interval: %s', rain_interval)

    if rain_interval < 60:
        raise EnvironmentError('Rain interval can\'t be less than 60 s!')

    baro_publisher = rospy.Publisher('{0}/barometer'.format(node_topic_prefix),
                                     FluidPressure, queue_size=10)
    rospy.logdebug('Publisher for a barometer topic ready: %s', baro_publisher)

    temp_in_publisher = rospy.Publisher('{0}/temp_in'.format(node_topic_prefix),
                                        Temperature, queue_size=10)
    rospy.logdebug('Publisher for an internal temperature topic ready: %s', temp_in_publisher)

    temp_out_publisher = rospy.Publisher('{0}/temp_out'.format(node_topic_prefix),
                                         Temperature, queue_size=10)
    rospy.logdebug('Publisher for an external temperature topic ready: %s', temp_out_publisher)

    humidity_in_publisher = rospy.Publisher('{0}/humidity_in'.format(node_topic_prefix),
                                            RelativeHumidity, queue_size=10)
    rospy.logdebug('Publisher for an internal humidity topic ready: %s', humidity_in_publisher)

    humidity_out_publisher = rospy.Publisher('{0}/humidity_out'.format(node_topic_prefix),
                                             RelativeHumidity, queue_size=10)
    rospy.logdebug('Publisher for an external humidity topic ready: %s', humidity_out_publisher)

    rain_publisher = rospy.Publisher('{0}/rain'.format(node_topic_prefix), Rain, queue_size=10)
    rospy.logdebug('Publisher for an rain sensor topic ready: %s', rain_publisher)

    wind_publisher = rospy.Publisher('{0}/wind'.format(node_topic_prefix), Wind, queue_size=10)
    rospy.logdebug('Publisher for a wind sensor topic ready: %s', wind_publisher)

    wind_dir_publisher = rospy.Publisher('{0}/wind_direction'.format(node_topic_prefix), WindDirection,
                                         queue_size=10)
    rospy.logdebug('Publisher for a wind sensor topic ready: %s', wind_dir_publisher)

    rate = rospy.Rate(1.0 / refresh_time)  # Regular station refresh rate

    station = WeatherStation()  # Connect to weather station

    rain_interval_sum = 0  # Rain sum for the measurement interval
    rain_interval_sum_lock = Lock()  # Rain interval sum lock

    def rain_interval_reset_callback(event):
        """
        Rain interval sum reset callback
        :return: None
        """
        global rain_interval_sum

        with rain_interval_sum_lock:
            rain_interval_sum = 0

    # Create a rain interval reset timer
    rain_interval_reset_timer = rospy.Timer(rospy.Duration(rain_interval), rain_interval_reset_callback)

    # We need to keep the previous value to calculate the current rain level (station returns the total)
    rain_previous = None

    while not rospy.is_shutdown():
        # Retrieve the newest data
        data = station.get_data(station.current_pos(), unbuffered=True)
        rospy.logdebug("Weather station data: %s", data)

        baro_msg = FluidPressure()
        baro_msg.header = Header()
        baro_msg.header.stamp = rospy.Time.now()

        baro_msg.fluid_pressure = data['abs_pressure'] * 100 if data['abs_pressure'] is not None else float('nan')
        baro_msg.variance = 0

        baro_publisher.publish(baro_msg)

        temp_in_msg = Temperature()
        temp_in_msg.header = Header()
        temp_in_msg.header.stamp = rospy.Time.now()

        temp_in_msg.temperature = data['temp_in'] if data['temp_in'] is not None else float('nan')
        temp_in_msg.variance = 0

        temp_in_publisher.publish(temp_in_msg)

        humidity_in_msg = RelativeHumidity()
        humidity_in_msg.header = Header()
        humidity_in_msg.header.stamp = rospy.Time.now()

        humidity_in_msg.relative_humidity = data['hum_in'] / 100.0 if data['hum_in'] is not None else float('nan')
        humidity_in_msg.variance = 0

        humidity_in_publisher.publish(humidity_in_msg)

        temp_out_msg = Temperature()
        temp_out_msg.header = Header()
        temp_out_msg.header.stamp = rospy.Time.now()

        temp_out_msg.temperature = data['temp_out'] if data['temp_out'] is not None else float('nan')
        temp_out_msg.variance = 0

        temp_out_publisher.publish(temp_out_msg)

        humidity_out_msg = RelativeHumidity()
        humidity_out_msg.header = Header()
        humidity_out_msg.header.stamp = rospy.Time.now()

        humidity_out_msg.relative_humidity = data['hum_out'] / 100.0 \
            if data['hum_out'] is not None else float('nan')
        humidity_out_msg.variance = 0

        humidity_out_publisher.publish(humidity_out_msg)

        rain_msg = Rain()
        rain_msg.header = Header()
        rain_msg.header.stamp = rospy.Time.now()

        if data['rain'] is not None:
            # It's not the first rain measurement and there is no rain sensor reset
            if (rain_previous is not None) and (rain_previous <= data['rain']):
                rain_msg.rain_overflow = data['status']['rain_overflow']

                with rain_interval_sum_lock:
                    # Sum with the previous values
                    rain_interval_sum += data['rain'] - rain_previous

                    rain_msg.rain = rain_interval_sum

                rain_msg.variance = 0

                rain_publisher.publish(rain_msg)

            rain_previous = data['rain']  # Update the previous rain value
        else:
            rain_previous = None  # Reset the previous rain value

            rain_msg.rain_overflow = False
            rain_msg.rain_overflow = float('nan')
            rain_msg.variance = 0

            rain_publisher.publish(rain_msg)

        wind_msg = Wind()
        wind_msg.header = Header()
        wind_msg.header.stamp = rospy.Time.now()

        wind_msg.average = data['wind_ave'] if data['wind_ave'] is not None else float('nan')
        wind_msg.average_variance = 0
        wind_msg.gust = data['wind_gust'] if data['wind_gust'] is not None else float('nan')
        wind_msg.gust_variance = 0

        wind_publisher.publish(wind_msg)

        wind_dir_msg = WindDirection()
        wind_dir_msg.header = Header()
        wind_dir_msg.header.stamp = rospy.Time.now()

        wind_dir_msg.direction = data['wind_dir'] * 22.5 \
            if (data['wind_dir'] is not None and data['wind_dir'] < 16) else float('nan')
        wind_dir_msg.variance = 0

        wind_dir_publisher.publish(wind_dir_msg)

        rate.sleep()  # Wait for the weather station data update
