#ifndef CS_GPIO_ACTUATOR_NODE
#define CS_GPIO_ACTUATOR_NODE

#include <unordered_set>

#include <ros/ros.h>

#include <cs_driver_msgs/DriverState.h>

// Base GPIO actuator node exception class
class gpioActuatorNodeException: public std::runtime_error
{
public:
  gpioActuatorNodeException(const std::string& what_arg);
};

// Invalid node configuration
class gpioActuatorInvalidConfiguration: public gpioActuatorNodeException
{
public:
  gpioActuatorInvalidConfiguration(const std::string& what_arg);
};

// pigpio library initialisation failed
class gpioActuatorPigpioFailed: public gpioActuatorNodeException
{
public:
  gpioActuatorPigpioFailed(const std::string& what_arg);
};

// GPIO pin setup failed
class gpioActuatorPinSetupFailed: public gpioActuatorNodeException
{
public:
  gpioActuatorPinSetupFailed(const std::string& what_arg);
};

// GPIO write failed
class gpioActuatorPinWriteFailed: public gpioActuatorNodeException
{
public:
  gpioActuatorPinWriteFailed(const std::string& what_arg);
};

// Service is not availible
class gpioActuatorServiceNotAvalible: public gpioActuatorNodeException
{
public:
  gpioActuatorServiceNotAvalible(const std::string& what_arg);
};

// ROS message driver state type
using driverNodeState = decltype(cs_driver_msgs::DriverState::state);

class gpioActuatorNode
{
  private:
    ros::NodeHandle &nh;  // Current instance handle

    int pigpiodHandle;  // pigpiod handle
    
    int actuatorPin;  // Actiator GPIO pin
    bool signalInversed;  // Output signal is inversed

    std::unordered_set<driverNodeState> activeStates;  // States set when actuator is active

    ros::Subscriber driverStateSub;  // Driver state topic subscription

    /* Driver state callback
    * msg - a new driver state message.
    */
    void driverStateCallback(const cs_driver_msgs::DriverState::ConstPtr& msg);

    /* Apply new actuator state
    * state - a new state.
    */
    void actuatorApplyState(const driverNodeState state);
  public:
    /* GPIO actuator node constructor
    * nh - ROS node handle.
    */
    gpioActuatorNode(ros::NodeHandle &nh);

    ~gpioActuatorNode();
};

#endif  // CS_GPIO_ACTUATOR_NODE
