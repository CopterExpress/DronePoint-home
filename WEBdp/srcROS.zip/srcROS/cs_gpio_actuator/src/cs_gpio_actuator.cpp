#include <exception>
#include <functional>
#include <unordered_map>

#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/classification.hpp>

#include <cs_driver_msgs/DriverState.h>

#include <pigpiod_if2.h>

#include "cs_gpio_actuator.h"

gpioActuatorNodeException::gpioActuatorNodeException(const std::string& what_arg)
: std::runtime_error(what_arg)
{
}

gpioActuatorInvalidConfiguration::gpioActuatorInvalidConfiguration(const std::string& what_arg)
: gpioActuatorNodeException(what_arg)
{
}

gpioActuatorPigpioFailed::gpioActuatorPigpioFailed(const std::string& what_arg)
: gpioActuatorNodeException(what_arg)
{
}

gpioActuatorPinSetupFailed::gpioActuatorPinSetupFailed(const std::string& what_arg)
: gpioActuatorNodeException(what_arg)
{
}

gpioActuatorPinWriteFailed::gpioActuatorPinWriteFailed(const std::string& what_arg)
: gpioActuatorNodeException(what_arg)
{
}

gpioActuatorServiceNotAvalible::gpioActuatorServiceNotAvalible(const std::string& what_arg)
: gpioActuatorNodeException(what_arg)
{
}

// Constant bindings for the charging station states
static const std::unordered_map<std::string, const driverNodeState> chargingStationStatesMap =
{
  {"UNKNOWN", cs_driver_msgs::DriverState::UNKNOWN},
  {"OPEN", cs_driver_msgs::DriverState::OPEN},
  {"OPENING", cs_driver_msgs::DriverState::OPENING},
  {"CLOSED", cs_driver_msgs::DriverState::CLOSED},
  {"CLOSING", cs_driver_msgs::DriverState::CLOSING},
  {"ERROR", cs_driver_msgs::DriverState::ERROR}
};

gpioActuatorNode::gpioActuatorNode(ros::NodeHandle &nh)
: nh(nh)  // Copy a reference to a ROS node handle
{
  bool debug;

  nh.param("debug", debug, false);

  // Set a log verbosity level
  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
      (debug) ? ros::console::levels::Debug : ros::console::levels::Info))
    ros::console::notifyLoggerLevelsChanged();

  if (debug)
    ROS_DEBUG("Debug mode enabled");

  std::string pigpiodIP;

  nh.param("pigpiod_ip", pigpiodIP, std::string("localhost"));
  ROS_DEBUG("pigpiod IP: \"%s\"", pigpiodIP.c_str());

  int pigpiodPort;

  nh.param("pigpiod_port", pigpiodPort, 8888);
  ROS_DEBUG("pigpiod port: %i", pigpiodPort);

  if (pigpiodPort <= 0)
    throw gpioActuatorInvalidConfiguration("pigpiod port can't be less or equal to 0!");

  // HINT: pigpiod expects port number as a C string
  std::string pigpiodPortStr(std::to_string(pigpiodPort));

  // Connect to the pigpiod server
  // HINT: Function expects string as a char *, const_cast is needed
  this->pigpiodHandle = pigpio_start(const_cast<char *>(pigpiodIP.c_str()),
    const_cast<char *>(pigpiodPortStr.c_str()));
  
  if (this->pigpiodHandle < 0)
    throw gpioActuatorPigpioFailed("pigpiod connection has failed");

  if (!nh.getParam("pin", this->actuatorPin))
    throw gpioActuatorInvalidConfiguration("No actuator pin number presented!");

  ROS_DEBUG("Actuator pin: %i", this->actuatorPin);

  if (this->actuatorPin < 0)
    throw gpioActuatorInvalidConfiguration("Actuator pin number can't be less than 0!");

  // Set an actuator pin as an OUTPUT
  if (set_mode(this->pigpiodHandle, this->actuatorPin, PI_OUTPUT))
    throw gpioActuatorPinSetupFailed("Failed to set pin mode");

  std::string activeStatesStr;  // Active states option value

  nh.param("active_states", activeStatesStr, std::string(""));

  // Convert string to the upper case
  std::transform(activeStatesStr.begin(), activeStatesStr.end(), activeStatesStr.begin(), ::toupper);

  // Remove all spaces
  activeStatesStr.erase(std::remove(activeStatesStr.begin(), activeStatesStr.end(), ' '), activeStatesStr.end());

  // An active states as a string vector
  std::vector<std::string> activeStatesVect;

  // Spit active states by commas
  boost::split(activeStatesVect, activeStatesStr, boost::is_any_of(","));

  for (const auto &state : activeStatesVect)
  {
    // Look for the active state binding
    auto stateIter = chargingStationStatesMap.find(state);

    // A binding doesn't exists
    if (stateIter == chargingStationStatesMap.end())
      throw gpioActuatorInvalidConfiguration("Unknown active state: \"" + state +'"');

    ROS_DEBUG("Found new active state: \"%s\"", state.c_str());

    if (activeStates.count(stateIter->second))
      throw gpioActuatorInvalidConfiguration("Duplicate active state: \"" + state +'"');

    activeStates.insert(stateIter->second);
  }

  nh.param("inversed_signal", this->signalInversed, false);
  ROS_DEBUG("Signal is %sinversed", this->signalInversed ? "" : "not ");

  // Initial GPIO pin write before the driver node is ready
  this->actuatorApplyState(cs_driver_msgs::DriverState::UNKNOWN);

  std::string driverNodePrefix;  // Driver node option value

  nh.param("driver_node_prefix", driverNodePrefix, std::string(""));
  ROS_DEBUG("Driver node prefix: %s", driverNodePrefix.c_str());

  // Create a subscriber for the driver state updates
  driverStateSub = this->nh.subscribe(driverNodePrefix + "/state", 1000, &gpioActuatorNode::driverStateCallback, this);
}

void gpioActuatorNode::actuatorApplyState(const driverNodeState state)
{
  // Check the state is in the active states set
  const bool signalLevel = this->activeStates.find(state) != this->activeStates.cend();

  ROS_INFO("GPIO pin state update: %s", signalLevel ? "on" : "off");

  // Write the GPIO pin state depending on the inversed signal flag
  if (gpio_write(this->pigpiodHandle, this->actuatorPin,
      (!this->signalInversed && signalLevel) || (this->signalInversed && !signalLevel)))
    throw gpioActuatorPinWriteFailed("Can't set actuator GPIO!");
}

void gpioActuatorNode::driverStateCallback(const cs_driver_msgs::DriverState::ConstPtr& msg)
{
  // Update the GPIO pin state
  this->actuatorApplyState(msg->state);
}

gpioActuatorNode::~gpioActuatorNode()
{
  try
  {
    // Reset an actuator pin
    set_mode(this->pigpiodHandle, this->actuatorPin, PI_INPUT);

    // Disconnect from the pigpiod service
    // HINT: pigpio_stop will return if pigpiod handle is invalid
    pigpio_stop(this->pigpiodHandle);
  }
  // Prevent exception to be thrown out of the destructor
  catch (...)
  {
  }
}
