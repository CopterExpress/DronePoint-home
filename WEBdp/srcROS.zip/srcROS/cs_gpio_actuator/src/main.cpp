#include <ros/ros.h>
#include <ros/console.h>

#include "cs_gpio_actuator.h"

int main(int argc, char **argv)
{
  // Set up ROS
  ros::init(argc, argv, "cs_gpio_actuator");

  ros::NodeHandle privateNodeHandle("~");

  ROS_DEBUG("Node handle has been received");

  gpioActuatorNode node(privateNodeHandle);

  ROS_DEBUG("Node has been initialized");

  // Let ROS handle all callbacks
  ros::spin();

  ROS_INFO("Node stop");

  return 0;
}
