from distutils.core import setup
from catkin_pkg.python_setup import generate_distutils_setup

d = generate_distutils_setup(
    packages=['cs_driver_software'],
    package_dir={'': 'scripts'}
)

setup(**d)
