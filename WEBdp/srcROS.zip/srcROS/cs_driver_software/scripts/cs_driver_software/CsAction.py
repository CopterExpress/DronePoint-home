#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""COEX software charging station driver toolkit"""

import threading
from enum import Enum, unique

import rospy


class CsAction(object):
    """
    Describes an immutable platform-independent chragin station action.
    """

    def __init__(self, do_action, timeout, goal_check):
        """
        :param do_action: a callable object that implements the action (callable)
            Warning: Asynchronous call! Implement thread safety!
        :param timeout: a maximum timeout (s) for the action to complete (int or float or None)
            HINT: Use 0 timeout to perform action without a goal check.
            HINT: Use None to disable maximum action timeout and wait for the goal forever.
        :param goal_check: a callable object that implements the action goal check
            (callable->bool or None (only if timeout == 0))
            Warning: Asynchronous call! Implement thread safety!
        """
        # Type checks
        if not callable(do_action):
            raise TypeError('do_action has to be callable!')

        if not isinstance(timeout, (int, float, type(None))):
            raise TypeError('timeout has to be int or float!')

        if not callable(goal_check):
            if timeout == 0:
                if goal_check is not None:
                    raise TypeError('goal_check has to be callable or None (if timeout is 0)!')
        else:
            if not isinstance(goal_check(), bool):
                raise TypeError('goal_check has to return bool!')
        #

        self.__do_action = do_action
        self.__timeout = timeout
        self.__goal_check = goal_check

    def do_action(self):
        """
        Starts the action using user specified callable object.
        :return: None
        """
        self.__do_action()

    @property
    def timeout(self):
        """
        Returns the user specified maximum timeout (s) for the action to complete.
        :return: User specified maximum timeout (s) for the action to complete (int, float,
            None)
        """
        return self.__timeout

    def goal_check(self):
        """
        Checks the action goal has been reached using user specified callable object.
        :return: The action goal has been reached (bool)
        """
        if self.__goal_check is not None:
            return self.__goal_check()
        else:
            return None


@unique
class CsActionSequenceExecutorState(Enum):
    """
    Describes charging station action sequence executor state.
    """
    IDLE = 0  # An executor was created but not started
    # An executor is running a sequence
    # HINT: It's better to use is_alive() method!
    RUNNING = 1
    STOPPED = 2  # An executor was stopped by request
    FAILED = 3  # An executor has detected an error during the sequence execution
    COMPLETED = 4  # An executor has finished the sequence


class CsActionSequenceExecutor(threading.Thread):
    """
    Describes a software charging station action sequence executor.
    WARNING: Works in the separate thread!
    """

    def __init__(self, action_sequence, stop_actor, completed_callback=None,
                 failed_callback=None, stopped_callback=None):
        """
        :param action_sequence: A sequence of actions to execute (tuple(CsAction))
        :param stop_actor: A callable to stop an actor immediately (callable)
        :param completed_callback: A callback to call in case of successful sequence execution
            (None or callable(CsActionSequenceExecutor))
        :param failed_callback: A callback to call in case of sequence execution error
            (None or callable(CsActionSequenceExecutor))
        :param stopped_callback: A callback to call in case of sequence executor stop
            (None or callable(CsActionSequenceExecutor))
        """
        super(CsActionSequenceExecutor, self).__init__()
        rospy.logdebug('[%s] Parent init completed', self)

        # Type checks
        if not len(action_sequence):
            raise ValueError('Action sequence can\'t be empty!')

        if not isinstance(action_sequence, tuple):
            raise TypeError('Action sequence has to a tuple!')

        for action in action_sequence:
            if not isinstance(action, CsAction):
                raise TypeError('Every action has to be an instance of CsAction!')

        if not callable(stop_actor):
            raise TypeError('stop_actor has to be callable!')

        if not isinstance(completed_callback, type(None)):
            if not callable(completed_callback):
                raise TypeError('completed_callback has to be None or callable!')

        if not isinstance(failed_callback, type(None)):
            if not callable(failed_callback):
                raise TypeError('failed_callback has to be None or callable!')

        if not isinstance(stopped_callback, type(None)):
            if not callable(stopped_callback):
                raise TypeError('stopped_callback has to be None or callable!')

        #

        self.__action_sequence = action_sequence
        self.__stop_actor = stop_actor

        self.__finished_callback = completed_callback
        self.__failed_callback = failed_callback
        self.__stopped_callback = stopped_callback

        # This event block the main thread loop until the new events appear
        self.__event_update_event = threading.Event()
        rospy.logdebug('[%s] New events event was created: %s', self, self.__event_update_event)

        # Action timeout timer (will be created on the action processing)
        self.__timeout_timer = None

        self.__timeout_event = threading.Event()  # Action timeout event
        rospy.logdebug('[%s] Timeout event was created: %s', self, self.__timeout_event)

        self.__goal_check_event = threading.Event()  # Goal check event
        rospy.logdebug('[%s] Timeout event was created: %s', self, self.__goal_check_event)

        self.__state = CsActionSequenceExecutorState.IDLE  # Sequence executor initial state

        self.__sequence_stop_event = threading.Event()  # Public event to request execution stop
        rospy.logdebug('[%s] External stop execution event was created: %s', self,
                       self.__sequence_stop_event)

        self.__state_lock = threading.Lock()  # A lock for the executor's state access
        rospy.logdebug('[%s] State threading lock was created: %s',self, self.__state_lock)

        rospy.logdebug('[%s] Init ready', self)

    def stop_executor(self):
        """
        Request a sequence execution termination.
        HINT: Use join to wait for the execution termination.
        :return: None
        """
        self.__sequence_stop_event.set()  # Set the stop request event
        rospy.logdebug('[%s] Stop request was set: %s', self, self.__sequence_stop_event)

        self.__event_update_event.set()  # Notify a thread about the new event

    @property
    def state(self):
        """
        Return current executor state in a thread-safe manner.
        :return: Current executor state (CsActionSequenceExecutorState)
        """
        with self.__state_lock:  # Synchronisation
            result = self.__state

        return result

    def __update_state(self, state):
        """
        Update the executor state in a thread-safe manner.
        :param state: New executor state (CsActionSequenceExecutorState)
        :return: None
        """
        if not isinstance(state, CsActionSequenceExecutorState):
            raise TypeError('state has to be an instance of CsActionSequenceExecutorState')

        with self.__state_lock:  # Synchronisation
            self.__state = state

        rospy.logdebug('[%s] New executor state: %s', self, state)

    def goal_check_notify(self):
        """
        Notify action executor about the goal-dependent changes.
        WARNING: Call it after the actual goal-dependent changes!
        :return: None
        """
        self.__goal_check_event.set()  # Set a goal check event

        self.__event_update_event.set()  # Notify a thread about the new event

    def __timeout(self, event):
        """
        Timeout timer was fired.
        :param timer: A timer event (rospy.TimerEvent)
        :return: None
        """
        rospy.logdebug('[%s] Timeout timer fired!', self)

        self.__timeout_event.set()  # Set a timeout timer event
        rospy.logdebug('[%s] Timeout event was set: %s', self, self.__timeout_event)

        self.__event_update_event.set()  # Notify a thread about the new event

    @property
    def action_sequence(self):
        """
        Return the action sequence an action executor is processing.
        :return: A sequence of actions the action executor is processing (tuple(CsAction))
        """

        return self.__action_sequence

    def run(self):
        """
        Charging station action sequence executor thread.
        :return: None
        """
        rospy.logdebug('[%s] Executor thread started', self)
        # Now the executor is running the sequence
        self.__update_state(CsActionSequenceExecutorState.RUNNING)

        for action in self.__action_sequence:  # For every action in the sequence
            rospy.logdebug('[%s] Executing an action: %s', self, action)

            # Check if we really need this action. It could be already completed.
            if action.goal_check():
                rospy.logdebug('[%s] No need to execute. Goal has been already reached.', self)
                continue  # Go to the next action

            action.do_action()  # Requesting an actor to start the action
            rospy.logdebug('[%s] Command executed: %s', self, action.do_action)

            self.__timeout_timer = None  # Timeout disabled

            # User requested to disable maximum timeout (will wait until the goal)
            if action.timeout is None:
                rospy.logdebug('[%s] No maximum timeout for this action.', self)
            elif action.timeout == 0:  # User requested to check the goal immediately
                rospy.logdebug('[%s] Action with no goal check.', self)
                continue  # Get the next action
            else:  # Maximum timeout enabled
                # Create a oneshot timer to set a timeout event and notify a thread
                self.__timeout_timer = rospy.Timer(
                    rospy.Duration(action.timeout),  # Maximum action timeout
                    self.__timeout,  # Callback
                    oneshot=True  # Oneshot timer
                )
                rospy.logdebug('[%s] Timeout timer created: %s', self, self.__timeout_timer)

            while True:  # Do while loop
                self.__event_update_event.wait()  # Wait for new events

                if self.__sequence_stop_event.is_set():  # External sequence stop request
                    # If maximum timeout was set for this action
                    if self.__timeout_timer is not None:
                        # Stop the timer
                        self.__timeout_timer.shutdown()
                        rospy.logdebug('[%s] Timeout timer shutdown: %s', self,
                                       self.__timeout_timer)

                    self.__stop_actor()  # Stop the actor immediately

                    # Updating the status
                    self.__update_state(CsActionSequenceExecutorState.STOPPED)

                    # If a stop callback is set
                    if self.__stopped_callback is not None:
                        self.__stopped_callback(self)  # Call a stop callback

                    rospy.logdebug('[%s] Executor\'s thread was successfully stopped', self)

                    return  # Stop the thread

                if self.__goal_check_event.is_set():  # Action goal event has happened
                    self.__goal_check_event.clear()  # Reset the event

                    if action.goal_check():  # The goal has been reached
                        # If maximum timeout was set for this action
                        if self.__timeout_timer is not None:
                            # Stop the timer
                            self.__timeout_timer.shutdown()
                            rospy.logdebug('[%s] Timeout timer shutdown: %s', self,
                                           self.__timeout_timer)

                        rospy.logdebug('[%s] Action has been completed.', self)

                        break  # Stop the event wait loop and get the next action

                if self.__timeout_event.is_set():  # Maximum timeout event has happened
                    self.__stop_actor()  # Stop the actor immediately

                    # Updating the state
                    self.__update_state(CsActionSequenceExecutorState.FAILED)

                    # If a timeout callback is set
                    if self.__failed_callback is not None:
                        self.__failed_callback(self)  # Call a timeout callback

                    rospy.logerr('[%s] Operation timeout', self)

                    return  # Stop the thread

        # Updating the status
        self.__update_state(CsActionSequenceExecutorState.COMPLETED)

        # If a finished callback is set
        if self.__finished_callback is not None:
            self.__finished_callback(self)  # Call a finished callback

        rospy.logdebug('[%s] Actor has executed the sequence successfully', self)
