#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""COEX Ground Charging Station node with MAVLink protocol support"""

import os
import json
from collections import OrderedDict
import threading

from enum import Enum, IntEnum, unique
import struct
import math

# ROS modules
import rospy
import rospkg

# pymavlink module (>= 2.2.9)
from pymavlink import mavutil

# This node uses geopy for the antenna offset correction
import geopy
import geopy.distance

from cs_driver_srvs.srv import DriverCommand, DriverCommandRequest, DriverCommandResponse
from cs_gps_srvs.srv import GetSurveyInParameters
from cs_gps_srvs.srv import SetSurveyInParameters
from cs_gps_srvs.srv import ResetSurveyInParameters

from std_msgs.msg import Float32
from std_srvs.srv import Trigger

from cs_driver_msgs.msg import DriverState
from cs_gps_msgs.msg import Rtcm, VehicleGpsPosition, SatelliteInformation, SurveyIn
from cs_meteo_msgs.msg import Wind, WindDirection, Rain

from sensor_msgs.msg import BatteryState, Temperature, FluidPressure, RelativeHumidity

# Package name of the current node
# FIXME: Find a way to determine current node package correctly.
# HINT: The best way on this moment is to declare package name as a constant.
PACKAGE_NAME = 'cs_mavlink'

# Maximal size of MAVLink RTCM data without fragmentation
MAVLINK_RTCM_DATA_LEN_MAX = 180

# Maximal MAVLink degree value
MAVLINK_DEGREE_MAX = 359.99

# uint8 border
UINT8_MAX = 2 ** 8

# int8 borders
INT8_MAX = 2 ** (8 - 1) - 1
INT8_MIN = -2 ** (8 - 1)

# int32 borders
INT32_MAX = 2 ** (32 - 1) - 1
INT32_MIN = -2 ** (32 - 1)

# uint16 border
UINT16_MAX = 2 ** 16

# int16 border
INT16_MAX = 2 ** (16 - 1) - 1


# Value reinterpretation helpers for MAVLink vehicle parameters
# FIXME: It's quite an ugly solution, but I didn't find another way to do it with pymavlink.
def uint8_to_float(value):
    """
    Reinterpret uint8 as float.
    :param value: A value to reinterpret (int) (0 .. 255).
    :return: Reinterpreted value (float).
    """
    # Type check
    if not isinstance(value, int):
        raise TypeError('value has to be an integer')

    if (value < 0) or (value > UINT8_MAX):
        raise TypeError('value has to be in range [0, {0}]'.format(UINT8_MAX))
    #

    return struct.unpack('<f', struct.pack('B', value) + '\x00' * 3)[0]


def float_to_uint8(value):
    """
    Reinterpret float as uint8.
    :param value: A value to reinterpret (float).
    :return: Reinterpreted value (int) (0 .. 255).
    """
    # Type check
    if not isinstance(value, float):
        raise TypeError('value has to be a float')

    return struct.unpack('B', struct.pack('<f', value)[0])[0]


def int8_to_float(value):
    """
    Reinterpret int8 as float.
    :param value: A value to reinterpret (int) (-128 .. 126).
    :return: Reinterpreted value (float).
    """
    # Type check
    if not isinstance(value, int):
        raise TypeError('value has to be an integer')

    if (value < INT8_MIN) or (value > INT8_MAX):
        raise TypeError('value has to be in range [{0}, {1}]'.format(INT8_MIN, INT8_MAX))
    #

    return struct.unpack('<f', struct.pack('b', value) + '\x00' * 3)[0]


def float_to_int8(value):
    """
    Reinterpret float as int8.
    :param value: A value to reinterpret (float).
    :return: Reinterpreted value (int) (-128 .. 126).
    """
    # Type check
    if not isinstance(value, float):
        raise TypeError('value has to be a float')

    return struct.unpack('b', struct.pack('<f', value)[0])[0]


def uint16_to_float(value):
    """
    Reinterpret uint16 as float.
    :param value: A value to reinterpret (int) (0 .. 65536).
    :return: Reinterpreted value (float).
    """
    # Type check
    if not isinstance(value, int):
        raise TypeError('value has to be an integer')

    if (value < 0) or (value > UINT16_MAX):
        raise TypeError('value has to be in range [0, {0}]'.format(UINT16_MAX))
    #

    return struct.unpack('<f', struct.pack('H', value) + '\x00' * 2)[0]


def float_to_uint16(value):
    """
    Reinterpret float as uint16.
    :param value: A value to reinterpret (float).
    :return: Reinterpreted value (int) (0 .. 65536).
    """
    # Type check
    if not isinstance(value, float):
        raise TypeError('value has to be a float')

    return struct.unpack('H', struct.pack('<f', value)[0:2])[0]


def int32_to_float(value):
    """
    Reinterpret int32 as float.
    :param value: A value to reinterpret (int) (INT32_MIN .. INT32_MAX).
    :return: Reinterpreted value (float).
    """
    # Type check
    if not isinstance(value, int):
        raise TypeError('value has to be an integer')

    if (value < INT32_MIN) or (value > INT32_MAX):
        raise TypeError('value has to be in range [{0}, {1}]'.format(INT32_MIN, INT32_MAX))
    #

    return struct.unpack('<f', struct.pack('i', value))[0]


def float_to_int32(value):
    """
    Reinterpret float as int32.
    :param value: A value to reinterpret (float).
    :return: Reinterpreted value (int) (INT32_MIN .. INT32_MAX).
    """
    # Type check
    if not isinstance(value, float):
        raise TypeError('value has to be a float')

    return struct.unpack('i', struct.pack('<f', value))[0]


#


CONFIG_DIRECTORY = 'config'  # Configuration file directory inside a ROS package

# Absolute configuration file path (will be calculated during initialisation)
# HINT: Stores MAVLink vehicle parameters
config_file_path = None

JSON_INDENT = 2  # JSON indent to improve output configuration file readability


class ConfigurationKey(object):
    """
    Namespace for configuration keys.
    """
    # Configuration key for the station MAVLink system ID
    SYSTEM_ID = 'system_id'
    # Configuration key for the station fixed coordinates
    COORDINATES = 'coordinates'
    # Configuration key for the station latitude
    COORDINATES_LATITUDE = 'latitude'
    # Configuration key for the station longitude
    COORDINATES_LONGITUDE = 'longitude'
    # Configuration key for the station altitude
    COORDINATES_ALTITUDE = 'altitude'
    # Configuration key for the station heading
    HEADING = 'heading'
    # Configuration key for the station GPS antenna offset
    GPS_ANTENNA_OFFSET = 'gps_antenna_offset'
    # Configuration key for X offset
    DX = 'dx'
    # Configuration key for Y offset
    DY = 'dy'
    # Configuration key for Z (altitude) offset
    DZ = 'dz'


# MAVLink URL (will be created during the vehicle initialisation)
mavlink_url = None

MAVLINK20_ENV = 'MAVLINK20'  # MAVLink v2.0 environment variable name

# Charging station MAVLink system ID (will be loaded from the configuration file)
mavlink_system_id = None

MAVLINK_SYSTEM_ID_BROADCAST = 0  # MAVLink broadcast ID

# Main charging station component ID (will be extracted from the MAVLink instance constants)
mavlink_component_id = None

MAVLINK_SYSTEM_ID_DEFAULT = 17  # Default charging station MAVLink system ID

mavlink_file = None  # Will be created during the vehicle initialisation

# MAVLink object instance (will be extracted from a pymavlink connection)
mavlink_instance = None

telemetry_timer = None  # Telemetry timer (will be created during the vehicle initialisation)

# Synchronises multiple thread access to a MAVLink instance
# WARNING: Use in all threads!
mavlink_lock = threading.Lock()

# Other system detection flag
# HINT: We need this flag to print the other system presence detection message only once
other_system_presence_flag = False

reboot_flag = False  # Vehicle virtual reboot request flag

# Vehicle start ROS timestamp (will be set during the vehicle initialisation call)
vehicle_start_time = None

# Default charging station coordinates (latitude, longitude, altitude)
# HINT: For the debug purposes default coordinates are set near the gazebo UAV default position
STATION_COORDINATES_DEFAULT = 47.397618, 8.54551, 150.0

# Charging station MAVLink coordinates (will be calculated during node initialisation process)
# HINT: Coordinates has to be recalculation before using with MAVLink
mavlink_station_coordinates = None

# Default charging station heading (needed for the correct GPS antenna offset calculation)
#   (degrees)
STATION_HEADING_DEFAULT = 0.0

# Station heading copy for telemetry (will be set during the node initialisation)
mavlink_station_heading = None

# Station attitude yaw copy for telemetry (will be set during the node initialisation)
mavlink_station_attitude_yaw = None

# Current compass heading (will be set during on the first topic update)
compass_heading = 0

# Lock for both MAVLink station coordinates, MAVLink station heading, compass heading
vehicle_position_lock = threading.Lock()

# Default charging station GPS antenna offset (meters)
GPS_ANTENNA_OFFSET_DEFAULT = 0.0, 0.0, 0.0

# Command service for the hardware driver (will be created during the node initialisation)
driver_command_service = None

# ROS node topic prefix (will be initialised during the node initialisation)
node_topic_prefix = None

# GPS/RTCM node set survey-in parameters service (will be created during the node initialisation,
# if GPS/RTCM node is set)
set_svin_params_service = None

# GPS/RTCM node reset survey-in parameters service (will be created during the node
# initialisation, if GPS/RTCM node is set)
reset_svin_params_service = None

# GPS/RTCM node survey in restart service (will be created during the node
# initialisation, if GPS/RTCM node is set)
gps_rtk_restart_service = None

# GPS driver node prefix (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
gps_node_prefix = None

# RTK node prefix (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
rtk_node_prefix = None

# Compass heading topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
compass_heading_topic = None

# Event informs threads (like RTCM message subscriber thread) that MAVLink instance is ready
#   to send outgoing messages
# HINT: Check in all threads (except the main thread) after acquiring the MAVLink send lock
mavlink_ready = threading.Event()

# UAV battery state ROS message
battery_state = None
battery_state_lock = threading.Lock()

# UAV battery state topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
battery_state_topic = None

# Wind ROS message
wind_data = None
# Wind direction ROS message
wind_direction = None
# Lock for both wind data and wind direction (to send in one MAVLink message)
wind_cov_lock = threading.Lock()

# Wind topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
wind_topic = None
# Wind direction topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
wind_direction_topic = None

# External temperature ROS message
external_temperature_data = None
# Barometer ROS message
barometer_data = None
# Lock for both external temperature data and barometer (to send in one MAVLink message)
scaled_pressure_lock = threading.Lock()

# External temperature topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
external_temperature_topic = None
# Barometer topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
barometer_topic = None

# Rain data ROS message
rain_data = None
rain_data_lock = threading.Lock()

# Rain topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
rain_topic = None

# External humidity ROS message
external_humidity_data = None
external_humidity_data_lock = threading.Lock()

# External humidity topic (will be set during the node initialisation)
# HINT: Set to '' if it's not presented
external_humidity_topic = None

# Survey in active flag
survey_in_active = False
survey_in_active_lock = threading.Lock()


@unique
class VehicleCustomMode(IntEnum):
    """
    Describes charging station MAVLink custom mode.
    HINT: This type mainly duplicates CsMavlinkDriverState. The main goal - to separate
    HINT:   a state instance from the custom mode instance.
    """

    # Charging station mode is unknown
    UNKNOWN = 0
    # Charging station is open
    OPEN = 1
    # Charging station is opening
    OPENING = 2
    # Charging station is closed
    CLOSED = 3
    # Charging station is closing
    CLOSING = 4
    # Loading payload to drone is in process
    LOADING_DRONE=5
    # Unloading payload from drone to dronepoint is in process
    UNLOADING_DRONE=6
    # Getting payload from user
    GETTING_FROM_USER=7
    # Unloading payload to user
    UNLOADING_TO_USER=8
    # Get an empty battery from drone ant replace it with a fresh one
    CHANGING_BATTERY=9
    # Any other non-meta command to dronepoint
    SERVICE=10
    # Reset from error state
    RESTORE=11
    # Dronepoint standby mode
    STANDBY=12
    # Charging station driver error
    ERROR=13
    # Charging station driver error
    STOP=14

    @staticmethod
    def state_to_custom_mode(state):
        """
        Converts a charging station state to the charging station custom mode.
        :param state: A charging station state (int)
        :return: A charging station custom mode (VehicleCustomMode)
        """

        # Type check
        if not isinstance(state, int):
            raise TypeError('state has to be an integer')

        try:
            # Translate with a dictionary
            return {
                # Simple state to custom mode translation
                DriverState.UNKNOWN: VehicleCustomMode.UNKNOWN,
                DriverState.OPEN: VehicleCustomMode.OPEN,
                DriverState.OPENING: VehicleCustomMode.OPENING,
                DriverState.CLOSED: VehicleCustomMode.CLOSED,
                DriverState.CLOSING: VehicleCustomMode.CLOSING,
                DriverState.LOADING_DRONE: VehicleCustomMode.LOADING_DRONE,
                DriverState.UNLOADING_DRONE: VehicleCustomMode.UNLOADING_DRONE,
                DriverState.GETTING_FROM_USER: VehicleCustomMode.GETTING_FROM_USER,
                DriverState.UNLOADING_TO_USER: VehicleCustomMode.UNLOADING_TO_USER,
                DriverState.CHANGING_BATTERY: VehicleCustomMode.CHANGING_BATTERY,
                DriverState.SERVICE: VehicleCustomMode.SERVICE,
                DriverState.STANDBY: VehicleCustomMode.STANDBY,
                # There is no mode for the error state, translate it to unknown mode
                # HINT: To correctly detect a charging station error mode use system status
                DriverState.ERROR: VehicleCustomMode.ERROR
            }[state]
        except KeyError as e:  # Charging station state is not found in the dictionary
            raise ValueError(
                'Can\'t translate "{0}" to the charging station custom mode'.format(e.args[0])
            )

    def to_driver_command(self):
        """
        Converts a custom mode to the hardware driver node command.
        :return: The hardware driver node command (DriverCommandRequest)
        """
        try:
            # Translate with a dictionary
            return {
                # Simple custom mode to the hardware driver command translation
                VehicleCustomMode.OPEN: DriverCommandRequest.OPEN,
                VehicleCustomMode.OPENING: DriverCommandRequest.OPEN,
                VehicleCustomMode.CLOSED: DriverCommandRequest.CLOSE,
                VehicleCustomMode.CLOSING: DriverCommandRequest.CLOSE,
                VehicleCustomMode.LOADING_DRONE: DriverCommandRequest.LOAD_DRONE,
                VehicleCustomMode.UNLOADING_DRONE: DriverCommandRequest.UNLOAD_DRONE,
                VehicleCustomMode.GETTING_FROM_USER: DriverCommandRequest.GET_FROM_USER,
                VehicleCustomMode.UNLOADING_TO_USER: DriverCommandRequest.UNLOAD_TO_USER,
                VehicleCustomMode.CHANGING_BATTERY: DriverCommandRequest.CHANGE_BATTERY,
                VehicleCustomMode.SERVICE: DriverCommandRequest.SERVICE,
                VehicleCustomMode.STANDBY: DriverCommandRequest.STANDBY,
                VehicleCustomMode.ERROR: DriverCommandRequest.ERROR,
                VehicleCustomMode.RESTORE: DriverCommandRequest.RESTORE,
                VehicleCustomMode.STOP: DriverCommandRequest.STOP,
            }[self]
        except KeyError as e:  # There is no command binding for the custom mode
            raise ValueError(
                'Can\'t translate "{0}" to the driver command'.format(e.args[0])
            )


# CS driver state (unknown at this moment) (int)
# WARNING: It's an integer!
cs_driver_state = DriverState.UNKNOWN

# Charging station custom mode
# HINT: To omit state to the custom mode conversion on the every heartbeat we keep it here.
# HINT: There is no need in the separate lock for cs_custom_mode. cs_driver_state
# HINT:     and cs_custom_mode often goes in pairs.
cs_custom_mode = VehicleCustomMode.UNKNOWN

# WARNING: Lock for multiple thread access for BOTH cs_driver_state and cs_custom_mode!
# HINT: Synchronisation between the main thread and the ROS topic subscriber's thread.
cs_state_mode_lock = threading.Lock()

# Major parameters version
# HINT: For the correct meta data detection in QGroundControl
PARAM_VERSION_STATIC = 1


class VehicleParameter(object):
    """
    Namespace for the vehicle parameters (parameter ID).
    """
    PARAM_VERSION = 'SYS_PARAM_VER'  # Major parameters version
    SYSTEM_ID = 'MAV_SYS_ID'  # MAVLink system ID
    LATITUDE = 'POS_LATITUDE'  # Charging station latitude
    LONGITUDE = 'POS_LONGITUDE'  # Charging station longitude
    ALTITUDE = 'POS_ALTITUDE'  # Charging station altitude
    HEADING = 'POS_HEADING'  # Charging station heading
    CONTROL = 'CONTROL'  # Charging station manual control parameter
    GPS_ANTENNA_DX = 'ANTENNA_DX'  # Charging station GPS antenna offset by X
    GPS_ANTENNA_DY = 'ANTENNA_DY'  # Charging station GPS antenna offset by Y
    GPS_ANTENNA_DZ = 'ANTENNA_DZ'  # Charging station GPS antenna offset by Z (altitude)
    SURVEY_IN_ACCURACY = 'SVIN_ACCURACY'  # GPS/RTCM node survey-in accuracy
    SURVEY_IN_DURATION = 'SVIN_DURATION'  # GPS/RTCM node survey-in duration


# Control parameter static value
# HINT: It never changes in QGC. Here you can select it's value.
CONTROL_PARAMETER_STATIC = 0


class ControlParameterCommand(IntEnum):
    """
    Control parameter available commands.
    """
    RESTORE = -1  # Restore station from the error state
    OPEN = 1  # Open charging station
    CLOSE = 2  # Close charging station
    STOP = 3  # Stop current charging station action

    def to_driver_command(self):
        """
        Converts a control parameter command to the hardware driver node command.
        :return: The hardware driver node command (DriverCommandRequest)
        """
        try:
            # Translate with a dictionary
            return {
                # Simple control parameter command to the hardware driver command translation
                ControlParameterCommand.RESTORE: DriverCommandRequest.RESTORE,
                ControlParameterCommand.OPEN: DriverCommandRequest.OPEN,
                ControlParameterCommand.CLOSE: DriverCommandRequest.CLOSE,
                ControlParameterCommand.STOP: DriverCommandRequest.STOP
            }[self]
        except KeyError as e:  # There is no command binding for the control parameter command
            raise ValueError(
                'Can\'t translate "{0}" to the driver command'.format(e.args[0])
            )


# A parameter ID -> value ordered dict
# HINT: We have to keep strict parameters order in MAVLink
VEHICLE_PARAMETERS = OrderedDict([
    # Always constant (int32)
    (VehicleParameter.PARAM_VERSION, PARAM_VERSION_STATIC),
    # Will be loaded from config or defaults (uint8)
    (VehicleParameter.SYSTEM_ID, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.LATITUDE, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.LONGITUDE, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.ALTITUDE, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.HEADING, None),
    # Always constant (int8)
    (VehicleParameter.CONTROL, CONTROL_PARAMETER_STATIC),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.GPS_ANTENNA_DX, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.GPS_ANTENNA_DY, None),
    # Will be loaded from config or defaults (float)
    (VehicleParameter.GPS_ANTENNA_DZ, None),
    # Will be loaded from the GPS/RTCM node (if presented) (float)
    (VehicleParameter.SURVEY_IN_ACCURACY, 0.0),
    # Will be loaded from the GPS/RTCM node (if presented) (int)
    (VehicleParameter.SURVEY_IN_DURATION, 0)
])

# Lock for all station parameters modification
# HINT: All parameters are updated in the main thread! No need to use read lock inside the
# HINT:     main thread!
vehicle_parameters_lock = threading.Lock()


def mavlink_time_from_boot_ms():
    """
    Calculate MAVLink time from boot.
    WARNING: To be called with acquired MAVLink instance send lock!
    :return: MAVLink time from boot (ms) (int)
    """
    global vehicle_start_time

    # Calculate the time interval from the vehicle boot (ms)
    time_from_boot_ms = int(round((rospy.Time.now() - vehicle_start_time).to_sec() * 1000))

    # WARNING: pymavlink messages are actually a software landmines. The application will
    # WARNING:  be terminated in about 49 days without this branch because timestamps
    # WARNING:  are limited with 32 bits.
    # HINT: uint32 time_from_boot_ms will overflow before uin64 time_from_boot_us
    if time_from_boot_ms >> 32:  # Check if our vehicle epoch doesnt't fit into uint32
        vehicle_start_time = rospy.Time.now()  # Reset vehicle epoch

        return 0  # Start a new vehicle epoch

    return time_from_boot_ms


def mavlink_coordinates(latitude, longitude, altitude):
    """
    Calculate MAVLink coordinates from the standard coordinates.
    :param latitude: Latitude coordinate (int, float)
    :param longitude: Longitude coordinate (int, float)
    :param altitude: Altitude coordinate (int, float)
    :return: MAVLink coordinates (tuple(int, int, int))
    """
    return round(latitude * 1e7), round(longitude * 1e7), round(altitude * 1000)


def standard_coordinates(latitude, longitude, altitude):
    """
    Calculate standard coordinates from the MAVLink coordinates.
    :param latitude: Latitude coordinate (int)
    :param longitude: Longitude coordinate (int)
    :param altitude: Altitude coordinate (int)
    :return: Standard coordinates (tuple(float, float, float))
    """
    if not isinstance(latitude, int):
        raise TypeError('latitude has to be an integer')

    if not isinstance(altitude, int):
        raise TypeError('longitude has to be an integer')

    if not isinstance(longitude, int):
        raise TypeError('altitude has to be an integer')

    return latitude * 1e-7, longitude * 1e-7, altitude / 1000.0


def correct_charging_station_position(position, antenna_offset, heading):
    """
    Correct charging station global position by antenna offset.
    :param position: Global charging station position
        (iterable of (int or float, int or float, int or float))
    :param antenna_offset: Metric antenna offset
        (iterable of (int or float, int or float, int or float))
    :param heading: Charging station heading (int or float).
    :return: Corrected charging station position (tuple of (float, float, float))
    """

    # Type checks
    try:
        iter(position)
    except TypeError:
        raise TypeError('position has to be iterable')

    if len(position) != 3:
        raise TypeError('position length has to be equal 3')

    for item in position:
        if not isinstance(item, (int, float)):
            raise TypeError('position elements has to be integers or floats')

    try:
        iter(antenna_offset)
    except TypeError:
        raise TypeError('antenna_offset has to be iterable')

    if len(antenna_offset) != 3:
        raise TypeError('antenna_offset length has to be equal 3')

    for item in antenna_offset:
        if not isinstance(item, (int, float)):
            raise TypeError('antenna_offset elements has to be integers or floats')

    if not isinstance(heading, (int, float)):
        raise TypeError('heading has to be integer or float')

    if heading > 180:
        raise ValueError('Heading can\'t be greater than 180')

    if heading < -180:
        raise ValueError('Heading can\'t be less than -180')

    # Charging station offset is the reverse antenna offset (FRD)
    station_offset = list()
    station_offset.append(-antenna_offset[0])
    station_offset.append(-antenna_offset[1])
    station_offset.append(antenna_offset[2])

    # Distance is a vector's module
    distance = math.sqrt(station_offset[0] ** 2 + station_offset[1] ** 2)
    # rospy.logdebug('distance = %s', distance)

    # Moving direction from the north is a vector angle
    relative_direction = math.degrees(math.atan2(*station_offset[0:2]))
    # rospy.logdebug('relative direction = %s', relative_direction)

    # We should add object heading to calculate the actual moving direction
    absolute_direction = heading + relative_direction
    # rospy.logdebug('absolute direction = %s', absolute_direction)

    # Normalize the absolute direction
    if absolute_direction > 180:
        absolute_direction -= 360
    elif absolute_direction < -180:
        absolute_direction += 360
    # rospy.logdebug('normalised absolute direction = %s', absolute_direction)

    # Create a geopy vehicle point from the vehicle position
    vehicle_point = geopy.Point(position[:2])
    # rospy.logdebug('geopy point = %s', vehicle_point)

    # Create a geopy distance object
    distance = geopy.distance.VincentyDistance(meters=distance)
    # rospy.logdebug('geopy distance = %s', distance)

    # Move the original vehicle point using geopy
    new_point = distance.destination(point=vehicle_point, bearing=absolute_direction)

    # Create a new vehicle position from the geopy point
    new_position = list(new_point)

    # Add an altitude offset
    new_position[2] = position[2] + station_offset[2]

    # Check if the new altitude fits the int32 borders
    new_position[2] = min(new_position[2], INT32_MAX)
    new_position[2] = max(new_position[2], INT32_MIN)
    # rospy.logdebug('Corrected altitude = %s', new_position[2])

    # Return the result as a tuple
    return tuple(new_position)


def update_mavlink_coordinates():
    """
    Apply the antenna offset (if presented), calculate MAVLink coordinates from standard
    coordinates and save them for the telemetry calls.
    WARNING: To be called only from the main thread!
    :return: None
    """
    global mavlink_station_coordinates

    # Synchronise with the heartbeat timer thread
    with vehicle_position_lock:
        # If the antenna offset is set we have to calculate a global position correction
        if VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] or \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY] or \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]:
            rospy.logdebug('Original coordinates: %s, %s, %s',
                           VEHICLE_PARAMETERS[VehicleParameter.LATITUDE],
                           VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE],
                           VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE]
                           )

            # Apply the offset
            new_coordinates = correct_charging_station_position(
                (VEHICLE_PARAMETERS[VehicleParameter.LATITUDE],
                 VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE],
                 VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE]),
                (VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX],
                 VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY],
                 VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]),
                VEHICLE_PARAMETERS[VehicleParameter.HEADING] if not compass_heading_topic
                else compass_heading
            )
            rospy.logdebug('Corrected coordinates: %s, %s, %s', *new_coordinates)
        else:  # No antenna offset is set
            # Path the coordinates as they are
            new_coordinates = VEHICLE_PARAMETERS[VehicleParameter.LATITUDE], \
                              VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE], \
                              VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE]

        # Convert to MAVLink coordinates and unpack
        mavlink_station_coordinates = mavlink_coordinates(*new_coordinates)

    rospy.logdebug('MAVLink coordinates update: %s', mavlink_station_coordinates)


def mavlink_heading(heading):
    """
    Calculate MAVLink heading from the degrees.
    :param heading: Vehicle heading (int, float)
    :return: MAVLink heading (int)
    """
    # Integrity checks
    if not isinstance(heading, (int, float)):
        raise TypeError('Heading has to be an instance of an integer or a float')

    if heading > 180:
        raise ValueError('Heading can\'t be greater than 180')

    if heading < -180:
        raise ValueError('Heading can\'t be less than -180')
    #

    # MAVLink doesn't accept negative heading
    heading = heading if heading >= 0 else 360 + heading

    # It also doesn't accept 360 degrees heading
    if heading > MAVLINK_DEGREE_MAX:
        heading = 0  # Actually, it's really close to the full circle (0 degrees)

    # To get a MAVLink heading we have to multiply degrees by 100 and round the fraction
    return round(heading * 100)


def mavlink_attitude_yaw(heading):
    """
    Calculate MAVLink attitude yaw from the degrees.
    :param heading: Vehicle heading (int, float)
    :return: MAVLink attitude yaw (float)
    """
    # Integrity checks
    if not isinstance(heading, (int, float)):
        raise TypeError('Heading has to be an instance of an integer or a float')

    if heading > 180:
        raise ValueError('Heading can\'t be greater than 180')

    if heading < -180:
        raise ValueError('Heading can\'t be less than -180')
    #

    # MAVLink doesn't accept negative heading
    heading = heading if heading >= 0 else 360 + heading

    # To get a MAVLink attitude yaw we have to convert degrees to radians
    return math.radians(heading)


def update_mavlink_heading():
    """
    Calculate MAVLink heading from the degrees, save it for the telemetry calls.
    WARNING: To be called only from the main thread!
    :return: None
    """
    global mavlink_station_heading
    global mavlink_station_attitude_yaw

    with vehicle_position_lock:  # Synchronise with the heartbeat timer thread
        # Calculate MAVLink heading
        mavlink_station_heading = mavlink_heading(VEHICLE_PARAMETERS[VehicleParameter.HEADING])
        # Calculate MAVLink attitude yaw
        mavlink_station_attitude_yaw = mavlink_attitude_yaw(VEHICLE_PARAMETERS[VehicleParameter.HEADING])

    rospy.logdebug('MAVLink vehicle heading update: %s', mavlink_station_heading)
    rospy.logdebug('MAVLink vehicle attitude yaw update: %s', mavlink_station_attitude_yaw)


def send_telemetry_static(time_from_boot_ms):
    """
    Send telemetry updates with static GPS coordinates.
    WARNING: To be called with acquired MAVLink instance send lock!
    :param time_from_boot_ms: MAVLink time from boot (ms) (int)
    :return: None
    """
    global vehicle_start_time

    with vehicle_position_lock:  # Synchronise with the main thread
        mavlink_instance.gps_raw_int_send(
            rospy.Time.now().to_nsec() / 1000,  # Time since the unix epoch
            # GPS type
            mavlink.GPS_FIX_TYPE_STATIC,
            mavlink_station_coordinates[0],  # Latitude, expressed as degrees * 1E7
            mavlink_station_coordinates[1],  # Longitude, expressed as degrees * 1E7
            mavlink_station_coordinates[2],  # Altitude (AMSL, NOT WGS84), in meters * 1000
            # GPS HDOP horizontal dilution of position
            0xFFFF,  # Unknown
            # GPS VDOP vertical dilution of position
            0xFFFF,  # Unknown
            # GPS ground speed (m/s * 100)
            0xFFFF,  # Unknown
            # Course over ground in degrees * 100, 0.0..359.99 degrees
            0xFFFF,  # Unknown
            # Number of satellites visible
            0xFF,  # Unknown
            0,  # Altitude (above WGS84, EGM96 ellipsoid), in meters * 1000
            0,  # Position uncertainty in meters * 1000
            0,  # Altitude uncertainty in meters * 1000
            0,  # Speed uncertainty in meters * 1000
            0  # Heading / track uncertainty in degrees * 1e5
        )

        mavlink_instance.global_position_int_send(
            time_from_boot_ms,  # Time since vehicle boot
            mavlink_station_coordinates[0],  # Latitude, expressed as degrees * 1E7
            mavlink_station_coordinates[1],  # Longitude, expressed as degrees * 1E7
            mavlink_station_coordinates[2],  # Altitude in meters, expressed as * 1000 (millimeters)
            0,  # Altitude above ground in meters, expressed as * 1000 (millimeters)
            0,  # Ground X Speed (Latitude, positive north), expressed as m/s * 100
            0,  # Ground Y Speed (Longitude, positive east), expressed as m/s * 100
            0,  # Ground Z Speed (Altitude, positive up), expressed as m/s * 100
            # Vehicle heading (yaw angle) in degrees * 100, 0.0..359.99 degrees
            mavlink_station_heading if not compass_heading_topic
            else mavlink_heading(compass_heading)
        )

        mavlink_instance.attitude_send(
            time_from_boot_ms,  # Time since vehicle boot
            0,  # Roll angle (-pi..+pi) [rad]
            0,  # Pitch angle (-pi..+pi) [rad] (type:float)
            mavlink_station_attitude_yaw if not compass_heading_topic
            else mavlink_attitude_yaw(compass_heading),  # Yaw angle (-pi..+pi) [rad]
            0,  # Roll angular speed [rad/s]
            0,  # Pitch angular speed [rad/s]
            0  # Yaw angular speed [rad/s]
        )

    mavlink_instance.gps_status_send(
        0,  # Number of satellites visible
        # Global satellite ID
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        # Satellites used
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        # Elevation
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        # Direction of satellite
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        # Signal to noise ratio of satellite
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    )


class ParameterNotFound(Exception):
    """
    The parameter you requested to set doesn't exists.
    """
    pass


class ParameterValueError(Exception):
    """
    The parameter value that was passed is incorrect.
    WARNING: Be careful with the exception text! It can't be bigger than 50 characters (will be
    WARNING:    cropped otherwise in GS) (MAVLink STATUSTEXT message limit).
    """
    pass


def match_param_id_index(param_id=None, param_index=-1):
    """
    If one of the identifiers are missing tries to find a pair, else passes arguments back.
    WARNING: To be called only from the main thread!
    :param param_id: Character parameter ID (str or None)
    :param param_index: Numeric parameter index (int) (-1 if not presented)
    :return: Character parameter ID and numeric parameter index (tuple(str, int))
    """

    # Type checks
    if not isinstance(param_id, (str, type(None))):
        raise TypeError('param_id has to be a str or None')

    if not isinstance(param_index, int):
        raise TypeError('param_id has to be an integer')
    #

    # HINT: Parameter ID can be both None (not presented in API) and '' (not presented in
    # HINT:     MAVLink) so the best way to check for valid value is to use bool(param_id)
    if param_id and (param_index != -1):  # Both presented
        pass  # Do nothing
    elif param_id:  # Character ID only presented
        try:
            # Try to find key index in the OrderedDict keys list
            param_index = VEHICLE_PARAMETERS.keys().index(param_id)
        except ValueError:  # Incorrect parameter index
            raise ParameterNotFound('Incorrect parameter ID')
    elif param_index != -1:  # Only numeric parameter index presented
        try:
            # Get key from the OrderedDict keys list directly
            param_id = VEHICLE_PARAMETERS.keys()[param_index]
        except IndexError:  # Incorrect parameter index
            raise ParameterNotFound('Incorrect parameter index')
    else:  # No parameter identities passes at all
        raise ValueError('Neither parameter ID nor parameter index is presented!')

    return param_id, param_index


class ChargingStationInErrorDriverState(Exception):
    """
    Custom mode setup requested while charging station is in the error state.
    HINT: The only reason we have this exception is to implement DO_SET_MODE idempotency (error
    HINT:   will cause an operation reject, a command will be accepted in other states).
    """
    pass


class CommandIsMeaningless(Exception):
    """
    Requested charging station custom mode is already in progress or has been already completed.
    """
    pass


class HardwareDriverError(Exception):
    """
    Requested operation was interrupted by a hardware driver node error.
    """
    pass


class GpsRtcmNodeError(Exception):
    """
    Requested operation was interrupted by a GPS/RTCM node error.
    """
    pass


def set_custom_mode(custom_mode, params = None):
    """
    Set new charging station custom mode (in fact, controls charging station).
    HINT: There are several ways to set custom mode in MAVLink.
    :param custom_mode: New vehicle custom mode (VehicleCustomMode)
    :return: None
    """
    # Type check
    if not isinstance(custom_mode, VehicleCustomMode):
        raise TypeError('custom_mode has to be an instance of VehicleCustomMode')

    rospy.logdebug('New charging station mode requested: %s', custom_mode)

    try:
        # Convert a custom mode to a driver command, start a driver command
        response = driver_command_service(custom_mode.to_driver_command(), 
            params["param1"], params["param2"], params["param3"], params["param4"], params["param5"])
    except ValueError:  # Driver command binding for the current custom mode isn't found
        raise NotImplementedError('No driver command binding for the custom mode: {0}'.format(
            custom_mode))
    except rospy.service.ServiceException as e:
        rospy.logerr('Driver node is down: "%s"!', e)
        raise HardwareDriverError('Driver node is down')

    # Driver command has been started successfully
    if response.result == DriverCommandResponse.SUCCESS:
        rospy.logdebug('Driver command has been started')
    elif response.result == DriverCommandResponse.BUSY:
        rospy.logdebug('Another driver command is in process')
        raise HardwareDriverError(response.message)
    # Driver error
    elif response.result == DriverCommandResponse.ERROR:
        rospy.logerr('Failed to start a driver command: "%s"!', response.message)
        raise HardwareDriverError(response.message)
    # Driver node is in the error state
    elif response.result == DriverCommandResponse.ERROR_STATE:
        rospy.logerr('Can\'t control charging station in the error state!')
        raise ChargingStationInErrorDriverState(response.message)
    # Driver is already processing the same command or the command is already completed
    elif response.result == DriverCommandResponse.ALREADY_DONE:
        rospy.logdebug('Command is meaningless in the current state!')
        raise CommandIsMeaningless(response.message)
    else:  # Unknown result code
        raise NotImplementedError('Unknown driver command result code: {0}'.format(response.result))


def set_parameter(param_value, param_id=None, param_index=-1):
    """
    Set vehicle parameter by passing value and one of it's identities.
    HINT: There are several ways to set parameter in MAVLink.
    WARNING: To be called only from the main thread!
    WARNING: At least one identity has to be set!
    :param param_value: Parameter value to set
    :param param_id: Parameter ID (str or None)
    :param param_index: Parameter index (int)
    :raises ValueError (incorrect arguments), ParameterNotFound (parameter doesn't exist),
        ParameterValueError (value integrity failed)
    :return: None
    """
    global mavlink_station_heading

    # Parameter value check
    if not isinstance(param_value, float):
        raise ParameterValueError('Value has to be a float')

    try:
        # Parameter identities match
        # HINT: param_id is immutable, safe to modify
        param_id, _ = match_param_id_index(param_id, param_index)
    except (TypeError, ValueError, ParameterNotFound):
        raise ParameterValueError('Invalid parameter identities')

    if param_id == VehicleParameter.PARAM_VERSION:  # Charging station parameters major version
        rospy.logerr('%s is a read-only parameter', VehicleParameter.PARAM_VERSION)

        raise ParameterValueError('{0} is a read-only parameter'.format(VehicleParameter.PARAM_VERSION))
    elif param_id == VehicleParameter.SYSTEM_ID:  # Charging station MAVLink system ID
        try:
            # Reinterpret float to uint8
            actual_value = float_to_uint8(param_value)
        except struct.error:  # Reinterpret error
            rospy.logerr('Can\'t reinterpret "%s" as uint8', param_value)

            raise ParameterValueError('Not a correct system ID')

        # Value integrity check:
        #   1: Not MAVLINK_SYSTEM_ID_BROADCAST
        if actual_value != MAVLINK_SYSTEM_ID_BROADCAST:
            with vehicle_parameters_lock:
                # WARNING: This parameter will be applied only after parameters save and a virtual
                #   vehicle reboot!
                VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] = actual_value
            rospy.loginfo(
                'Updated system ID: %s. Will be applied after save and reboot!',
                VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID])
        else:  # Value integrity check has failed
            rospy.logerr('"%s" can\'t be a broadcast address!', actual_value)

            raise ParameterValueError('Not a correct system ID')
    elif param_id == VehicleParameter.LATITUDE:  # Latitude coordinate
        if not (-90 <= param_value <= 90):  # Value integrity check
            rospy.logerr('"%s" is not a correct latitude!', param_value)

            raise ParameterValueError('Not a correct latitude')

        with vehicle_parameters_lock:
            # Pass the value directly
            VEHICLE_PARAMETERS[VehicleParameter.LATITUDE] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station latitude: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.LATITUDE])
    elif param_id == VehicleParameter.LONGITUDE:  # Longitude coordinate
        if not (-180 <= param_value <= 180):  # Value integrity check
            rospy.logerr('"%s" is not a correct longitude!', param_value)

            raise ParameterValueError('Not a correct longitude')

        with vehicle_parameters_lock:
            # Pass the value directly
            VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station longitude: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE])
    elif param_id == VehicleParameter.ALTITUDE:  # Altitude coordinate
        if not (INT32_MIN <= param_value <= INT32_MAX):  # Value integrity check
            rospy.logerr('"%s" is not a correct altitude!', param_value)

            raise ParameterValueError('Not a correct altitude')

        with vehicle_parameters_lock:
            # Pass the value directly
            VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station altitude: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE])
    elif param_id == VehicleParameter.HEADING:  # Station heading
        if not (-180 <= param_value <= 180):  # Value integrity check
            rospy.logerr('"%s" is not a correct heading!', param_value)

            raise ParameterValueError('Not a correct vehicle heading')

        with vehicle_parameters_lock:
            # Pass the value directly
            VEHICLE_PARAMETERS[VehicleParameter.HEADING] = param_value

        update_mavlink_heading()

        if VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] or \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY]:
            # Convert coordinates to MAVLink format and save for telemetry usage
            update_mavlink_coordinates()

        rospy.loginfo('Updated charging station heading: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.HEADING])
    elif param_id == VehicleParameter.GPS_ANTENNA_DX:  # GPS antenna offset by X
        with vehicle_parameters_lock:
            # Pass the value directly
            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station GPS antenna offset by X: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX])
    elif param_id == VehicleParameter.GPS_ANTENNA_DY:  # GPS antenna offset by Y
        with vehicle_parameters_lock:
            # GPS antenna offset by Y
            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station GPS antenna offset by Y: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY])
    elif param_id == VehicleParameter.GPS_ANTENNA_DZ:  # GPS antenna offset by Z (altitude)
        with vehicle_parameters_lock:
            # GPS antenna offset by Y
            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ] = param_value

        # Convert coordinates to MAVLink format and save for telemetry usage
        update_mavlink_coordinates()

        rospy.loginfo('Updated charging station GPS antenna offset by Z: %s.',
                      VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ])
    elif param_id == VehicleParameter.SURVEY_IN_ACCURACY:  # GPS/RTCM survey-in accuracy
        if not rtk_node_prefix:  # No RTK node is presented
            raise GpsRtcmNodeError('No RTK node presented')

        with vehicle_parameters_lock:
            try:
                # Set survey-in parameters
                result = set_svin_params_service(
                    param_value,
                    VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_DURATION]
                )
            except rospy.service.ServiceException as e:
                rospy.logerr('RTK node is down: "%s"!', e)
                raise GpsRtcmNodeError('RTK node is down')

            if not result.success:  # Failed
                raise ParameterValueError(result.message)

            # Update parameter value
            VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_ACCURACY] = param_value
    elif param_id == VehicleParameter.SURVEY_IN_DURATION:  # GPS/RTCM survey-in duration
        if not rtk_node_prefix:  # No RTK node is presented
            raise GpsRtcmNodeError('No RTK node presented')

        try:
            # Reinterpret float to uint16
            actual_value = float_to_uint16(param_value)
        except struct.error:  # Reinterpret error
            rospy.logerr('Can\'t reinterpret "%s" as uint16', param_value)

            raise ParameterValueError('Not a correct RTK survey-in duration')

        with vehicle_parameters_lock:
            try:
                # Set survey-in parameters
                result = set_svin_params_service(
                    VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_ACCURACY],
                    actual_value
                )
            except rospy.service.ServiceException as e:
                rospy.logerr('RTK node is down: "%s"!', e)
                raise GpsRtcmNodeError('RTK node is down')

            if not result.success:  # Failed
                raise ParameterValueError(result.message)

            # Update parameter value
            VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_DURATION] = actual_value
    elif param_id == VehicleParameter.CONTROL:  # Charging station manual control parameter
        try:
            # Reinterpret float to int8
            actual_value = float_to_int8(param_value)
        except struct.error:  # Reinterpret error
            rospy.logerr('Can\'t reinterpret "%s" as int8', param_value)

            raise ParameterValueError('Not a correct control parameter value')

        # Value integrity check:
        #   1: Presented in ControlParameterCommand
        try:
            # Trying to instantiate an enum from parameter value without fraction part
            parameter_command = ControlParameterCommand(actual_value)
        except ValueError:
            raise ParameterValueError('Unknown control parameter command')

        rospy.logdebug('Manual charging station operation requested: %s',
                       parameter_command)

        try:
            # Convert a parameter command to a driver command (if possible),
            #   start a driver command
            response = driver_command_service(parameter_command.to_driver_command())
        except ValueError:  # No driver command binding for the parameter command
            raise NotImplementedError(
                'Manual control parameter value is not implemented: {0}'.format(
                    parameter_command))
        except rospy.service.ServiceException as e:
            rospy.logerr('Driver node is down: "%s"!', e)
            raise HardwareDriverError('Driver node is down')

        # Driver command has been successfully started
        if response.result == DriverCommandResponse.SUCCESS:
            rospy.logdebug('Driver command has been started')
        # Driver error
        elif response.result == DriverCommandResponse.ERROR:
            rospy.logerr('Failed to start a driver command: "%s"', response.message)
            raise HardwareDriverError(response.message)
        # Driver node is in the error state
        elif response.result == DriverCommandResponse.ERROR_STATE:
            rospy.logerr('Can\'t control charging station in the error state!')
            raise ChargingStationInErrorDriverState(response.message)
        # Driver is already processing this action or the action is already completed
        elif response.result == DriverCommandResponse.ALREADY_DONE:
            rospy.logdebug('Charging station is already processing the same request or the '
                           'action has been already done!')
            raise CommandIsMeaningless(response.message)
        else:  # Unknown result code
            raise NotImplementedError('Unknown driver command result code: {0}'.format(
                response.result))
    # Implement extra parameters here
    else:  # Unknown parameter
        raise ParameterNotFound('Unknown parameter!')


def load_parameters(default=False):
    """
    Load parameters from the configuration file (default=False) or from the default constants
        (default=True).
    WARNING: To be called only from the main thread!
    HINT: There are several ways to load parameters in MAVLink.
    HINT: If some values in configuration file is missing or invalid the default values
        will be used.
    WARNING: Do not use before config_file_path initialisation!
    :param default: Load parameters from the default constants (bool)
    :return: None
    """
    global mavlink_station_heading

    if default:  # Default parameters needed
        with vehicle_parameters_lock:
            # Load default system ID
            VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] = MAVLINK_SYSTEM_ID_DEFAULT

            # Load default static coordinates
            VEHICLE_PARAMETERS[VehicleParameter.LATITUDE] = \
                STATION_COORDINATES_DEFAULT[0]

            VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE] = \
                STATION_COORDINATES_DEFAULT[1]

            VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE] = \
                STATION_COORDINATES_DEFAULT[2]

            # Load default station heading
            VEHICLE_PARAMETERS[VehicleParameter.HEADING] = STATION_HEADING_DEFAULT

            # Load default GPS antenna offset
            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] = \
                GPS_ANTENNA_OFFSET_DEFAULT[0]

            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY] = \
                GPS_ANTENNA_OFFSET_DEFAULT[1]

            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ] = \
                GPS_ANTENNA_OFFSET_DEFAULT[2]

        update_mavlink_heading()

        rospy.logdebug('Default parameters loaded')
    else:  # Parameters from configuration files is needed
        with open(config_file_path, 'rt') as json_file:  # Open configuration file for reading
            try:
                config_data = json.load(json_file)  # Parse JSON

                rospy.logdebug('Configuration file data loaded')
            except ValueError as e:  # Can't parse a JSON file
                rospy.logerr('Failed to parse configuration file: "%s"!', e)

                # Load defaults parameters instead in recursion call
                # TODO: Is there a better way to do that?
                load_parameters(default=True)

                return

        rospy.logdebug('Config file content: %s', config_data)

        try:
            with vehicle_parameters_lock:
                # Extract charging station MAVLink system ID
                VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] = \
                    config_data[ConfigurationKey.SYSTEM_ID]

            # Type check
            if not isinstance(VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID], int):
                raise TypeError('MAVLink system ID has to be an integer!')

            # Integrity check:
            #   1: System ID has to be in range from 0 .. 255
            if (VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] < 0) or \
                    (VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] > 255):
                raise ValueError('MAVLink system ID has to be in range from 0 to 255!')

            # Integrity check:
            #   2: System ID can't be MAVLINK_SYSTEM_ID_BROADCAST
            if (VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] ==
                    MAVLINK_SYSTEM_ID_BROADCAST):
                raise ValueError('MAVLink system ID can\'t be a MAVLink broadcast ID!')
        except KeyError:  # Not exists in the configuration file
            with vehicle_parameters_lock:
                # Loading the default value
                VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] = MAVLINK_SYSTEM_ID_DEFAULT

            rospy.logdebug('No system ID has been found, using default')
        except (TypeError, ValueError):  # Invalid field value in the configuration file
            with vehicle_parameters_lock:
                # Loading the default value
                VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID] = MAVLINK_SYSTEM_ID_DEFAULT

            rospy.logdebug('Invalid system ID field value (%s), using default',
                           config_data[ConfigurationKey.SYSTEM_ID])

        rospy.logdebug('MAVLink system ID loaded from config')

        try:
            with vehicle_parameters_lock:
                # Extract the charging station fixed coordinates (have to be integers or floats)
                VEHICLE_PARAMETERS[VehicleParameter.LATITUDE] = float(
                    config_data[ConfigurationKey.COORDINATES]
                    [ConfigurationKey.COORDINATES_LATITUDE])

                VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE] = float(
                    config_data[ConfigurationKey.COORDINATES]
                    [ConfigurationKey.COORDINATES_LONGITUDE])

                VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE] = float(
                    config_data[ConfigurationKey.COORDINATES]
                    [ConfigurationKey.COORDINATES_ALTITUDE])

            # Latitude integrity check
            if not (-90 <= VEHICLE_PARAMETERS[VehicleParameter.LATITUDE] <= 90):
                raise ValueError('Not a correct latitude!')

            # Longitude integrity check
            if not (-180 <= VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE] <= 180):
                raise ValueError('Not a correct longitude!')

            rospy.logdebug('Station coordinates loaded from the configuration file')
        except KeyError:  # Not exists in the configuration file
            with vehicle_parameters_lock:
                # Loading the default coordinates
                VEHICLE_PARAMETERS[VehicleParameter.LATITUDE], \
                VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE], \
                VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE] = STATION_COORDINATES_DEFAULT

            rospy.logdebug('No coordinates found, using defaults')
        except (TypeError, ValueError):  # Invalid coordinates values in the configuration file
            with vehicle_parameters_lock:
                # Loading the default coordinates
                VEHICLE_PARAMETERS[VehicleParameter.LATITUDE], \
                VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE], \
                VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE] = STATION_COORDINATES_DEFAULT

            rospy.logerr('Invalid coordinates values "%s", using defaults',
                         config_data[ConfigurationKey.COORDINATES])

        try:
            with vehicle_parameters_lock:
                # Extract the charging station fixed heading (has to be integer or float)
                VEHICLE_PARAMETERS[VehicleParameter.HEADING] = \
                    float(config_data[ConfigurationKey.HEADING])

            # Heading integrity check
            if not (-180 <= VEHICLE_PARAMETERS[VehicleParameter.HEADING] <= 180):
                raise ValueError('Not a correct heading!')

            update_mavlink_heading()

            rospy.logdebug('Station heading loaded from the configuration file')
        except KeyError:  # Not exists in the configuration file
            with vehicle_parameters_lock:
                # Loading the default heading
                VEHICLE_PARAMETERS[VehicleParameter.HEADING] = STATION_HEADING_DEFAULT

            update_mavlink_heading()

            rospy.logdebug('No heading found, using defaults')
        except (TypeError, ValueError):  # Invalid baring value in the configuration file
            with vehicle_parameters_lock:
                # Loading the default heading
                VEHICLE_PARAMETERS[VehicleParameter.HEADING] = STATION_HEADING_DEFAULT

            update_mavlink_heading()

            rospy.logerr('Invalid heading value "%s", using defaults',
                         config_data[ConfigurationKey.HEADING])

        try:
            with vehicle_parameters_lock:
                # Extract GPS antenna offset (have to be integers or floats)
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] = float(
                    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DX])

                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY] = float(
                    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DY])

                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ] = float(
                    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DZ])

            rospy.logdebug('GPS antenna offset loaded from the configuration file')
        except KeyError:  # Not exists in the configuration file
            with vehicle_parameters_lock:
                # Loading the default GPS antenna offset
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX], \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY], \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ] = GPS_ANTENNA_OFFSET_DEFAULT

            rospy.logdebug('No GPS antenna offset found, using defaults')
        except TypeError:  # Invalid coordinates values in the configuration file
            with vehicle_parameters_lock:
                # Loading the default GPS antenna offset
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX], \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY], \
                VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ] = GPS_ANTENNA_OFFSET_DEFAULT

            rospy.logerr('Invalid coordinates values "%s", using defaults',
                         config_data[ConfigurationKey.COORDINATES])

    rospy.logdebug('Loaded system ID: %s', VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID])

    rospy.logdebug('Loaded charging station fixed coordinates: (%s, %s, %s)',
                   VEHICLE_PARAMETERS[VehicleParameter.LATITUDE],
                   VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE],
                   VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE]
                   )

    rospy.logdebug('Loaded station heading: %s',
                   VEHICLE_PARAMETERS[VehicleParameter.HEADING])

    rospy.logdebug('Loaded GPS antenna offset: (%s, %s, %s)',
                   VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX],
                   VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY],
                   VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]
                   )


def save_parameters():
    """
    Save parameters to the configuration file.
    WARNING: To be called only from the main thread!
    HINT: There are several ways to set parameter in MAVLink.
    WARNING: Do not use before config_file_path initialisation!
    :return: None
    """
    if os.path.exists(config_file_path):  # Check if configuration file exists
        with open(config_file_path, 'rt') as json_file:  # Open config file for reading
            try:
                config_data = json.load(json_file)  # Parsing JSON
                rospy.logdebug('Configuration file data was loaded')
            # Can't parse a JSON file (somebody edited it in runtime)
            except ValueError as e:
                rospy.logerr('Failed to parse configuration file: "%s"!', e)

                config_data = {}  # Use an empty dict
    else:  # Configuration file doesn't exists
        config_data = {}  # Use an empty dict

        rospy.logdebug('Configuration file doesn\'t exists!')

    # Update configuration file dictionary
    config_data[ConfigurationKey.SYSTEM_ID] = VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID]

    # If COORDINATES doesn't exists (configuration can't be loaded), create
    #   it using get method (with default value)
    config_data[ConfigurationKey.COORDINATES] = config_data.get(ConfigurationKey.COORDINATES,
                                                                {})

    # Update coordinates latitude
    config_data[ConfigurationKey.COORDINATES][ConfigurationKey.COORDINATES_LATITUDE] = \
        VEHICLE_PARAMETERS[VehicleParameter.LATITUDE]

    # Update coordinates longitude
    config_data[ConfigurationKey.COORDINATES][ConfigurationKey.COORDINATES_LONGITUDE] = \
        VEHICLE_PARAMETERS[VehicleParameter.LONGITUDE]

    # Update coordinates altitude
    config_data[ConfigurationKey.COORDINATES][ConfigurationKey.COORDINATES_ALTITUDE] = \
        VEHICLE_PARAMETERS[VehicleParameter.ALTITUDE]

    # Update heading
    config_data[ConfigurationKey.HEADING] = VEHICLE_PARAMETERS[VehicleParameter.HEADING]

    # If GPS_ANTENNA_OFFSET doesn't exists (configuration can't be loaded), create
    #   it using get method (with default value)
    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET] = config_data.get(
        ConfigurationKey.GPS_ANTENNA_OFFSET, {})

    # Update GPS antenna offset by X
    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DX] = \
        VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX]

    # Update GPS antenna offset by Y
    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DY] = \
        VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY]

    # Update GPS antenna offset by Z (altitude)
    config_data[ConfigurationKey.GPS_ANTENNA_OFFSET][ConfigurationKey.DZ] = \
        VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]

    with open(config_file_path, 'wt') as json_file:  # Open config file for writing
        # Save configuration file dictionary as JSON data
        # HINT: Use indent to improve JSON file readability
        json.dump(config_data, json_file, indent=JSON_INDENT)

    rospy.logdebug('Configuration file was updated')


def send_parameter(param_id=None, param_index=-1):
    """
    Sends parameter according to the identities
    WARNING: To be called only from the main thread!
    HINT: There are several ways to send parameter in MAVLink.
    WARNING: At least one identity has to be set!
    :param param_id: Character parameter ID (str or None)
    :param param_index: Numeric parameter index (int)
    :return: None
    """

    # Parameter identities match
    # HINT: param_id and param_index are immutable, safe to modify
    param_id, param_index = match_param_id_index(param_id, param_index)

    # Set parameter type according to the parameter ID and reinterpret data to float (if needed)
    if param_id == VehicleParameter.PARAM_VERSION:
        parameter_type = mavlink.MAV_PARAM_TYPE_INT32

        # Reinterpret int32 to float
        actual_value = int32_to_float(VEHICLE_PARAMETERS[param_id])
    elif param_id == VehicleParameter.SYSTEM_ID:
        parameter_type = mavlink.MAV_PARAM_TYPE_UINT8

        # Reinterpret uint8 to float
        actual_value = uint8_to_float(VEHICLE_PARAMETERS[param_id])
    elif param_id == VehicleParameter.CONTROL:
        parameter_type = mavlink.MAV_PARAM_TYPE_INT8

        # Reinterpret int8 to float
        actual_value = int8_to_float(VEHICLE_PARAMETERS[param_id])
    elif param_id == VehicleParameter.SURVEY_IN_DURATION:
        parameter_type = mavlink.MAV_PARAM_TYPE_UINT16

        # Reinterpret int16 to float
        actual_value = uint16_to_float(VEHICLE_PARAMETERS[param_id])
    else:
        parameter_type = mavlink.MAV_PARAM_TYPE_REAL32

        actual_value = VEHICLE_PARAMETERS[param_id]  # Pass a source value

    mavlink_instance.param_value_send(
        param_id,  # A NULL-terminated character parameter ID
        actual_value,  # Actual parameter value
        parameter_type,  # Parameter type
        len(VEHICLE_PARAMETERS),  # Total number of parameters
        param_index  # Parameter index
    )
    rospy.logdebug('Answering PARAM_VALUE for "%s" (%s)', param_id, param_index)


# MAVLink callbacks tools
# =================================

# Callback mapper dictionary
# WARNING: Do not edit manually! Use mavlink_message_callback decorator instead!
callback_mapper = {}

# Check a MAVLink target system if the message presented in this set
# WARNING: Do not edit manually! Use mavlink_message_callback decorator instead!
target_check_types = set()


def mavlink_message_callback(message_type, target_check=False):
    """
    MAVLink message callback decorator with arguments.
    WARNING: It's forbidden to use multiple callbacks for one message type!
    Example:
        @mavlink_message_callback('HEARTBEAT')
        @mavlink_message_callback('COMMAND_LONG', target_check=True)
    :param message_type: MAVLink message type (str)
    :param target_check: Target system check is needed (bool)
    :return: mavlink_message_callback_decorator
    """

    def mavlink_message_callback_decorator(func):
        """
        MAVLink message callback decorator. Registers a callback function in the callback_mapper
            and in the target_check_types (if target_check=True). Keeps a source function
            unchanged.
        :param func: Source function (callable)
        :return: Source function (callable)
        """
        callback_mapper[message_type] = func  # Register callback in the callback mapper

        if target_check:  # If target check requested
            target_check_types.add(message_type)  # Add message type to target_check_types

        return func  # Pass source function unchanged

    return mavlink_message_callback_decorator  # Pass the decorator


# =================================
# MAVLink callbacks section
# =================================


@mavlink_message_callback('HEARTBEAT')
def mavlink_heartbeat_callback(msg):
    """
    MAVLink heartbeat callback.
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A heartbeat message (pymavlink.MAVLink_heartbeat_message)
    :return: None
    """
    # rospy.logdebug('Incoming heartbeat: "%s"', msg)

    global other_system_presence_flag

    if not other_system_presence_flag:
        other_system_presence_flag = True  # Set the flag

        rospy.loginfo('Other system heartbeat detected!')


@mavlink_message_callback('COMMAND_LONG', target_check=True)
def mavlink_long_command_callback(msg):
    """
    MAVLink long command callback (execute a command).
    WARNING: Synchronous callback!
    WARNING: All commands have to be idempotent!
    :param msg: A long command message (pymavlink.MAVLink_command_long_message)
    :return: None
    """
    global reboot_flag

    # rospy.logdebug('Incoming long command: "%s"', msg)

    # Target component check
    if (msg.target_component != mavlink_component_id) and \
            (msg.target_component != mavlink.MAV_COMP_ID_ALL):
        rospy.logerr('Unsupported component: %s', msg.target_component)

        return  # Ignore

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        user_hint = None  # User hint after ack

        if msg.command == 519: #mavlink.MAV_CMD_REQUEST_PROTOCOL_VERSION (deprecated):  # Protocol version request
            rospy.logdebug('Protocol version request command received')

            mavlink_instance.command_ack_send(
                msg.command,  # Command type
                # Command result
                mavlink.MAV_RESULT_UNSUPPORTED  # Success
                # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                # # Set a source component as a target component
                # target_component=msg.get_srcComponent()
            )
            rospy.logdebug('Command unsupported')

            # mavlink_instance.protocol_version_send(
            #     200,  # Currently active MAVLink version number * 100
            #     200,  # Minimum MAVLink version supported
            #     200,  # Maximum MAVLink version supported (same as default)
            #     [0, 0, 0, 0, 0, 0, 0, 0],  # The first 8 bytes of the spec version git hash
            #     [0, 0, 0, 0, 0, 0, 0, 0]  # The first 8 bytes of the library version git hash
            # )
            rospy.logdebug('Answering PROTOCOL_VERSION')
        # Autopilot capabilities request
        elif msg.command == mavlink.MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES:
            rospy.logdebug('Autopilot capabilities request command received')

            mavlink_instance.command_ack_send(
                msg.command,  # Command type
                # Command result
                mavlink.MAV_RESULT_ACCEPTED # Success
                # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                # # Set a source component as a target component
                # target_component=msg.get_srcComponent()
            )
            rospy.logdebug('Command accepted')

            mavlink_instance.autopilot_version_send(
                # Bitmask of capabilities
                mavlink.MAV_PROTOCOL_CAPABILITY_MAVLINK2 or
                mavlink.MAV_PROTOCOL_CAPABILITY_PARAM_FLOAT,
                1,  # Firmware version number
                0,  # Middleware version number
                0,  # Operating system version number
                0,  # HW / board version (last 8 bytes should be silicon ID, if any)
                [0, 0, 0, 0, 0, 0, 0, 0],  # Flight custom version field
                [0, 0, 0, 0, 0, 0, 0, 0],  # Middleware custom version field
                [0, 0, 0, 0, 0, 0, 0, 0],  # OS custom version field
                0,  # ID of the board vendor
                0,  # ID of the product
                0,  # UID if provided by hardware
                # UID2 if provided by hardware
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            )
            rospy.logdebug('Answering AUTOPILOT_CAPABILITIES')
        elif msg.command == mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN:  # Reboot or shutdown command
            rospy.logdebug('Autopilot reboot/shutdown command received')

            if msg.param1 == 1:  # Autopilot reboot
                rospy.logdebug('Reboot requested')

                if not reboot_flag:  # Double reboot request check
                    reboot_flag = True  # Set reboot flag
                    rospy.logdebug('Autopilot reboot requested')
                else:  # Ack was lost? It's ok.
                    rospy.logdebug('Reboot has been already requested.')

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_ACCEPTED  # Success
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command accepted')
            # Implement other subcommands here
            else:  # Other subcommands are not not supported
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_UNSUPPORTED # Not supported
                    # target_system=msg.get_srcSystem()  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command unsupported')

                rospy.logerr('Only reboot implemented at this moment ("%s" requested)', msg.param1)
        elif msg.command == mavlink.MAV_CMD_DO_SET_PARAMETER:  # Parameter set
            rospy.logdebug('Set parameter command received')
            try:
                # Try to set a parameter by index
                set_parameter(msg.param2, param_index=int(msg.param1))

                rospy.logdebug('Parameter with index %s was set successfully to "%s"',
                               int(msg.param1), msg.param2)

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_ACCEPTED  # Success
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command accepted')

                # We need a user hint only for the system ID parameter
                if msg.param1 == VehicleParameter.SYSTEM_ID:
                    user_hint = "New System ID will be applied after save and reboot!"
            # An error occurred
            except (ParameterNotFound, ParameterValueError, HardwareDriverError,
                    ChargingStationInErrorDriverState, GpsRtcmNodeError):
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_FAILED  # Error
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command failed')
            except CommandIsMeaningless:  # It's not an error in this case
                pass  # Command long has to be idempotent
        elif msg.command == mavlink.MAV_CMD_PREFLIGHT_STORAGE:  # Non-volatile storage command
            rospy.logdebug('Preflight storage command received')

            # Parameter storage action requested
            # We can execute this command if:
            #   HINT: According to QGC commands -1 for the mission storage is an ignore request.
            #   1 - msg.param2 (mission storage) is -1 (ignore);
            #   2 - msg.param3 (onboard logging) is 0 (ignore).
            if (msg.param2 == -1) and not msg.param3:
                rospy.logdebug('Parameter storage action')

                if msg.param1 == 1:  # Write storage
                    rospy.logdebug('Parameter storage write requested')

                    save_parameters()
                elif msg.param1 == 2:  # Default parameters load
                    rospy.logdebug('Default parameters load requested')

                    load_parameters(default=True)

                    # Convert coordinate to MAVLink format and save for the telemetry
                    update_mavlink_coordinates()

                    save_parameters()

                    if rtk_node_prefix:  # RTK node is presented
                        # Ask node to reset survey-in parameters and return defaults
                        result = reset_svin_params_service()

                        if not result.success:  # Operation failed
                            rospy.logerr(
                                'RTK node failed to reset survey-in parameters: "%s"!',
                                result.message)
                            mavlink_instance.command_ack_send(
                                msg.command,  # Command type
                                # Command result
                                mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                                # Set a source system as a target system
                                # target_system=msg.get_srcSystem(),
                                # # Set a source component as a target component
                                # target_component=msg.get_srcComponent()
                            )
                            rospy.logdebug('Command failed')

                            return

                        with vehicle_parameters_lock:
                            # Update vehicle survey-in parameters to defaults
                            VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_ACCURACY] = \
                                result.accuracy
                            VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_DURATION] = \
                                result.duration

                    # A hint for a user
                    user_hint = "Reboot to apply default MAVLink system ID!"
                else:  # Something from a new protocol version?
                    rospy.logdebug('Unknown action requested: %s', msg.param1)

                    mavlink_instance.command_ack_send(
                        msg.command,  # Command type
                        # Command result
                        mavlink.MAV_RESULT_UNSUPPORTED  # Success
                        # Set a source system as a target system
                        # target_system=msg.get_srcSystem(),
                        # # Set a source component as a target component
                        # target_component=msg.get_srcComponent()
                    )
                    rospy.logdebug('Command unsupported')

                    return

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_ACCEPTED  # Success
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command accepted')
            # Implement other actions here
            else:  # Could be something new in MAVLink
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_UNSUPPORTED  # Unsupported
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command unsupported')
        elif msg.command == mavlink.MAV_CMD_DO_SET_MODE:  # Mode setup
            rospy.logdebug('Mode setup command received: %s', msg)

            # Check if user requested to set a custom mode
            if msg.param1 != mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED:
                rospy.logerr('Invalid mode: %s. Only custom mode is supported!', msg.param1)

                mavlink_instance.statustext_send(
                    mavlink.MAV_SEVERITY_ERROR,  # It's an error
                    'Only custom modes are allowed!')
                rospy.logdebug('Answering STATUSTEXT')

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_UNSUPPORTED  # Only custom mode is supported
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command unsupported')

                return

            # Custom mode integrity check:
            #   1: param2 shouldn't have a fraction
            if not msg.param2.is_integer():
                rospy.logerr('Custom mode can\'t have a fraction! Received: "%s".', msg.param2)

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command temporarily rejected')

                return

            # Custom mode integrity check:
            #   2: int(param2) has to be in VehicleCustomMode
            try:
                # Converting float to int (doesn't care about fractional part) and then to the
                #   VehicleCustomMode
                custom_mode = VehicleCustomMode(int(msg.param2))
            except ValueError:
                rospy.logerr('Unknown custom mode: %s!', int(msg.param2))

                mavlink_instance.statustext_send(
                    mavlink.MAV_SEVERITY_ERROR,  # It's an error
                    'Unknown custom mode!')
                rospy.logdebug('Answering STATUSTEXT')

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command temporarily rejected')

                return

            rospy.loginfo('Mode setup requested: %s', custom_mode)

            try:
                params = {
                    "param1": msg.param3,
                    "param2": msg.param4,
                    "param3": msg.param5,
                    "param4": msg.param6,
                    "param5": msg.param7,
                }
                set_custom_mode(custom_mode, params=params)
            # A hardware driver node failed to start the command
            except HardwareDriverError as e:
                rospy.logerr('Hardware driver failed to start a command: "%s"!', e)

                mavlink_instance.statustext_send(
                    mavlink.MAV_SEVERITY_ERROR,  # It's an error
                    str(e) + '!')
                rospy.logdebug('Answering STATUSTEXT')

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command failed')

                return
            except ChargingStationInErrorDriverState:  # Charging station in the error mode
                rospy.logerr(
                    'Can\'t set new custom mode while charging station is in the error mode!')

                mavlink_instance.statustext_send(
                    mavlink.MAV_SEVERITY_ERROR,  # It's an error
                    str(e) + '!')

                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command failed')

                return
            # Requested current custom mode is meaningless in the current state
            #   (already in progress, completed)
            except CommandIsMeaningless as e:
                # HINT: Still, it's ok because command long has to be idempotent

                mavlink_instance.statustext_send(
                    mavlink.MAV_SEVERITY_INFO,  # It's information
                    str(e) + '!'
                )

                rospy.logdebug('Command is meaningless: "%s"', e)

                # Just send a positive ack

            # Accept the custom mode change command
            mavlink_instance.command_ack_send(
                msg.command,  # Command type
                # Command result
                mavlink.MAV_RESULT_ACCEPTED  # Success
                # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                # # Set a source component as a target component
                # target_component=msg.get_srcComponent()
            )
            rospy.logdebug('Command accepted')
        elif msg.command == mavlink.MAV_CMD_USER_1:  # Survey in restart
            if gps_rtk_restart_service is None:
                rospy.logerr('GPS node is not presented!')
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command failed')
            else:
                # Inform that it's a time-consuming command
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_IN_PROGRESS  # Success
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command in progress')

                try:
                    # Reconfigure GPS module
                    result = gps_rtk_restart_service()
                except rospy.service.ServiceException as e:
                    rospy.logerr('GPS/RTCM node is down: "%s"!', e)
                    mavlink_instance.command_ack_send(
                        msg.command,  # Command type
                        # Command result
                        mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                        # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                        # # Set a source component as a target component
                        # target_component=msg.get_srcComponent()
                    )
                    rospy.logdebug('Command failed')

                if not result.success:  # Failed
                    rospy.logerr('Failed to restart survey in!')
                    mavlink_instance.command_ack_send(
                        msg.command,  # Command type
                        # Command result
                        mavlink.MAV_RESULT_TEMPORARILY_REJECTED  # Temporarily rejected
                        # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                        # # Set a source component as a target component
                        # target_component=msg.get_srcComponent()
                    )
                    rospy.logdebug('Command failed')

                    return

                # Accept the command
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    # Command result
                    mavlink.MAV_RESULT_ACCEPTED  # Success
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command accepted')
        # Implement other commands here
        else:  # Command is unsupported
            # Send unsupported ack only for non-broadcast long commands
            if msg.target_system != MAVLINK_SYSTEM_ID_BROADCAST:
                mavlink_instance.command_ack_send(
                    msg.command,  # Command type
                    mavlink.MAV_RESULT_UNSUPPORTED  # Unsupported
                    # target_system=msg.get_srcSystem(),  # Set a source system as a target system
                    # # Set a source component as a target component
                    # target_component=msg.get_srcComponent()
                )
                rospy.logdebug('Command unsupported')

        # A status text with a hint is needed
        # TODO: Should a command-ack sequence be really strict? It would be much
        # TODO:  easier if we could send a status text before ack.
        if user_hint:
            # Special information for user
            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_INFO,  # Just additional information
                user_hint
            )
            rospy.logdebug('Answering STATUSTEXT')


@mavlink_message_callback('PARAM_REQUEST_LIST', target_check=True)
def mavlink_parameter_list_request_callback(msg):
    """
    MAVLink parameter list request callback (read all parameters from the vehicle).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A parameter list request message (pymavlink.MAVLink_param_request_list_message)
    :return: None
    """
    rospy.logdebug('Incoming parameter list request: "%s"', msg)

    # Target component check
    if (msg.target_component != mavlink_component_id) and \
            (msg.target_component != mavlink.MAV_COMP_ID_ALL):
        rospy.logdebug('Unsupported component: %s', msg.target_component)

        return

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        # Iterate over all parameter identifiers
        for param_id in VEHICLE_PARAMETERS:
            send_parameter(param_id=param_id)  # Send parameter


@mavlink_message_callback('PARAM_REQUEST_READ', target_check=True)
def mavlink_parameter_read_request(msg):
    """
    MAVLink parameter read request callback (read one parameter by character ID).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A parameter request message (pymavlink.MAVLink_param_request_read_message)
    :return: None
    """
    rospy.logdebug('Incoming parameter read request: "%s"', msg)

    # Target component check
    if (msg.target_component != mavlink_component_id) and \
            (msg.target_component != mavlink.MAV_COMP_ID_ALL):
        rospy.logdebug('Unsupported component: %s', msg.target_component)

        return

    try:
        param_id, param_index = match_param_id_index(msg.param_id, msg.param_index)
    except (TypeError, ValueError, ParameterNotFound) as e:
        rospy.logerr('Invalid parameter identities: %s!', e)

        # No ack for this command, just ignoring
        return

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        # Sending parameter
        send_parameter(param_id=param_id, param_index=param_index)


@mavlink_message_callback('PARAM_SET', target_check=True)
def mavlink_parameter_set_callback(msg):
    """
    MAVLink mission acknowledged callback (set one parameter by character ID).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A parameter set message (pymavlink.MAVLink_param_set_message)
    :return: None
    """
    rospy.logdebug('Incoming parameter set request: "%s"', msg)

    # Target component check
    if (msg.target_component != mavlink_component_id) and \
            (msg.target_component != mavlink.MAV_COMP_ID_ALL):
        rospy.logerr('Unsupported component: %s', msg.target_component)

        return

    message_text = None  # Keep status text message here
    message_severity = mavlink.MAV_SEVERITY_ERROR  # Status text message severity

    try:
        set_parameter(msg.param_value, param_id=msg.param_id)
    except ParameterNotFound:
        rospy.logerr('Unknown parameter: "%s"', msg.param_id)
        # No ack message for this command. Just ignoring.

        return
    except ParameterValueError as e:  # Incorrect parameter value
        message_text = str(e) + '!'
        rospy.logerr('Incorrect parameter value')
        # Return the old value, send status text with an error
    except HardwareDriverError as e:  # Hardware driver error
        message_text = str(e) + '!'
        rospy.logerr('Hardware driver error')
        # Return the old value, send status text with an error
    except GpsRtcmNodeError as e:  # Driver node error
        message_text = str(e) + '!'
        rospy.logerr('RTK node error')
        # Return the old value, send status text with an error
    except ChargingStationInErrorDriverState as e:  # Charging station is in the error mode
        message_text = str(e) + '!'
        rospy.logerr('Charging station is in the error mode!')
        # Return the old value, send status text with an error
    except CommandIsMeaningless as e:  # Driver node error
        message_text = str(e) + '!'
        message_severity = mavlink.MAV_SEVERITY_INFO
        rospy.logdebug('Charging station is already processing the same request or the '
                       'action has been already done!')
        # Return the old value, send status text with an information

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        # Sending back new parameter value
        send_parameter(param_id=msg.param_id)

        # TODO: Is it ok to send STATUSTEXT before PARAM_VALUE? It will improve code significantly.
        if message_text is not None:  # Status text message is prepared
            mavlink_instance.statustext_send(
                message_severity,  # Message severity
                message_text  # Message text
            )
            rospy.logdebug('Answering STATUSTEXT')

            # It was an error
            if message_severity == mavlink.MAV_SEVERITY_ERROR:
                return  # No need to save parameter in this case

        # WARNING: We have to save new parameter here! It violates MAVLink protocol description.
        # WARNING: Still, according to the link down it's an error in MAVLink description.
        # WARNING: https://groups.google.com/forum/#!topic/drones-discuss/dPzHNs7Oxyw
        # Check if the parameter ID affects configuration file
        if msg.param_id in {VehicleParameter.SYSTEM_ID, VehicleParameter.LATITUDE,
                            VehicleParameter.LONGITUDE, VehicleParameter.ALTITUDE,
                            VehicleParameter.HEADING, VehicleParameter.GPS_ANTENNA_DX,
                            VehicleParameter.GPS_ANTENNA_DY, VehicleParameter.GPS_ANTENNA_DZ}:
            save_parameters()  # Save parameters to the configuration file


@mavlink_message_callback('MISSION_REQUEST_LIST', target_check=True)
def mavlink_mission_list_request_callback(msg):
    """
    MAVLink mission list request callback.
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A mission list request message (pymavlink.MAVLink_mission_request_list_message)
    :return: None
    """
    rospy.logdebug('Incoming mission list request: "%s"', msg)

    # Target component check
    # WARNING: This message is served by mission planer component!
    if msg.target_component not in \
            [mavlink.MAV_COMP_ID_MISSIONPLANNER, mavlink_component_id, mavlink.MAV_COMP_ID_ALL]:
        rospy.logdebug('Unsupported component: %s', msg.target_component)

        return

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        # Send empty mission back
        mavlink_instance.mission_count_send(
            msg.get_srcSystem(),
            msg.get_srcComponent(),
            # Number of mission items in the sequence
            0,  # Always empty for the charging station
            mavlink.MAV_MISSION_TYPE_MISSION  # Mission type
        )
        rospy.logdebug('Answering MISSION_COUNT')


@mavlink_message_callback('MISSION_ACK', target_check=True)
def mavlink_mission_ack_callback(msg):
    """
    MAVLink mission acknowledged callback (mission acknowledged by the remote device).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A mission ack message (pymavlink.MAVLink_mission_ack_message)
    :return: None
    """
    rospy.logdebug('Incoming mission list request: "%s"', msg)

    # Target component check
    # WARNING: This message serves mission planer component!
    if msg.target_component not in \
            [mavlink.MAV_COMP_ID_MISSIONPLANNER, mavlink_component_id, mavlink.MAV_COMP_ID_ALL]:
        rospy.logdebug('Unsupported component: %s', msg.target_component)

        return


@mavlink_message_callback('MISSION_COUNT', target_check=True)
def mavlink_mission_count_callback(msg):
    """
    MAVLink mission count callback (remote device wants to upload a mission).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A mission count message (pymavlink.MAVLink_mission_count_message)
    :return: None
    """
    rospy.logdebug('Incoming mission count: "%s"', msg)

    # Target component check
    # WARNING: This message serves mission planer component!
    if msg.target_component not in \
            [mavlink.MAV_COMP_ID_MISSIONPLANNER, mavlink_component_id, mavlink.MAV_COMP_ID_ALL]:
        rospy.logdebug('Unsupported component: %s', msg.target_component)

        return

    if msg.target_system != MAVLINK_SYSTEM_ID_BROADCAST:
        with mavlink_lock:  # Synchronise with other MAVLink data sending threads
            # Rejecting
            mavlink_instance.mission_ack_send(
                msg.get_srcSystem(),  # System ID
                msg.get_srcComponent(),  # Component ID
                mavlink.MAV_MISSION_UNSUPPORTED,  # Mission result
                mavlink.MAV_MISSION_TYPE_MISSION  # Mission type
            )
            rospy.logdebug('Answering MISSION_ACK')


@mavlink_message_callback('SYSTEM_TIME')
def mavlink_system_time_callback(msg):
    """
    MAVLink system time callback (remote system time information).
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A system time message (pymavlink.MAVLink_system_time_message)
    :return: None
    """
    # rospy.logdebug('Incoming system time message: "%s"', msg)

    # rospy.logdebug('System time from node "%s" = %s ms, component "%s" time = %s us',
    #    msg.get_srcSystem(), msg.time_boot_ms, msg.get_srcComponent(),  msg.time_unix_usec)

    pass


@mavlink_message_callback('SET_MODE', target_check=True)
def mavlink_set_mode_callback(msg):
    """
    MAVLink set mode callback.
    HINT: Deprecated! But QGC still uses it.
    WARNING: Synchronous callback! Feel free to send MAVLink massages here.
    :param msg: A set mode message (pymavlink.MAVLink_set_mode_message)
    :return: None
    """
    rospy.logdebug('Incoming set mode message: "%s"', msg)
    print(msg.get_payload())

    with mavlink_lock:  # Synchronise with other MAVLink data sending threads
        if msg.base_mode != mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED:
            rospy.logerr('Only custom modes are allowed!')

            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_ERROR,  # It's an error
                'Only custom modes are allowed!')
            rospy.logdebug('Answering STATUSTEXT')

            return  # No answer needed

        try:
            custom_mode = VehicleCustomMode(msg.custom_mode)
        except ValueError:
            rospy.logerr('Unknown custom mode: %s!', msg.custom_mode)

            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_ERROR,  # It's an error
                'Unknown custom mode!')
            rospy.logdebug('Answering STATUSTEXT')

            return  # No answer needed

        try:
            set_custom_mode(custom_mode)
        except HardwareDriverError as e:  # Hardware driver error
            rospy.logerr('Failed to start driver command: "%s"!', e)

            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_ERROR,  # It's an error
                str(e) + '!')
            rospy.logdebug('Answering STATUSTEXT')

            return  # No answer needed
        except ChargingStationInErrorDriverState as e:  # Charging station in the error mode
            rospy.logerr('Can\'t set new custom mode while charging station is in the error mode!')

            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_ERROR,  # It's an error
                str(e) + '!')
            rospy.logdebug('Answering STATUSTEXT')

            return  # No answer needed
        except CommandIsMeaningless as e:  # Can't change custom mode in the current mode
            rospy.loginfo('Command is meaningless: "%s"', e)

            mavlink_instance.statustext_send(
                mavlink.MAV_SEVERITY_INFO,  # It's information
                str(e) + '!'
            )
            rospy.logdebug('Answering STATUSTEXT')

            return  # No answer needed


# =================================


def cs_driver_state_changed_callback(msg):
    """
    Charging station driver's state change callback (charging station state has changed).
    WARNING: Asynchronous callback! Avoid message output here!
    :param msg: New charging station driver's state (DriverState)
    :return: None
    """
    global cs_driver_state  # Use global variable
    global cs_custom_mode  # Use global variable

    rospy.logdebug('CS driver\'s state changed message: "%s"', msg)

    # WARNING: Synchronisation for BOTH cs_driver_state and cs_custom_mode
    with cs_state_mode_lock:
        cs_driver_state = msg.state  # Just copy the new state from message into global

        # Convert a CS driver state to the custom mode
        cs_custom_mode = VehicleCustomMode.state_to_custom_mode(cs_driver_state)

        severity = mavlink.MAV_SEVERITY_ERROR
        if msg.state != 13:
            severity = mavlink.MAV_SEVERITY_INFO

        if msg.status_string != '':
            mavlink_instance.statustext_send(
                severity,
                msg.status_string)

        rospy.logdebug('New CS state: %s. New CS custom mode: %s.', cs_driver_state,
                       cs_custom_mode)


# MAVLink RTCM seuence ID (will be set during the vehicle initialisation)
rtcm_sequence_id = None


def cs_rtcm_data_callback(msg):
    """
    Charging station GPS/RTCM node RTCM data callback.
    WARNING: Asynchronous callback!
    :param msg: RTCM data (Rtcm)
    :return: None
    """
    global rtcm_sequence_id

    # rospy.logdebug('RTCM data: "%s"', msg)

    # Synchronise with other MAVLink data sending threads
    with mavlink_lock:
        # Prevents using mavlink if it's not ready (on the node start/stop,
        #   the vehicle virtual reboot)
        if mavlink_ready.is_set():
            # RTCM data block fits the MAVLink RTCM data message
            if len(msg.data) <= MAVLINK_RTCM_DATA_LEN_MAX:
                # Send MAVLink RTCM fragment
                mavlink_instance.gps_rtcm_data_send(
                    # RTCM sequence ID with 3 bit shift, other bits to zero
                    #   (not fragmented, fragment ID = 0)
                    rtcm_sequence_id << 3,
                    # RTCM block size
                    len(msg.data),
                    # We have to pass iterable object with integer elements with exact
                    #   MAVLINK_RTCM_DATA_LEN_MAX length to to pymavlink
                    # HINT: ROS passes uint8 arrays as strings so bytearray() helps to solve
                    #   the issue
                    bytearray(msg.data + '\0' * (MAVLINK_RTCM_DATA_LEN_MAX - len(msg.data)))
                )
            else:  # It doesn't fit MAVLink RTCM data message
                rtcm_block_sent = 0  # RTCM block bytes sent

                rtcm_fragment_id = 0  # RTCM sequence fragment number

                # The first fragment will be always full
                rtcm_fragment_size = MAVLINK_RTCM_DATA_LEN_MAX

                while True:
                    # Send MAVLink RTCM fragment
                    mavlink_instance.gps_rtcm_data_send(
                        # RTCM sequence ID with 3 bit shift (5 bits), RTCM fragment ID with 1 bit shift (2 bit),
                        #   fragmented message flag
                        (rtcm_sequence_id << 3) | (rtcm_fragment_id << 1) | (1 << 0),
                        # RTCM block size
                        rtcm_fragment_size,
                        # We have to pass iterable object with integer elements with exact
                        #   MAVLINK_RTCM_DATA_LEN_MAX length to to pymavlink
                        # HINT: ROS passes uint8 arrays as strings, bytearray() helps to
                        # solve the issue
                        bytearray(
                            msg.data[rtcm_block_sent:rtcm_block_sent + rtcm_fragment_size + 1]
                            + '\0' * (MAVLINK_RTCM_DATA_LEN_MAX - rtcm_fragment_size)
                        )
                    )

                    # Increase RTCM block sent bytes counter
                    rtcm_block_sent += rtcm_fragment_size

                    # Calculate fragment size to send
                    rtcm_fragment_size = len(msg.data) - rtcm_block_sent

                    # No more data to send
                    if not rtcm_fragment_size:
                        break  # Stop the loop

                    # It doesn't fit MAVLink RTCM data message
                    if rtcm_fragment_size > MAVLINK_RTCM_DATA_LEN_MAX:
                        # Set size equal to MAVLINK_RTCM_DATA_LEN_MAX, we will send
                        #   the rest in the next fragment
                        rtcm_fragment_size = MAVLINK_RTCM_DATA_LEN_MAX

                    rtcm_fragment_id += 1  # Increase RTCM fragment ID

                    # Check if RTCM fragment ID doesn't fit into 2 bits
                    if rtcm_fragment_id >> 2:
                        rtcm_fragment_id = 0  # Reset RTCM fragment counter

            rtcm_sequence_id += 1  # Increase RTCM fragment ID

            # Check if RTCM sequence ID doesn't fit into 5 bits
            if rtcm_sequence_id >> 5:
                rtcm_sequence_id = 0  # Reset RTCM sequence counter


def survey_in_status_callback(msg):
    """
    RTK GPS survey in status callback.
    WARNING: Asynchronous callback!
    :param msg: Survey in status (gps_msgs/SurveyIn)
    :return: None
    """
    global survey_in_active

    # rospy.logdebug('Survey in status: "%s"', msg)

    # Synchronise with other MAVLink data sending threads
    with mavlink_lock:
        # Prevents using mavlink if it's not ready (on the node start/stop,
        #   the vehicle virtual reboot)
        if mavlink_ready.is_set():
            # Calculate the time interval from the vehicle boot (ms)
            time_from_boot_ms = mavlink_time_from_boot_ms()

            mavlink_instance.named_value_float_send(
                time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                'rtk_acc',  # Name of the debug variable
                msg.mean_accuracy  # Floating point value
            )
            mavlink_instance.named_value_float_send(
                time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                'rtk_dur',  # Name of the debug variable
                msg.duration  # Floating point value
            )

    # Synchronise with the heartbeat timer thread
    with survey_in_active_lock:
        # The message sends in the heartbeat timer callback
        survey_in_active = msg.active


def cs_vehicle_gps_position_callback(msg):
    """
    Charging station GPS/RTCM node vehicle GPS position callback.
    WARNING: Asynchronous callback!
    :param msg: Vehicle GPS position (VehicleGpsPosition)
    :return: None
    """
    global vehicle_start_time

    # rospy.logdebug('Vehicle GPS position: "%s"', msg)

    with mavlink_lock:  # Synchronise with the other threads
        # Prevents using mavlink if it's not ready (on the node start/stop,
        #   the vehicle virtual reboot)
        if mavlink_ready.is_set():
            # Calculate the time interval from the vehicle boot (ms)
            time_from_boot_ms = mavlink_time_from_boot_ms()

            with vehicle_position_lock:  # Synchronise with other threads
                with vehicle_parameters_lock:  # Synchronise with the main thread
                    # Antenna offset is presented
                    if VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX] or \
                            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY] or \
                            VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]:
                        # Calculate the new coordinates
                        corrected_coordinates = mavlink_coordinates(
                            *correct_charging_station_position(
                                standard_coordinates(msg.lat, msg.lon, msg.alt),
                                (VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DX],
                                 VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DY],
                                 VEHICLE_PARAMETERS[VehicleParameter.GPS_ANTENNA_DZ]),
                                VEHICLE_PARAMETERS[VehicleParameter.HEADING]
                                if not compass_heading_topic else compass_heading
                            )
                        )
                    else:  # No antenna offset is presented
                        # Pass the coordinates as they are
                        corrected_coordinates = msg.lat, msg.lon, msg.alt

                mavlink_instance.global_position_int_send(
                    time_from_boot_ms,  # Time since vehicle boot
                    corrected_coordinates[0],  # Latitude, expressed as degrees * 1E7
                    corrected_coordinates[1],  # Longitude, expressed as degrees * 1E7
                    corrected_coordinates[2],  # Altitude in meters, expressed as * 1000 (millimeters)
                    0,  # Altitude above ground in meters, expressed as * 1000 (millimeters)
                    # Ground X Speed (Latitude, positive north), expressed as m/s * 100
                    round(msg.vel_n_m_s * 100),
                    # Ground Y Speed (Longitude, positive east), expressed as m/s * 100
                    round(msg.vel_e_m_s * 100),
                    # Ground Z Speed (Altitude, positive up), expressed as m/s * 100
                    -round(msg.vel_d_m_s * 100),
                    # Vehicle heading (yaw angle) in degrees * 100, 0.0..359.99 degrees
                    mavlink_station_heading if not compass_heading_topic
                    else mavlink_heading(compass_heading)
                )

                mavlink_instance.attitude_send(
                    time_from_boot_ms,  # Time since vehicle boot
                    0,  # Roll angle (-pi..+pi) [rad]
                    0,  # Pitch angle (-pi..+pi) [rad] (type:float)
                    mavlink_station_attitude_yaw if not compass_heading_topic
                    else mavlink_attitude_yaw(compass_heading),  # Yaw angle (-pi..+pi) [rad]
                    0,  # Roll angular speed [rad/s]
                    0,  # Pitch angular speed [rad/s]
                    0  # Yaw angular speed [rad/s]
                )

            # Convert course over ground to degrees
            course_over_ground = math.degrees(msg.cog_rad)

            # Normalise to [0, 360]
            if course_over_ground < 0:
                course_over_ground += 360

            # MAVLink doesn't accept 360 degrees heading
            if course_over_ground > MAVLINK_DEGREE_MAX:
                course_over_ground = 0  # It's really close to the full circle (0 degrees)

            # Send raw GPS data
            mavlink_instance.gps_raw_int_send(
                # Microseconds since UNIX epoch from the GPS module
                msg.time_utc_usec,
                msg.fix_type,  # GPS fix type
                corrected_coordinates[0],  # Latitude, expressed as degrees * 1E7
                corrected_coordinates[1],  # Longitude, expressed as degrees * 1E7
                corrected_coordinates[2],  # Altitude (AMSL, NOT WGS84), in meters * 1000
                # GPS HDOP horizontal dilution of position (* 100)
                round(msg.hdop * 100),
                # GPS VDOP vertical dilution of position (* 100)
                round(msg.vdop * 100),
                # GPS ground speed (m/s * 100)
                round(msg.vel_m_s * 100),
                # Course over ground in degrees * 100, 0.0..359.99 degrees
                round(course_over_ground * 100),
                # Number of satellites visible
                msg.satellites_used,
                # Altitude (above WGS84, EGM96 ellipsoid), in meters * 1000
                msg.alt_ellipsoid,
                0,  # Position uncertainty in meters * 1000
                0,  # Altitude uncertainty in meters * 1000
                0,  # Speed uncertainty in meters * 1000
                0  # Heading / track uncertainty in degrees * 1e5
            )


def cs_satellite_information_callback(msg):
    """
    Charging station GPS/RTCM node satellite information callback.
    WARNING: Asynchronous callback!
    :param msg: Vehicle GPS position (SatelliteInformation)
    :return: None
    """
    # rospy.logdebug('Satellite information: "%s"', msg)

    with mavlink_lock:  # Synchronise with the other threads
        # Prevents using mavlink if it's not ready (on the node start/stop,
        #   the vehicle virtual reboot)
        if mavlink_ready.is_set():
            # Send satellite information
            mavlink_instance.gps_status_send(
                # Number of satellites visible
                msg.count,
                # Global satellite ID
                bytearray(msg.svid),
                # Satellites used
                bytearray(msg.used),
                # Elevation
                bytearray(msg.elevation),
                # Direction of satellite
                bytearray(msg.azimuth),
                # Signal to noise ratio of satellite
                bytearray(msg.snr)
            )


def cs_compass_heading_callback(msg):
    """
    Charging station GPS/RTCM node satellite information callback.
    WARNING: Asynchronous callback!
    :param msg: Vehicle GPS position (SatelliteInformation)
    :return: None
    """
    global compass_heading

    # rospy.logdebug('Compass heading: "%s"', msg)

    with vehicle_position_lock:
        compass_heading = math.degrees(msg.data)  # Update current compass header


def battery_state_callback(msg):
    """
    UAV battery state callback.
    WARNING: Asynchronous callback!
    :param msg: UAV battery state (sensor_msgs/BatteryState)
    :return: None
    """
    global battery_state

    # rospy.logdebug('Battery state: "%s"', msg)

    with battery_state_lock:
        battery_state = msg  # Update current battery state


def wind_callback(msg):
    """
    Wind callback.
    WARNING: Asynchronous callback!
    :param msg: Wind data (cs_meteo_msgs/Wind)
    :return: None
    """
    global wind_data

    # rospy.logdebug('Wind: "%s"', msg)

    with wind_cov_lock:
        wind_data = msg  # Update current wind data


def wind_direction_callback(msg):
    """
    Wind direction callback.
    WARNING: Asynchronous callback!
    :param msg: Wind direction data (cs_meteo_msgs/WindDirection)
    :return: None
    """
    global wind_direction

    # rospy.logdebug('Wind direction: "%s"', msg)

    with wind_cov_lock:
        wind_direction = msg  # Update current wind direction


def external_temperature_callback(msg):
    """
    External temperature callback.
    WARNING: Asynchronous callback!
    :param msg: Temperature data (sensor_msgs/Temperature)
    :return: None
    """
    global external_temperature_data

    # rospy.logdebug('Temperature: "%s"', msg)

    with scaled_pressure_lock:
        external_temperature_data = msg  # Update current external temperature


def barometer_callback(msg):
    """
    Barometer callback.
    WARNING: Asynchronous callback!
    :param msg: Barometer data (sensor_msgs/FluidPressure)
    :return: None
    """
    global barometer_data

    # rospy.logdebug('Barometer: "%s"', msg)

    with scaled_pressure_lock:
        barometer_data = msg  # Update current barometer data


def rain_callback(msg):
    """
    Rain callback.
    WARNING: Asynchronous callback!
    :param msg: Rain data (sensor_msgs/Rain)
    :return: None
    """
    global rain_data

    # rospy.logdebug('Rain: "%s"', msg)

    with rain_data_lock:
        rain_data = msg  # Update current rain data


def external_humidity_callback(msg):
    """
    External humidity callback.
    WARNING: Asynchronous callback!
    :param msg: Relative humidity data (sensor_msgs/RelativeHumidity)
    :return: None
    """
    global external_humidity_data
    # rospy.logdebug('Humidity: "%s"', msg)

    with external_humidity_data_lock:
        external_humidity_data = msg  # Update current external humidity


def telemetry_timer_callback(event):
    """
    Telemetry timer callback.
    :param event: Timer event (rospy.TimerEvent) or None (first heartbeat)
    :return: None
    """
    with mavlink_lock:  # If no other MAVLink node activity (in main thread)
        # Synchronisation with a charging station mode topic subscriber's thread
        # WARNING: Synchronisation for BOTH cs_driver_state and cs_custom_mode!
        with cs_state_mode_lock:
            mavlink_instance.heartbeat_send(
                mavlink.MAV_TYPE_CHARGING_STATION,  # Vehicle type
                mavlink.MAV_AUTOPILOT_GENERIC,  # Autopilot type
                mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,  # System mode bitfield
                # Passing custom mode directly
                cs_custom_mode,
                # System status
                # HINT: Pass EMERGENCY if CS internal state is the error state
                mavlink.MAV_STATE_STANDBY
                if cs_driver_state != DriverState.ERROR
                else mavlink.MAV_STATE_EMERGENCY
                # else mavlink.MAV_STATE_CRITICAL
            )

        # Calculate the time interval from the vehicle boot (ms)
        time_from_boot_ms = mavlink_time_from_boot_ms()

        if not gps_node_prefix:  # GPS node prefix is not presented in the configuration
            send_telemetry_static(time_from_boot_ms)  # Send static telemetry information

        with battery_state_lock:
            mavlink_instance.sys_status_send(
                # Bitmap showing which onboard controllers and sensors are present
                mavlink.MAV_SYS_STATUS_SENSOR_BATTERY,
                # Bitmap showing which onboard controllers and sensors are enabled
                mavlink.MAV_SYS_STATUS_SENSOR_BATTERY if (battery_state is not None) else 0,
                # Bitmap showing which onboard controllers and sensors are operational or have an error
                mavlink.MAV_SYS_STATUS_SENSOR_BATTERY if (battery_state is not None) else 0,
                0,  # Maximum usage in percent of the mainloop time
                0,  # Battery voltage [mV]
                -1,  # Battery current (unknown)
                # Remaining battery energy
                0 if (battery_state is None) or (battery_state.power_supply_status
                                                 == BatteryState.POWER_SUPPLY_STATUS_CHARGING) else 100,
                0,  # Communication drop rate
                0,  # Communication errors
                0,  # Autopilot-specific errors
                0,  # Autopilot-specific errors
                0,  # Autopilot-specific errors
                0  # Autopilot-specific errors
            )

            if battery_state is not None:
                mavlink_instance.battery_status_send(
                    0,  # Battery ID
                    mavlink.MAV_BATTERY_FUNCTION_UNKNOWN,  # Function of the battery
                    mavlink.MAV_BATTERY_TYPE_UNKNOWN,  # Type (chemistry) of the battery
                    INT16_MAX,  # Temperature of the battery (unknown)
                    [0] * 10,  # Battery voltage of cells (unknown)
                    -1,  # Battery current (unknown)
                    -1,  # Consumed charge (unknown)
                    -1,  # Consumed energy (unknown)
                    # Remaining battery energy
                    0 if battery_state.power_supply_status == BatteryState.POWER_SUPPLY_STATUS_CHARGING else 100,
                    -1,  # Remaining battery time (unknown)
                    # State for extent of discharge
                    mavlink.MAV_BATTERY_CHARGE_STATE_CHARGING
                    if battery_state.power_supply_status == BatteryState.POWER_SUPPLY_STATUS_CHARGING else
                    mavlink.MAV_BATTERY_CHARGE_STATE_OK
                )

        with wind_cov_lock:
            # WIND_COV makes sense only if both wind data and wind direction received
            if (wind_data is not None) and (wind_direction is not None) and \
                    (not math.isnan(wind_data.average)) and (not math.isnan(wind_direction.direction)):
                # Calculate wind in Y (NED) force from the wind absolute value and the wind direction
                wind_y = wind_data.average * math.sin(math.radians(wind_direction.direction))

                mavlink_instance.wind_cov_send(
                    rospy.Time.now().to_nsec() / 1000,  # Time since the unix epoch
                    # Calculate wind in X (NED) from the absolute value and wind in Y
                    math.sqrt(wind_data.average ** 2 - wind_y ** 2),
                    wind_y,  # Wind in Y (NED)
                    0,  # Wind in Z (NED) (Unknown)
                    -1,  # Variability of the wind in XY (Unknown)
                    -1,  # Variability of the wind in Z (Unknown)
                    -1,  # Altitude (MSL) that this measurement was taken at (Unknown)
                    0,  # Horizontal speed 1-STD accuracy (Unknown)
                    0  # Vertical speed 1-STD accuracy  (Unknown)
                )

        with scaled_pressure_lock:
            if ((barometer_data is not None) or (external_temperature_data is not None)) and \
                    ((not math.isnan(barometer_data.fluid_pressure)) or
                     (not math.isnan(external_temperature_data.temperature))):
                mavlink_instance.scaled_pressure_send(
                    time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                    # Absolute pressure [hPa]
                    barometer_data.fluid_pressure / 100 if barometer_data is not None else float('nan'),
                    # Differential pressure 1 [hPa]
                    float('nan'),
                    # Temperature [cdegC]
                    round(external_temperature_data.temperature * 100)
                    if (external_temperature_data is not None) and
                       (not math.isnan(external_temperature_data.temperature)) else INT16_MAX
                )

        with rain_data_lock:
            if (rain_data is not None) and (not math.isnan(rain_data.rain)):
                mavlink_instance.named_value_float_send(
                    time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                    'rain',  # Name of the debug variable
                    rain_data.rain  # Floating point value
                )

        with external_humidity_data_lock:
            if (external_humidity_data is not None) and (not math.isnan(external_humidity_data.relative_humidity)):
                mavlink_instance.named_value_float_send(
                    time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                    'humidity',  # Name of the debug variable
                    external_humidity_data.relative_humidity  # Floating point value
                )

        if rtk_node_prefix:
            with survey_in_active_lock:
                mavlink_instance.named_value_int_send(
                    time_from_boot_ms,  # Timestamp (time since system boot) [ms]
                    'rtk_surv',  # Name of the debug variable
                    int(survey_in_active)  # Integer value
                )
    #  rospy.logdebug('Telemetry send')


def init_vehicle():
    """
    Create a new MAVLink instance for a charging station vehicle, initialise a vehicle.
    :return: None
    """
    global vehicle_start_time
    global mavlink_system_id
    global mavlink_file
    global mavlink_instance
    global rtcm_sequence_id
    global telemetry_timer

    vehicle_start_time = rospy.Time.now()  # Saving vehicle startup time

    # MAVLink system ID changes only after reboot, so we have to cache this parameter
    mavlink_system_id = VEHICLE_PARAMETERS[VehicleParameter.SYSTEM_ID]

    # HINT: Extra debug to catch exit calls from mavutils
    rospy.logdebug('Creating MAVLink connection...')

    # Create a new MAVLink connection (MAVLink instance will be created automatically)
    # WARNING: mavutils can call exit(1) in some cases instead of throwing
    # WARNING:  exceptions!
    mavlink_file = mavutil.mavlink_connection(
        mavlink_url,  # MAVLink URL
        source_system=mavlink_system_id,  # System source ID
        source_component=mavlink_component_id  # System component ID
    )
    rospy.logdebug('New MAVLink connection ready: %s', mavlink_file)

    # Retrieve MAVLink instance from the connection
    mavlink_instance = mavlink_file.mav
    rospy.logdebug('MAVLink instance from connection: %s', mavlink_instance)

    rtcm_sequence_id = 0
    rospy.logdebug('MAVLink RTCM sequence ID reset')

    mavlink_ready.set()  # Inform other threads that mavlink instance is ready
    rospy.logdebug('MAVLink ready event was set')

    # Create a telemetry time
    telemetry_timer = rospy.Timer(rospy.Duration(
        1.0 / rospy.get_param('~telemetry_rate', 1)),
        # Set the event when the timer fires
        telemetry_timer_callback
    )
    rospy.logdebug('Telemetry timer ready: %s', telemetry_timer_callback)

    telemetry_timer_callback(None)  # Send telemetry immediately


# Main function
if __name__ == '__main__':
    # Initialize the node, name it, set log verbosity level
    rospy.init_node('cs_mavlink', log_level=rospy.DEBUG)
    rospy.logdebug('Node initialized')

    rospy.logdebug('Callback mapper content: %s', callback_mapper)

    rospy.logdebug('Message target check set: %s', target_check_types)

    config_file_path = rospy.get_param('~configuration_file', None)
    if not config_file_path:  # Determine configuration file path automatically
        rospy.logdebug('Node package name: %s', PACKAGE_NAME)

        # Create RosPack object to find current package path
        rospack = rospkg.RosPack()
        rospy.logdebug('New rospack instance: %s', rospack)

        # Find current package path
        current_package_path = rospack.get_path(PACKAGE_NAME)
        rospy.logdebug('Node package directory: %s', current_package_path)

        # CONFIG_PATH = <current_package_path> + <CONFIG_DIRECTORY> +
        #   <current node name (no starting slash)>.json
        config_file_path = os.path.join(current_package_path, CONFIG_DIRECTORY,
                                        "{0}.json".format(rospy.get_name()[1::]))

        # Cleaning up
        del rospack
        del current_package_path
    rospy.logdebug('Node config file: "%s"', config_file_path)

    # It's better to check right for config file at this point
    if os.path.isfile(config_file_path):  # Check  configuration file exists
        rospy.logdebug('Config file exists')

        # Check if file readable and writable
        if not os.access(config_file_path, os.W_OK or os.R_OK):
            # TODO: Create an appropriate exception
            raise Exception('Node don\'t have read or write permissions to {0}'.format(
                config_file_path))

        rospy.logdebug('Config file permissions ok')

        load_parameters()  # Load parameters from configuration file
    else:  # The configuration file doesn't exist, check if it's possible to create one
        rospy.logdebug('Config doesn\'t exists')

        # Calculating configuration file directory
        config_file_directory = os.path.dirname(config_file_path)

        rospy.logdebug('Config directory: %s', config_file_directory)

        if not os.path.isdir(config_file_directory):
            raise EnvironmentError('Configuration file directory "{0}" doesn\'t exist'.format(
                config_file_directory))

        if not os.access(config_file_directory, os.W_OK):  # Check if the directory is writable
            raise EnvironmentError('Node don\'t have permission to create file in {0}'.format(
                config_file_directory))

        # Clean up
        del config_file_directory

        rospy.logdebug('Config directory permissions ok')

        load_parameters(default=True)  # Load default parameters

    # Convert coordinate to MAVLink format and save for the telemetry
    update_mavlink_coordinates()

    env_cleanup = False  # Environment cleanup flag (not set by default)
    if MAVLINK20_ENV not in os.environ:  # Check if MAVLINK20 is set globally
        # Force pymavlink to use MAVLink v2.0 using environment variable
        # WARNING: Is there a better way to do this?
        # HINT: There is no content check for this variable in the pymavlink sources.
        os.environ[MAVLINK20_ENV] = ''
        rospy.logdebug('%s environment variable is set', MAVLINK20_ENV)

        # It's a good idea to clean this flag for other programs
        env_cleanup = True  # Set environment cleenup flag

    # Forcing pymavlink to use common MAVLink dialect
    # HINT: The result depends on the MAVLINK20 environment variable
    mavutil.set_dialect('common')

    if env_cleanup:  # Environment cleenup needed
        del os.environ[MAVLINK20_ENV]  # No need in this environmental variable further
        rospy.logdebug('%s environment variable is removed', MAVLINK20_ENV)

    # Clean up
    del env_cleanup

    # Importing mavlink module from pymavlink
    # WARNING: It looks the most right way to do it here. The result depends on the selected
    #   dialect.
    # TODO: Is there a better way to do this?
    from pymavlink.mavutil import mavlink

    # From this point we can use MAVLink module

    # Retrieving component ID
    # HINT: We have to implement AUTOPILOT component to communicate with GS software
    mavlink_component_id = mavlink.MAV_COMP_ID_AUTOPILOT1
    rospy.logdebug('mavlink module imported: %s', mavlink)

    mavlink_url = rospy.get_param('~mavlink_url', 'udpout:localhost:14550')

    if not isinstance(mavlink_url, str):
        raise EnvironmentError('MAVLink URL parameter value has to be a string!')

    rospy.logdebug('MAVLink URL: "%s"', mavlink_url)

    node_topic_prefix = rospy.get_param('~prefix', default='')

    if not isinstance(node_topic_prefix, str):
        raise EnvironmentError('Node topic prefix parameter value has to be a string!')

    # Get driver node wait timeout
    service_waiting_timeout = rospy.get_param('~service_waiting_timeout', default=10)

    if not isinstance(service_waiting_timeout, (int, float)):
        raise EnvironmentError('Service waiting timeout has to be an integer or a float!')

    rospy.logdebug('Service waiting timeout: %s', service_waiting_timeout)

    driver_node = rospy.get_param('~driver_node', default='cs_driver_a1')

    if not isinstance(driver_node, str):
        raise EnvironmentError('Driver node parameter value has to be a string!')

    rospy.logdebug('Driver node: %s', driver_node)

    # Subscribe for a hardware driver state topic
    rospy.Subscriber('{0}/state'.format(driver_node), DriverState,
                     cs_driver_state_changed_callback)
    rospy.logdebug('Subscribed for a driver\'s state change topic')

    # Calculate a driver command service name
    driver_command_service_name = '{0}/command'.format(driver_node)
    # Create a service client to send commands to a hardware driver
    driver_command_service = rospy.ServiceProxy(driver_command_service_name, DriverCommand)
    rospy.logdebug('Wait for a driver command service...')
    try:
        # Wait until the service is ready
        rospy.wait_for_service(driver_command_service_name, timeout=service_waiting_timeout)
    except rospy.exceptions.ROSException:
        raise EnvironmentError('Driver command service is not ready')
    rospy.logdebug('Service client for a driver commands is ready: %s', driver_command_service)

    # Cleaning up
    del driver_node
    del driver_command_service_name

    # Get compass heading topic
    compass_heading_topic = rospy.get_param('~compass_heading_topic', default='')

    if not isinstance(compass_heading_topic, (str, type(None))):
        raise EnvironmentError('Compass heading topic parameter value has to be a string!')

    if compass_heading_topic:
        # Subscribe for the compass heading topic
        rospy.Subscriber(compass_heading_topic, Float32, cs_compass_heading_callback)
        rospy.logdebug('Subscribed for the compass heading topic')

    # Get GPS node prefix
    gps_node_prefix = rospy.get_param('~gps_node_prefix', default='')

    if not isinstance(gps_node_prefix, str):
        raise EnvironmentError('GPS node prefix parameter value has to be a string!')

    if gps_node_prefix:  # Parameter is set
        rospy.logdebug('GPS node prefix: "%s"', gps_node_prefix)

        # Subscribe for the GPS node vehicle GPS position topic
        rospy.Subscriber(gps_node_prefix + '/vehicle_gps_position', VehicleGpsPosition,
                         cs_vehicle_gps_position_callback)
        rospy.logdebug('Subscribed for the vehicle GPS position topic')

        # Subscribe for the GPS node vehicle GPS position topic
        rospy.Subscriber(gps_node_prefix + '/satellite_information', SatelliteInformation,
                         cs_satellite_information_callback)
        rospy.logdebug('Subscribed for the satellite information topic')
    else:  # Not GPS node provided
        rospy.logdebug('No GPS node prefix presented. Using fixed position.')

    # Get RTK node prefix
    rtk_node_prefix = rospy.get_param('~rtk_node_prefix', default='')

    if not isinstance(rtk_node_prefix, str):
        raise EnvironmentError('RTK node prefix parameter value has to be a string!')

    if rtk_node_prefix:  # Parameter set
        # Calculate RTK node get survey-in parameters service name
        get_svin_params_service_name = '{0}/get_survey_in_parameters'.format(rtk_node_prefix)

        # Create RTK get survey-in parameters client
        get_svin_params_service = rospy.ServiceProxy(get_svin_params_service_name,
                                                     GetSurveyInParameters)
        rospy.logdebug('Wait for RTK get survey-in parameters service...')
        try:
            # Wait until the service is ready
            rospy.wait_for_service(get_svin_params_service_name, timeout=service_waiting_timeout)
        except rospy.exceptions.ROSException:
            raise EnvironmentError('RTK get survey-in parameters service is not ready')
        rospy.logdebug('Service client for RTK get survey-in parameters is ready: %s',
                       get_svin_params_service)

        # Clean up
        del get_svin_params_service_name
        del service_waiting_timeout

        survey_in_params = get_svin_params_service()

        if not survey_in_params.success:
            raise EnvironmentError(
                'Failed to retrieve RTK survey-in parameters: "{0}"'.format(
                    survey_in_params.message))

        VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_ACCURACY] = survey_in_params.accuracy
        VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_DURATION] = survey_in_params.duration

        rospy.logdebug('Survey-in accuracy: %s. Survey-in duration: %s.',
                       VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_ACCURACY],
                       VEHICLE_PARAMETERS[VehicleParameter.SURVEY_IN_DURATION])

        # Clean up
        del survey_in_params

        # Create RTK survey-in restart survey-in client
        gps_rtk_restart_service = rospy.ServiceProxy('{0}/restart_survey_in'.format(rtk_node_prefix),
                                                     Trigger)
        rospy.logdebug('Service client for RTK set survey-in parameters is ready: %s',
                       set_svin_params_service)

        # Create RTK set survey-in parameters client
        set_svin_params_service = rospy.ServiceProxy(
            '{0}/set_survey_in_parameters'.format(rtk_node_prefix), SetSurveyInParameters)
        rospy.logdebug('Service client for RTK set survey-in parameters is ready: %s',
                       set_svin_params_service)

        # Create RTK reset survey-in parameters client
        reset_svin_params_service = rospy.ServiceProxy(
            '{0}/reset_survey_in_parameters'.format(rtk_node_prefix), ResetSurveyInParameters)
        rospy.logdebug('Service client for RTK reset survey-in parameters is ready: %s',
                       reset_svin_params_service)

        # Subscribe for the RTK RTCM data topic
        rospy.Subscriber(rtk_node_prefix + '/rtcm', Rtcm, cs_rtcm_data_callback)
        rospy.logdebug('Subscribed for the RTK RTCM data topic')

        # Subscribe for the RTK survey in status topic
        rospy.Subscriber(rtk_node_prefix + '/survey_in', SurveyIn, survey_in_status_callback)
        rospy.logdebug('Subscribed for the RTK survey in status topic')

    node_state_check_timeout = rospy.get_param('~node_state_check_timeout', default=0.5)

    if not isinstance(node_state_check_timeout, (int, float)):
        raise EnvironmentError('Node state check timeout parameter value has to be an integer or '
                               + 'a float!')

    rospy.logdebug('Node state check timeout: %s', node_state_check_timeout)

    # Get battery state topic
    battery_state_topic = rospy.get_param('~battery_state_topic', default='')

    if not isinstance(battery_state_topic, (str, type(None))):
        raise EnvironmentError('Battery state topic parameter value has to be a string!')

    if battery_state_topic:
        # Subscribe for the battery state topic
        rospy.Subscriber(battery_state_topic, BatteryState, battery_state_callback)
        rospy.logdebug('Subscribed for the battery state topic')

    # Get wind topic
    wind_topic = rospy.get_param('~wind_topic', default='')

    if not isinstance(wind_topic, (str, type(None))):
        raise EnvironmentError('Wind topic parameter value has to be a string!')

    if wind_topic:
        # Subscribe for the wind topic
        rospy.Subscriber(wind_topic, Wind, wind_callback)
        rospy.logdebug('Subscribed for the wind topic')

    # Get wind direction topic
    wind_direction_topic = rospy.get_param('~wind_direction_topic', default='')

    if not isinstance(wind_direction_topic, (str, type(None))):
        raise EnvironmentError('Wind direction topic parameter value has to be a string!')

    if wind_direction_topic:
        # Subscribe for the wind direction topic
        rospy.Subscriber(wind_direction_topic, WindDirection, wind_direction_callback)
        rospy.logdebug('Subscribed for the wind direction topic')

    # Get external temperature topic
    external_temperature_topic = rospy.get_param('~external_temperature_topic', default='')

    if not isinstance(external_temperature_topic, (str, type(None))):
        raise EnvironmentError('External temperature topic parameter value has to be a string!')

    if external_temperature_topic:
        # Subscribe for the external temperature topic
        rospy.Subscriber(external_temperature_topic, Temperature, external_temperature_callback)
        rospy.logdebug('Subscribed for the external temperature topic')

    # Get barometer topic
    barometer_topic = rospy.get_param('~barometer_topic', default='')

    if not isinstance(barometer_topic, (str, type(None))):
        raise EnvironmentError('Barometer topic parameter value has to be a string!')

    if barometer_topic:
        # Subscribe for the barometer topic
        rospy.Subscriber(barometer_topic, FluidPressure, barometer_callback)
        rospy.logdebug('Subscribed for the barometer topic')

    # Get rain topic
    rain_topic = rospy.get_param('~rain_topic', default='')

    if not isinstance(rain_topic, (str, type(None))):
        raise EnvironmentError('Rain topic parameter value has to be a string!')

    if rain_topic:
        # Subscribe for the rain topic
        rospy.Subscriber(rain_topic, Rain, rain_callback)
        rospy.logdebug('Subscribed for the rain topic')

    # Get external humidity topic
    external_humidity_topic = rospy.get_param('~external_humidity_topic', default='')

    if not isinstance(external_humidity_topic, (str, type(None))):
        raise EnvironmentError('External humidity topic parameter value has to be a string!')

    if external_humidity_topic:
        # Subscribe for the rain topic
        rospy.Subscriber(external_humidity_topic, RelativeHumidity, external_humidity_callback)
        rospy.logdebug('Subscribed for the external humidity topic')

    # Start a vehicle for the charging station
    init_vehicle()

    # New data flag
    # HINT: Keep True at start to help MAVLink to initialise connection using recv_msg
    new_data = True

    try:
        while not rospy.is_shutdown():  # While the ROS is up
            if new_data:  # Incoming data in the buffer
                # WARNING: It's not safe to call pymavlink read and write operations from
                # WARNING:  different threads!
                with mavlink_lock:  # Synchronise with other threads
                    # Parse all input from the MAVLink, exit on new message
                    msg = mavlink_file.recv_msg()

                if msg:  # If a massage was parsed
                    # Retrieve a message type
                    msg_type = msg.get_type()
                    # No target check for this message type
                    if msg_type not in target_check_types:
                        try:
                            callback_mapper[msg_type](msg)  # Call an appropriate callback
                        except KeyError:
                            #  rospy.logdebug('Unsupported message: %s (%s)', msg, msg_type)
                            pass
                    else:  # A message with a target system
                        # Check if the massage is for this device or it's a broadcast
                        if (msg.target_system == mavlink_system_id) or \
                                (msg.target_system == MAVLINK_SYSTEM_ID_BROADCAST):
                            try:
                                callback_mapper[msg_type](msg)  # Call an appropriate callback
                            except KeyError:  # No callback implemented for this message
                                #  rospy.logdebug('Unsupported message with target: %s (%s)',
                                #   msg, msg_type)
                                pass

                    if reboot_flag:  # Vehicle reboot requested
                        rospy.loginfo('Node is about to make a virtual vehicle reboot')

                        # Inform other threads that MAVLink instance is not ready
                        mavlink_ready.clear()

                        # Wait until active thread stops using MAVLink
                        # HINT: There is a risk that one thread is actually acquired the lock
                        # HINT:     while the event was set. Wait until he ends his activity.
                        with mavlink_lock:
                            pass

                        rospy.logdebug('MAVLink dependent threads informed about MAVLink'
                                       ' shutdown')

                        # Stop the telemetry timer
                        telemetry_timer.shutdown()
                        rospy.logdebug('Telemetry timer shutdown: %s', telemetry_timer)

                        # Close pymavlink file to free resources for sure before variable
                        #  release
                        mavlink_file.close()

                        # Reset information about other systems presence
                        other_system_presence_flag = False

                        # HINT: It looks like a good idea to reset state and mode to unknown, but
                        # HINT:  it's not so simple. We can accidentally stuck in unknown state
                        # HINT:  for long time since driver's node will update state only on
                        # HINT:  the actual charging station state change.

                        reboot_flag = False  # Reset reboot request flag

                        # Start a new vehicle for the charging station
                        init_vehicle()

            # Wait for new data or exit by timeout
            # WARNING: Possible problems with thread safety with interpreters other than
            # WARNING:  CPython!
            # HINT: If file descriptor is not initialised, will wait for min(timeout, 0.5)
            # HINT:  and return True to allow pymavlink init file descriptor using recv_msg
            new_data = mavlink_file.select(node_state_check_timeout)
    finally:  # On the node error or shutdown
        # Inform other threads that MAVLink instance is not ready
        mavlink_ready.clear()

        # Wait until active thread stops using MAVLink
        # HINT: There is a risk that one thread is actually acquired the lock
        # HINT:     while the event was set. Wait until he ends his activity.
        with mavlink_lock:
            pass

        rospy.logdebug('MAVLink dependent threads informed about MAVLink shutdown')

        # Stop a telemetry timer to prevent callbacks during the node shutdown
        telemetry_timer.shutdown()
        rospy.logdebug('Telemetry timer shutdown: %s', telemetry_timer)
