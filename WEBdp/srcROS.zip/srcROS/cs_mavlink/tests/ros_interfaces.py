#!/usr/bin/env python
import rospy
import pytest
from pymavlink import mavutil
import math
from random import randint
import os
from time import sleep

from std_msgs.msg import Header, Float32

from cs_driver_srvs.srv import DriverCommand, DriverCommandRequest, DriverCommandResponse
from cs_driver_msgs.msg import DriverState

from cs_gps_srvs.srv import GetSurveyInParameters, GetSurveyInParametersResponse
from cs_gps_srvs.srv import SetSurveyInParameters, SetSurveyInParametersResponse
from cs_gps_srvs.srv import ResetSurveyInParameters, ResetSurveyInParametersResponse

from cs_gps_msgs.msg import Rtcm, VehicleGpsPosition, SatelliteInformation, SurveyIn

from sensor_msgs.msg import BatteryState, Temperature, FluidPressure, RelativeHumidity

from cs_meteo_msgs.msg import Wind, WindDirection, Rain

from cs_mavlink import cs_mavlink_node as target

MAVLINK20_ENV = 'MAVLINK20'  # MAVLink v2.0 environment variable name

env_cleanup = False  # Environment cleanup flag (not set by default)
if MAVLINK20_ENV not in os.environ:  # Check if MAVLINK20 is set globally
    # Force pymavlink to use MAVLink v2.0 using environment variable
    # WARNING: Is there a better way to do this?
    # HINT: There is no content check for this variable in the pymavlink sources.
    os.environ[MAVLINK20_ENV] = ''
    rospy.logdebug('%s environment variable is set', MAVLINK20_ENV)

    # It's a good idea to clean this flag for other programs
    env_cleanup = True  # Set environment cleenup flag

# Forcing pymavlink to use common MAVLink dialect
# HINT: The result depends on the MAVLINK20 environment variable
mavutil.set_dialect('common')

if env_cleanup:  # Environment cleenup needed
    del os.environ[MAVLINK20_ENV]  # No need in this environmental variable further
    rospy.logdebug('%s environment variable is removed', MAVLINK20_ENV)

# Clean up
del env_cleanup

# Importing mavlink module from pymavlink
# WARNING: It looks the most right way to do it here. The result depends on the selected
#   dialect.
# TODO: Is there a better way to do this?
from pymavlink.mavutil import mavlink

SVIN_ACCURACY_STATIC = 1.23
SVIN_DURATION_STATIC = 213

SVIN_ACCURACY_STATUS_STATIC = 2.54
SVIN_DURATION_STATUS_STATIC = 205

LAT_STATIC = 55.706630
LON_STATIC = 37.725511
ALT_STATIC = 500.3
ALT_ELLIPSOID_STATIC = 600
S_VARIANCE_MS_STATIC = 5.92
C_VARIANCE_RAD_STATIC = 3.22
EPH_STATIC_STATIC = 2.67
EPV_STATIC_STATIC = 3.78
HDOP_STATIC_STATIC = 1.23
VDOP_STATIC_STATIC = 0.98
NOISE_PER_MS_STATIC = 4
JAMMING_INDICATOR_STATIC = 6
VEL_MS_STATIC = 3.17
VEL_NMS_STATIC = 4.3
VEL_EMS_STATIC = 2.57
VEL_DMS_STATIC = 4.25
COG_RAD_STATIC = 1.3
FIX_TYPE_STATIC = 3
SATELLITES_USED_STATIC = 15

HEADING_STATIC = 3.05

BATTERY_VOLTAGE_STATIC = 12.6
BATTERY_CURRENT_STATIC = 6.5
BATTERY_CHARGE_STATIC = 2.0
BATTERY_CAPACITY_STATIC = 5.2
BATTERY_DESIGN_CAPACITY_STATIC = 6.0
BATTERY_PERCENTAGE_STATIC = 0.6
BATTERY_CELL_VOLTAGE_STATIC = [3.1, 3.2, 3.0, 3.1]
BATTERY_LOCATION = 'drone'
BATTERY_SERIAL = 'AABBCC112233'

WIND_DIRECTION_STATIC = 2.11
WIND_DIRECTION_COV_STATIC = 0.2

WIND_AVE_STATIC = 10.20
WIND_AVE_COV_STATIC = 2.1
WIND_GUST_STATIC = 15.27
WIND_GUST_COV_STATIC = 2.7

FLUID_PRESSURE_STATIC = 102.625
FLUID_PRESSURE_VAR_STATIC = 1.24

EXT_TEMP_STATIC = -25.3
EXT_TEMP_VAR_STATIC = 0.25

RAIN_STATIC = 104.23
RAIN_VAR_STATIC = 2.12

REL_HUMIDITY_STATIC = 0.56
REL_HUMIDITY_VAR_STATIC = 0.012

mavlink_file = None
mavlink_instance = None

message_wait_timeout = None
custom_vehicle_id = None

state_publisher = None


def isclose(a, b, rel_tol=1e-09, abs_tol=0.0):
    return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)


def cs_driver_command_callback(req):
    return DriverCommandResponse(DriverCommandResponse.SUCCESS, '')


def get_survey_in_parameters(req):
    return GetSurveyInParametersResponse(SVIN_ACCURACY_STATIC, SVIN_DURATION_STATIC, True, '')


def set_survey_in_parameters(req):
    return SetSurveyInParametersResponse(True, '')


def reset_survey_in_parameters(req):
    return ResetSurveyInParametersResponse(True, '')


def setup_module(module):
    global mavlink_file
    global mavlink_instance
    global message_wait_timeout
    global custom_vehicle_id
    global state_publisher

    rospy.init_node('mavlink_test', anonymous=True)
    mavlink_file = mavutil.mavlink_connection(
        'udpin:localhost:14550',  # MAVLink URL
        source_system=rospy.get_param('~mavlink_id'),  # System source ID
        source_component=mavlink.MAV_TYPE_GCS  # System component ID
    )
    mavlink_instance = mavlink_file.mav

    # Create a command service server
    rospy.Service('{0}/command'.format(rospy.get_param('cs_mavlink/driver_node')), DriverCommand,
                  cs_driver_command_callback)
    rospy.logdebug('Created a driver command service server')

    # Creating a topic publisher for commands addressed to actuation driver with latching
    state_publisher = rospy.Publisher('{0}/state'.format(rospy.get_param('cs_mavlink/driver_node')),
                                      DriverState, queue_size=10, latch=True)
    rospy.logdebug('Publisher for a state topic ready: %s', state_publisher)

    message_wait_timeout = rospy.get_param('~message_wait_interval')
    custom_vehicle_id = rospy.get_param('~custom_vehicle_id')

    rtk_node = rospy.get_param('cs_mavlink/rtk_node_prefix')

    rospy.Service('{0}/get_survey_in_parameters'.format(rtk_node), GetSurveyInParameters, get_survey_in_parameters)

    rospy.Service('{0}/set_survey_in_parameters'.format(rtk_node), SetSurveyInParameters, set_survey_in_parameters)

    rospy.Service('{0}/reset_survey_in_parameters'.format(rtk_node), ResetSurveyInParameters,
                  reset_survey_in_parameters)

    # Discover the uplink before starting tests
    msg = mavlink_file.recv_match(type='HEARTBEAT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None


@pytest.mark.order1
@pytest.mark.dependency()
def test_parameters_storage():
    assert not os.path.exists(rospy.get_param('cs_mavlink/configuration_file'))


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_rtk_node_interface():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_ACCURACY, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_ACCURACY),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert isclose(msg.param_value, SVIN_ACCURACY_STATIC, rel_tol=1e-07)
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_REAL32
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.SURVEY_IN_ACCURACY)

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_DURATION, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_DURATION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_uint16(msg.param_value) == SVIN_DURATION_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_UINT16
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.SURVEY_IN_DURATION)

    rtcm_publisher = rospy.Publisher('{0}/rtcm'.format(rospy.get_param('cs_mavlink/rtk_node_prefix')),
                                     Rtcm, queue_size=10, latch=True)

    def get_fragment_id(obj):
        return (obj.flags & 0b110) >> 1

    def get_fragmented(obj):
        return bool(obj.flags & 0b1)

    def get_sequence_id(obj):
        return obj.flags >> 3

    class GpsRtcmDataFragmentKey(object):
        def __init__(self, obj, *args):
            self.obj = obj

        def __lt__(self, other):
            return get_fragment_id(self.obj) < get_fragment_id(other.obj)

        def __gt__(self, other):
            return get_fragment_id(self.obj) > get_fragment_id(other.obj)

        def __eq__(self, other):
            return get_fragment_id(self.obj) == get_fragment_id(other.obj)

        def __le__(self, other):
            return get_fragment_id(self.obj) <= get_fragment_id(other.obj)

        def __ge__(self, other):
            return get_fragment_id(self.obj) >= get_fragment_id(other.obj)

        def __ne__(self, other):
            return get_fragment_id(self.obj) != get_fragment_id(other.obj)

    sequence_id = 0

    for test_sample in [randint(0, 255)], [randint(0, 255) for x in xrange(target.MAVLINK_RTCM_DATA_LEN_MAX // 2)], \
                       [randint(0, 255) for x in xrange(target.MAVLINK_RTCM_DATA_LEN_MAX - 30)], \
                       [randint(0, 255) for x in xrange(target.MAVLINK_RTCM_DATA_LEN_MAX)]:
        rtcm_publisher.publish(header=Header(stamp=rospy.Time.now()), data=test_sample)

        rtcm_messages = []
        while True:
            msg = mavlink_file.recv_match(type='GPS_RTCM_DATA', blocking=True, timeout=message_wait_timeout)
            if msg is None:
                break
            else:
                rtcm_messages.append(msg)
        assert len(rtcm_messages) == 1

        assert not get_fragmented(rtcm_messages[0])
        assert not get_fragment_id(rtcm_messages[0])
        assert get_sequence_id(rtcm_messages[0]) == sequence_id
        assert test_sample == rtcm_messages[0].data[:rtcm_messages[0].len]
        sequence_id += 1

    for test_sample in [randint(0, 255) for x in xrange(target.MAVLINK_RTCM_DATA_LEN_MAX * 2)], \
                       [randint(0, 255) for x in xrange(
                           target.MAVLINK_RTCM_DATA_LEN_MAX * 3 - target.MAVLINK_RTCM_DATA_LEN_MAX // 2
                       )], \
                       [randint(0, 255) for x in xrange(target.MAVLINK_RTCM_DATA_LEN_MAX * 4 - 101)]:
        rtcm_publisher.publish(header=Header(stamp=rospy.Time.now()), data=test_sample)

        rtcm_messages = []
        while True:
            msg = mavlink_file.recv_match(type='GPS_RTCM_DATA', blocking=True, timeout=message_wait_timeout)
            if msg is None:
                break
            else:
                rtcm_messages.append(msg)
        assert len(rtcm_messages) == len(test_sample) // target.MAVLINK_RTCM_DATA_LEN_MAX + \
               (1 if len(test_sample) % target.MAVLINK_RTCM_DATA_LEN_MAX else 0)

        rtcm_messages = sorted(rtcm_messages, key=GpsRtcmDataFragmentKey)
        data_recovered = []
        for i, value in enumerate(rtcm_messages):
            assert get_fragmented(value)
            assert get_fragment_id(value) == i
            assert get_sequence_id(value) == sequence_id
            data_recovered.extend(value.data[:value.len])
        assert test_sample == data_recovered
        sequence_id += 1

    survey_in_status_publisher = rospy.Publisher('{0}/survey_in'.format(rospy.get_param('cs_mavlink/rtk_node_prefix')),
                                                 SurveyIn, queue_size=10, latch=True)

    survey_in_status_publisher.publish(header=Header(stamp=rospy.Time.now()), mean_accuracy=SVIN_ACCURACY_STATUS_STATIC,
                                       duration=SVIN_DURATION_STATUS_STATIC, active=True, valid=True)
    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_FLOAT',
        condition="NAMED_VALUE_FLOAT.name=='rtk_acc'",
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert isclose(msg.value, SVIN_ACCURACY_STATUS_STATIC, rel_tol=1e-07)

    survey_in_status_publisher.publish(header=Header(stamp=rospy.Time.now()), mean_accuracy=SVIN_ACCURACY_STATUS_STATIC,
                                       duration=SVIN_DURATION_STATUS_STATIC, active=True, valid=True)
    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_FLOAT',
        condition="NAMED_VALUE_FLOAT.name=='rtk_dur'",
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert isclose(msg.value, SVIN_DURATION_STATUS_STATIC)

    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_INT',
        condition="(NAMED_VALUE_INT.name=='rtk_surv') and (NAMED_VALUE_INT.value=={0})".format(True),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None

    survey_in_status_publisher.publish(header=Header(stamp=rospy.Time.now()), mean_accuracy=SVIN_ACCURACY_STATUS_STATIC,
                                       duration=SVIN_DURATION_STATUS_STATIC, active=False, valid=False)
    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_INT',
        condition="(NAMED_VALUE_INT.name=='rtk_surv') and (NAMED_VALUE_INT.value=={0})".format(False),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_gps_node():
    vehicle_gps_position_publisher = rospy.Publisher('{0}/vehicle_gps_position'.format(
        rospy.get_param('cs_mavlink/gps_node_prefix')), VehicleGpsPosition, queue_size=10, latch=True)

    mavlink_coordinates = target.mavlink_coordinates(LAT_STATIC, LON_STATIC, ALT_STATIC)
    gps_position_msg = VehicleGpsPosition(
        header=Header(stamp=rospy.Time.now()),
        time_utc_usec=rospy.Time.now().to_nsec() // 1000,
        lat=mavlink_coordinates[0],
        lon=mavlink_coordinates[1],
        alt=mavlink_coordinates[2],
        alt_ellipsoid=int(ALT_ELLIPSOID_STATIC * 1000),
        s_variance_m_s=S_VARIANCE_MS_STATIC,
        c_variance_rad=C_VARIANCE_RAD_STATIC,
        eph=EPH_STATIC_STATIC,
        epv=EPV_STATIC_STATIC,
        hdop=HDOP_STATIC_STATIC,
        vdop=VDOP_STATIC_STATIC,
        noise_per_ms=NOISE_PER_MS_STATIC,
        jamming_indicator=JAMMING_INDICATOR_STATIC,
        vel_m_s=VEL_MS_STATIC,
        vel_n_m_s=VEL_NMS_STATIC,
        vel_e_m_s=VEL_EMS_STATIC,
        vel_d_m_s=VEL_DMS_STATIC,
        cog_rad=COG_RAD_STATIC,
        timestamp_time_relative=0,
        fix_type=FIX_TYPE_STATIC,
        vel_ned_valid=True,
        satellites_used=SATELLITES_USED_STATIC
    )

    vehicle_gps_position_publisher.publish(gps_position_msg)
    msg = mavlink_file.recv_match(type='GLOBAL_POSITION_INT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    standard_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
    assert isclose(standard_coordinates[0], LAT_STATIC)
    assert isclose(standard_coordinates[1], LON_STATIC)
    assert isclose(standard_coordinates[2], ALT_STATIC)
    assert not msg.relative_alt
    assert isclose(msg.vx / 100.0, VEL_NMS_STATIC)
    assert isclose(msg.vy / 100.0, VEL_EMS_STATIC)
    assert isclose(-msg.vz / 100.0, VEL_DMS_STATIC)
    assert not msg.hdg

    vehicle_gps_position_publisher.publish(gps_position_msg)
    msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.time_usec == gps_position_msg.time_utc_usec
    assert msg.fix_type == FIX_TYPE_STATIC
    standard_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
    assert isclose(standard_coordinates[0], LAT_STATIC)
    assert isclose(standard_coordinates[1], LON_STATIC)
    assert isclose(standard_coordinates[2], ALT_STATIC)
    assert isclose(msg.eph / 100.0, HDOP_STATIC_STATIC)
    assert isclose(msg.epv / 100.0, VDOP_STATIC_STATIC)
    assert isclose(msg.vel / 100.0, VEL_MS_STATIC)
    assert isclose(math.radians(msg.cog / 100.0), COG_RAD_STATIC, rel_tol=1e-2)
    assert msg.satellites_visible == SATELLITES_USED_STATIC
    assert isclose(msg.alt_ellipsoid / 1000.0, ALT_ELLIPSOID_STATIC)
    assert not msg.h_acc
    assert not msg.v_acc
    assert not msg.vel_acc
    assert not msg.hdg_acc

    gps_position_msg.cog_rad = math.radians(target.MAVLINK_DEGREE_MAX + 1e-3)
    vehicle_gps_position_publisher.publish(gps_position_msg)
    msg = mavlink_file.recv_match(type='GPS_RAW_INT', condition='GPS_RAW_INT.cog == 0', blocking=True,
                                  timeout=message_wait_timeout)
    assert msg is not None

    gps_position_msg.cog_rad = -COG_RAD_STATIC
    vehicle_gps_position_publisher.publish(gps_position_msg)
    msg = mavlink_file.recv_match(type='GPS_RAW_INT',
                                  condition='GPS_RAW_INT.cog != 0',
                                  blocking=True,
                                  timeout=message_wait_timeout)
    assert msg is not None
    assert isclose(math.radians(msg.cog / 100.0), 2 * math.pi - COG_RAD_STATIC, rel_tol=1e-02)

    satellite_information_publisher = rospy.Publisher('{0}/satellite_information'.format(
        rospy.get_param('cs_mavlink/gps_node_prefix')), SatelliteInformation, queue_size=10, latch=True)

    max_satellites = 20
    for n in 0, 10, 15, 20:
        satellite_information_msg = SatelliteInformation(
            header=Header(stamp=rospy.Time.now()),
            count=n,
            svid=[randint(0, 255) for x in xrange(n)] + [0] * (max_satellites - n),
            used=[1] * n + [0] * (max_satellites - n),
            elevation=[randint(0, 255) for x in xrange(n)] + [0] * (max_satellites - n),
            azimuth=[randint(0, 255) for x in xrange(n)] + [0] * (max_satellites - n),
            snr=[randint(0, 255) for x in xrange(n)] + [0] * (max_satellites - n)
        )
        satellite_information_publisher.publish(satellite_information_msg)
        msg = mavlink_file.recv_match(type='GPS_STATUS',
                                      condition='GPS_STATUS.satellites_visible == {0}'.format(n),
                                      blocking=True,
                                      timeout=message_wait_timeout)
        assert msg is not None
        assert msg.satellite_prn == satellite_information_msg.svid
        assert msg.satellite_used == satellite_information_msg.used
        assert msg.satellite_elevation == satellite_information_msg.elevation
        assert msg.satellite_azimuth == satellite_information_msg.azimuth
        assert msg.satellite_snr == satellite_information_msg.snr


@pytest.mark.order3
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_heading_topic():
    heading_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/compass_heading_topic'), Float32,
                                        queue_size=10, latch=True)

    heading_publisher.publish(data=HEADING_STATIC)
    rospy.sleep(0.5)

    vehicle_gps_position_publisher = rospy.Publisher('{0}/vehicle_gps_position'.format(
        rospy.get_param('cs_mavlink/gps_node_prefix')), VehicleGpsPosition, queue_size=10, latch=True)

    mavlink_coordinates = target.mavlink_coordinates(LAT_STATIC, LON_STATIC, ALT_STATIC)
    vehicle_gps_position_publisher.publish(
        header=Header(stamp=rospy.Time.now()),
        time_utc_usec=rospy.Time.now().to_nsec() // 1000,
        lat=mavlink_coordinates[0],
        lon=mavlink_coordinates[1],
        alt=mavlink_coordinates[2],
        alt_ellipsoid=int(ALT_ELLIPSOID_STATIC * 1000),
        s_variance_m_s=S_VARIANCE_MS_STATIC,
        c_variance_rad=C_VARIANCE_RAD_STATIC,
        eph=EPH_STATIC_STATIC,
        epv=EPV_STATIC_STATIC,
        hdop=HDOP_STATIC_STATIC,
        vdop=VDOP_STATIC_STATIC,
        noise_per_ms=NOISE_PER_MS_STATIC,
        jamming_indicator=JAMMING_INDICATOR_STATIC,
        vel_m_s=VEL_MS_STATIC,
        vel_n_m_s=VEL_NMS_STATIC,
        vel_e_m_s=VEL_EMS_STATIC,
        vel_d_m_s=VEL_DMS_STATIC,
        cog_rad=COG_RAD_STATIC,
        timestamp_time_relative=0,
        fix_type=FIX_TYPE_STATIC,
        vel_ned_valid=True,
        satellites_used=SATELLITES_USED_STATIC
    )

    passed = False
    for i in xrange(rospy.get_param('~mavlink_retries')):
        msg = mavlink_file.recv_match(type='ATTITUDE', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        assert not msg.roll
        assert not msg.pitch
        assert not msg.rollspeed
        assert not msg.pitchspeed
        assert not msg.yawspeed
        if isclose(msg.yaw, HEADING_STATIC, rel_tol=1e-02):
            passed = True
            break
    assert passed


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_battery_status_topic():
    msg = mavlink_file.recv_match(type='SYS_STATUS', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.onboard_control_sensors_present | mavlink.MAV_SYS_STATUS_SENSOR_BATTERY
    assert msg.onboard_control_sensors_enabled | mavlink.MAV_SYS_STATUS_SENSOR_BATTERY
    assert msg.onboard_control_sensors_health | mavlink.MAV_SYS_STATUS_SENSOR_BATTERY
    assert not msg.load
    assert not msg.voltage_battery
    assert msg.current_battery == -1
    assert not msg.battery_remaining
    assert not msg.drop_rate_comm
    assert not msg.errors_comm
    assert not msg.errors_count1
    assert not msg.errors_count2
    assert not msg.errors_count3
    assert not msg.errors_count4

    battery_state_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/battery_state_topic'),
                                              BatteryState, queue_size=10, latch=True)
    battery_state_publisher.publish(
        header=Header(stamp=rospy.Time.now()), voltage=BATTERY_VOLTAGE_STATIC, current=BATTERY_CURRENT_STATIC,
        charge=BATTERY_CHARGE_STATIC, capacity=BATTERY_CAPACITY_STATIC, design_capacity=BATTERY_DESIGN_CAPACITY_STATIC,
        percentage=BATTERY_PERCENTAGE_STATIC, power_supply_status=BatteryState.POWER_SUPPLY_STATUS_FULL,
        power_supply_health=BatteryState.POWER_SUPPLY_HEALTH_GOOD,
        power_supply_technology=BatteryState.POWER_SUPPLY_TECHNOLOGY_LIPO, present=True,
        cell_voltage=BATTERY_CELL_VOLTAGE_STATIC,
        location=BATTERY_LOCATION, serial_number=BATTERY_SERIAL
    )

    msg = mavlink_file.recv_match(type='SYS_STATUS',
                                  condition='SYS_STATUS.battery_remaining == 100', blocking=True,
                                  timeout=message_wait_timeout)
    assert msg is not None

    msg = mavlink_file.recv_match(type='BATTERY_STATUS', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert not msg.id
    assert msg.battery_function == mavlink.MAV_BATTERY_FUNCTION_UNKNOWN
    assert msg.type == mavlink.MAV_BATTERY_TYPE_UNKNOWN
    assert msg.temperature == target.INT16_MAX
    assert msg.voltages == [0] * 10
    assert msg.current_battery == -1
    assert msg.current_consumed == -1
    assert msg.energy_consumed == -1
    assert msg.battery_remaining == 100
    assert msg.time_remaining == -1
    assert msg.charge_state == mavlink.MAV_BATTERY_CHARGE_STATE_OK

    battery_state_publisher.publish(BatteryState(
        header=Header(stamp=rospy.Time.now()), voltage=BATTERY_VOLTAGE_STATIC, current=BATTERY_CURRENT_STATIC,
        charge=BATTERY_CHARGE_STATIC, capacity=BATTERY_CAPACITY_STATIC, design_capacity=BATTERY_DESIGN_CAPACITY_STATIC,
        percentage=BATTERY_PERCENTAGE_STATIC, power_supply_status=BatteryState.POWER_SUPPLY_STATUS_CHARGING,
        power_supply_health=BatteryState.POWER_SUPPLY_HEALTH_GOOD,
        power_supply_technology=BatteryState.POWER_SUPPLY_TECHNOLOGY_LIPO, present=True,
        cell_voltage=BATTERY_CELL_VOLTAGE_STATIC, location=BATTERY_LOCATION, serial_number=BATTERY_SERIAL
    ))

    msg = mavlink_file.recv_match(type='SYS_STATUS',
                                  condition='SYS_STATUS.battery_remaining == 0', blocking=True,
                                  timeout=message_wait_timeout)
    assert msg is not None

    msg = mavlink_file.recv_match(
        type='BATTERY_STATUS',
        condition='BATTERY_STATUS.battery_remaining == 0 and BATTERY_STATUS.charge_state == {0}'.format(
            mavlink.MAV_BATTERY_CHARGE_STATE_CHARGING
        ),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_weather_sensors_interface():
    wind_direction_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/wind_direction_topic'),
                                                     WindDirection, queue_size=10, latch=True)
    wind_direction_topic_publisher.publish(header=Header(stamp=rospy.Time.now()), direction=WIND_DIRECTION_STATIC,
                                                         variance=WIND_DIRECTION_COV_STATIC)
    wind_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/wind_topic'), Wind,
                                           queue_size=10, latch=True)
    wind_topic_publisher.publish(header=Header(stamp=rospy.Time.now()), average=WIND_AVE_STATIC,
                                 average_variance=WIND_AVE_COV_STATIC, gust=WIND_GUST_STATIC,
                                 gust_variance=WIND_GUST_COV_STATIC)
    msg = mavlink_file.recv_match(type='WIND_COV', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    wind_ave = math.sqrt(msg.wind_x ** 2 + msg.wind_y ** 2)
    assert isclose(wind_ave, WIND_AVE_STATIC, rel_tol=1e-07)
    wind_direction = math.degrees(math.acos(msg.wind_x / wind_ave))
    assert isclose(wind_direction, WIND_DIRECTION_STATIC, rel_tol=1e-07)
    assert not msg.wind_z
    assert msg.var_horiz == -1
    assert msg.var_vert == -1
    assert msg.wind_alt == -1
    assert not msg.horiz_accuracy
    assert not msg.vert_accuracy

    ext_temp_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/external_temperature_topic'),
                                               Temperature, queue_size=10, latch=True)
    ext_temp_topic_publisher.publish(header=Header(stamp=rospy.Time.now()), temperature=EXT_TEMP_STATIC,
                                     variance=EXT_TEMP_VAR_STATIC)
    barometer_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/barometer_topic'),
                                                FluidPressure, queue_size=10, latch=True)
    barometer_topic_publisher.publish(header=Header(stamp=rospy.Time.now()), fluid_pressure=FLUID_PRESSURE_STATIC,
                                     variance=FLUID_PRESSURE_VAR_STATIC)
    passed = False
    for i in xrange(rospy.get_param('~mavlink_retries')):
        msg = mavlink_file.recv_match(type='SCALED_PRESSURE', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        assert math.isnan(msg.press_diff)
        if isclose(msg.press_abs * 100, FLUID_PRESSURE_STATIC, rel_tol=1e-07) \
                and isclose(msg.temperature / 100.0, EXT_TEMP_STATIC):
            passed = True
            break
    assert passed

    rain_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/rain_topic'), Rain, queue_size=10, latch=True)
    rain_topic_publisher.publish(header=Header(stamp=rospy.Time.now()), rain_overflow=False, rain=RAIN_STATIC,
                                 variance=RAIN_VAR_STATIC)
    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_FLOAT',
        condition="NAMED_VALUE_FLOAT.name == 'rain'",
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert isclose(msg.value, RAIN_STATIC, rel_tol=1e-07)

    external_humidity_topic_publisher = rospy.Publisher(rospy.get_param('cs_mavlink/external_humidity_topic'),
                                                        RelativeHumidity, queue_size=10, latch=True)
    external_humidity_topic_publisher.publish(header=Header(stamp=rospy.Time.now()),
                                              relative_humidity=REL_HUMIDITY_STATIC, variance=REL_HUMIDITY_VAR_STATIC)
    msg = mavlink_file.recv_match(
        type='NAMED_VALUE_FLOAT',
        condition="NAMED_VALUE_FLOAT.name == 'humidity'",
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert isclose(msg.value, REL_HUMIDITY_STATIC, rel_tol=1e-07)


def teardown_module():
    sleep(0.5)  # Wait for some time before removing configuration file
    try:
        os.remove(rospy.get_param('cs_mavlink/configuration_file'))
    except OSError as e:
        if e.errno != 2:
            raise e
