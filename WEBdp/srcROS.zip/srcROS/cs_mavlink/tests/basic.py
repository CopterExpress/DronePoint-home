#!/usr/bin/env python
import rospy
import pytest
from pymavlink import mavutil
from threading import Event
from monotonic import monotonic
import os
from time import sleep

from std_msgs.msg import Header
from cs_driver_srvs.srv import DriverCommand, DriverCommandRequest, DriverCommandResponse
from cs_driver_msgs.msg import DriverState

from cs_mavlink import cs_mavlink_node as target

MAVLINK20_ENV = 'MAVLINK20'  # MAVLink v2.0 environment variable name

env_cleanup = False  # Environment cleanup flag (not set by default)
if MAVLINK20_ENV not in os.environ:  # Check if MAVLINK20 is set globally
    # Force pymavlink to use MAVLink v2.0 using environment variable
    # WARNING: Is there a better way to do this?
    # HINT: There is no content check for this variable in the pymavlink sources.
    os.environ[MAVLINK20_ENV] = ''
    rospy.logdebug('%s environment variable is set', MAVLINK20_ENV)

    # It's a good idea to clean this flag for other programs
    env_cleanup = True  # Set environment cleenup flag

# Forcing pymavlink to use common MAVLink dialect
# HINT: The result depends on the MAVLINK20 environment variable
mavutil.set_dialect('common')

if env_cleanup:  # Environment cleenup needed
    del os.environ[MAVLINK20_ENV]  # No need in this environmental variable further
    rospy.logdebug('%s environment variable is removed', MAVLINK20_ENV)

# Clean up
del env_cleanup

# Importing mavlink module from pymavlink
# WARNING: It looks the most right way to do it here. The result depends on the selected
#   dialect.
# TODO: Is there a better way to do this?
from pymavlink.mavutil import mavlink

mavlink_file = None
mavlink_instance = None

message_wait_timeout = None
custom_vehicle_id = None

state_publisher = None


def isclose(a, b, rel_tol=1e-09, abs_tol=0.0):
    return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)


class MavlinkRateCalculator(object):
    def __init__(self):
        self.__messages = None
        self.__timer = None
        self.__start_time = None
        self.__stop = None

    def measure(self, timeout):
        self.__messages = {}
        if self.__timer is not None:
            self.__timer.shutdown()
        self.__timer = rospy.Timer(rospy.Duration(timeout), self.__callback, oneshot=True)
        self.__start_time = monotonic()
        self.__stop = Event()

        while not self.__stop.is_set():
            msg = mavlink_file.recv_match(blocking=True, timeout=100)
            if msg is not None:
                if not msg.get_type() in self.__messages.keys():
                    self.__messages[msg.get_type()] = 1
                else:
                    self.__messages[msg.get_type()] += 1

        actual_time = monotonic() - self.__start_time
        for key in self.__messages.iterkeys():
            self.__messages[key] = float(self.__messages[key]) / actual_time

    def __callback(self, event):
        self.__stop.set()

    def __getitem__(self, key):
        return self.__messages[key]

    def __del__(self):
        self.__timer.shutdown()


def cs_driver_command_callback(req):
    if req.command == DriverCommandRequest.OPEN:
        state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.OPEN)
    elif req.command == DriverCommandRequest.CLOSE:
        state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.CLOSED)
    elif req.command == DriverCommandRequest.RESTORE:
        state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.OPEN)
    elif req.command == DriverCommandRequest.STOP:
        state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.UNKNOWN)
    else:
        return DriverCommandResponse(DriverCommandResponse.ERROR, 'Unknown driver command')

    return DriverCommandResponse(DriverCommandResponse.SUCCESS, '')


def setup_module(module):
    global mavlink_file
    global mavlink_instance
    global message_wait_timeout
    global custom_vehicle_id
    global state_publisher

    rospy.init_node('mavlink_test', anonymous=True)
    mavlink_file = mavutil.mavlink_connection(
        'udpin:localhost:14550',  # MAVLink URL
        source_system=rospy.get_param('~mavlink_id'),  # System source ID
        source_component=mavlink.MAV_TYPE_GCS  # System component ID
    )
    mavlink_instance = mavlink_file.mav

    # Create a command service server
    rospy.Service('{0}/command'.format(rospy.get_param('cs_mavlink/driver_node')), DriverCommand,
                  cs_driver_command_callback)
    rospy.logdebug('Created a driver command service server')

    # Creating a topic publisher for commands addressed to actuation driver with latching
    state_publisher = rospy.Publisher('{0}/state'.format(rospy.get_param('cs_mavlink/driver_node')),
                                      DriverState, queue_size=10, latch=True)
    rospy.logdebug('Publisher for a state topic ready: %s', state_publisher)

    message_wait_timeout = rospy.get_param('~message_wait_interval')
    custom_vehicle_id = rospy.get_param('~custom_vehicle_id')


@pytest.mark.order1
@pytest.mark.dependency()
def test_parameters_storage():
    assert not os.path.exists(rospy.get_param('cs_mavlink/configuration_file'))


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_regular_telemetry():
    msg = mavlink_file.recv_match(type='HEARTBEAT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert msg.type == mavlink.MAV_TYPE_CHARGING_STATION
    assert msg.base_mode == mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED
    assert msg.custom_mode in set(map(int, target.VehicleCustomMode))
    assert msg.system_status == mavlink.MAV_STATE_STANDBY

    msg = mavlink_file.recv_match(type='SYS_STATUS', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert msg.onboard_control_sensors_present == mavlink.MAV_SYS_STATUS_SENSOR_BATTERY
    assert not msg.onboard_control_sensors_enabled
    assert not msg.onboard_control_sensors_health
    assert not msg.load
    assert not msg.voltage_battery
    assert msg.current_battery == -1
    assert not msg.battery_remaining
    assert not msg.drop_rate_comm
    assert not msg.errors_comm
    assert not msg.errors_count1
    assert not msg.errors_count2
    assert not msg.errors_count3
    assert not msg.errors_count4

    assert mavlink_file.recv_match(type='BATTERY_STATUS', blocking=True, timeout=message_wait_timeout) is None
    assert mavlink_file.recv_match(type='WIND_COV', blocking=True, timeout=message_wait_timeout) is None
    assert mavlink_file.recv_match(type='SCALED_PRESSURE', blocking=True, timeout=message_wait_timeout) is None
    assert mavlink_file.recv_match(type='NAMED_VALUE_INT', blocking=True, timeout=message_wait_timeout) is None
    assert mavlink_file.recv_match(type='NAMED_VALUE_FLOAT', blocking=True, timeout=message_wait_timeout) is None


@pytest.mark.order2
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_static_telemetry():
    mavlink_coordinates = target.mavlink_coordinates(*target.STATION_COORDINATES_DEFAULT)

    msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert abs(rospy.Time.now().to_nsec() / 1000.0 - msg.time_usec) * 1e-6 <= rospy.get_param('~rates_tolerance')
    assert msg.fix_type == mavlink.GPS_FIX_TYPE_STATIC
    assert msg.lat == mavlink_coordinates[0]
    assert msg.lon == mavlink_coordinates[1]
    assert msg.alt == mavlink_coordinates[2]
    assert msg.eph == 0xFFFF
    assert msg.epv == 0xFFFF
    assert msg.vel == 0xFFFF
    assert msg.cog == 0xFFFF
    assert msg.satellites_visible == 0xFF
    assert not msg.alt_ellipsoid
    assert not msg.h_acc
    assert not msg.v_acc
    assert not msg.vel_acc
    assert not msg.hdg_acc

    mavlink_heading = target.mavlink_heading(target.STATION_HEADING_DEFAULT)

    msg = mavlink_file.recv_match(type='GLOBAL_POSITION_INT', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert msg.lat == mavlink_coordinates[0]
    assert msg.lon == mavlink_coordinates[1]
    assert msg.relative_alt == 0
    assert not msg.vx
    assert not msg.vy
    assert not msg.vz
    assert msg.hdg == mavlink_heading

    msg = mavlink_file.recv_match(type='ATTITUDE', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert not msg.roll
    assert not msg.pitch
    assert msg.yaw == mavlink_heading
    assert not msg.rollspeed
    assert not msg.pitchspeed
    assert not msg.yawspeed

    msg = mavlink_file.recv_match(type='GPS_STATUS', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1
    assert not msg.satellites_visible
    assert not any(msg.satellite_prn)
    assert not any(msg.satellite_used)
    assert not any(msg.satellite_elevation)
    assert not any(msg.satellite_azimuth)
    assert not any(msg.satellite_snr)


# @pytest.mark.skip
@pytest.mark.order3
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_rates():
    rate_tolerance = rospy.get_param('~rates_tolerance')
    telemetry_rate = rospy.get_param('cs_mavlink/telemetry_rate')
    rates = MavlinkRateCalculator()
    rates.measure(rospy.get_param('~rates_measure_interval'))
    assert isclose(rates['HEARTBEAT'], telemetry_rate, (rate_tolerance / 100))
    assert isclose(rates['SYS_STATUS'], telemetry_rate, (rate_tolerance / 100))
    assert isclose(rates['GPS_RAW_INT'], telemetry_rate, (rate_tolerance / 100))
    assert isclose(rates['GLOBAL_POSITION_INT'], telemetry_rate, (rate_tolerance / 100))
    assert isclose(rates['ATTITUDE'], telemetry_rate, (rate_tolerance / 100))
    assert isclose(rates['GPS_STATUS'], telemetry_rate, (rate_tolerance / 100))


@pytest.mark.order3
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_cs_states():
    state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.OPENING)
    assert mavlink_file.recv_match(condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPENING),
                                   blocking=True, timeout=message_wait_timeout) is not None

    state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.OPEN)
    assert mavlink_file.recv_match(condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
                                   blocking=True, timeout=message_wait_timeout) is not None

    state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.CLOSING)
    assert mavlink_file.recv_match(condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSING),
                                   blocking=True, timeout=message_wait_timeout) is not None

    state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.CLOSED)
    assert mavlink_file.recv_match(condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSED),
                                   blocking=True, timeout=message_wait_timeout) is not None

    state_publisher.publish(header=Header(stamp=rospy.Time.now()), state=DriverState.UNKNOWN)
    assert mavlink_file.recv_match(condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.UNKNOWN),
                                   blocking=True, timeout=message_wait_timeout) is not None


# @pytest.mark.skip
# @pytest.mark.order3
# @pytest.mark.dependency(depends='test_parameters_storage')
# def test_incoming_heartbeats():
#     for i in xrange(10, 20 + 1, 5):
#         rate = rospy.Rate(i)
#         start_time = monotonic()
#         while monotonic() - start_time <= 10.0:
#             mavlink_instance.heartbeat_send(
#                 mavlink.MAV_TYPE_GCS,  # Vehicle type
#                 mavlink.MAV_AUTOPILOT_INVALID,  # Autopilot type
#                 0,  # System mode bitfield
#                 0,  # Passing custom mode directly
#                 0  # System status
#             )
#             # Flush input buffer
#             mavlink_file.recv_match()
#             rate.sleep()


@pytest.mark.order3
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_incoming_heartbeat():
    mavlink_instance.heartbeat_send(
        mavlink.MAV_TYPE_GCS,  # Vehicle type
        mavlink.MAV_AUTOPILOT_INVALID,  # Autopilot type
        0,  # System mode bitfield
        0,  # Passing custom mode directly
        0  # System status
    )
    rospy.sleep(1.)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        blocking=True,
        timeout=message_wait_timeout
    ) is not None


@pytest.mark.order3
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_gqc_vehicle_protocol():
    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_REQUEST_PROTOCOL_VERSION, True, 0, 0, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_REQUEST_PROTOCOL_VERSION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    msg = mavlink_file.recv_match(type='PROTOCOL_VERSION', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.version == 200
    assert msg.min_version == 200
    assert msg.max_version == 200
    assert not any(msg.spec_version_hash)
    assert not any(msg.library_version_hash)

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES, True, 0, 0, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    msg = mavlink_file.recv_match(type='AUTOPILOT_VERSION', blocking=True, timeout=message_wait_timeout)
    assert msg is not None
    assert msg.capabilities == mavlink.MAV_PROTOCOL_CAPABILITY_MAVLINK2 or mavlink.MAV_PROTOCOL_CAPABILITY_PARAM_FLOAT
    assert msg.flight_sw_version == 1
    assert not msg.middleware_sw_version
    assert not msg.os_sw_version
    assert not any(msg.flight_custom_version)
    assert not any(msg.middleware_custom_version)
    assert not any(msg.os_custom_version)
    assert not msg.vendor_id
    assert not msg.product_id
    assert not msg.uid
    assert not any(msg.uid2)

    for component in mavlink.MAV_COMP_ID_AUTOPILOT1, mavlink.MAV_COMP_ID_MISSIONPLANNER, mavlink.MAV_COMP_ID_ALL:
        mavlink_instance.mission_request_list_send(target.MAVLINK_SYSTEM_ID_DEFAULT, component)
        msg = mavlink_file.recv_match(
            type='MISSION_COUNT',
            condition='MISSION_COUNT.target_system=={0} and MISSION_COUNT.target_component=={1}'.format(
                rospy.get_param('~mavlink_id'), mavlink.MAV_TYPE_GCS
            ),
            blocking=True,
            timeout=message_wait_timeout
        )
        assert msg is not None
        assert not msg.count
        assert msg.mission_type == mavlink.MAV_MISSION_TYPE_MISSION

        mavlink_instance.mission_ack_send(target.MAVLINK_SYSTEM_ID_DEFAULT, component, mavlink.MAV_MISSION_ACCEPTED)

        mavlink_instance.mission_count_send(target.MAVLINK_SYSTEM_ID_DEFAULT, component, 1)
        msg = mavlink_file.recv_match(
            type='MISSION_ACK',
            condition='MISSION_ACK.target_system=={0} and MISSION_ACK.target_component=={1}'.format(
                rospy.get_param('~mavlink_id'), mavlink.MAV_TYPE_GCS
            ),
            blocking=True,
            timeout=message_wait_timeout
        )
        assert msg.type == mavlink.MAV_MISSION_UNSUPPORTED
        assert msg.mission_type == mavlink.MAV_MISSION_TYPE_MISSION


@pytest.mark.order4
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_reset_parameters_and_reboot():
    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_PREFLIGHT_STORAGE, True, 2, -1, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_PREFLIGHT_STORAGE),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN, True, 1, 0, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED

    rospy.sleep(0.5)

    for i in xrange(rospy.get_param('~heartbeats_after_reboot')):
        assert mavlink_file.recv_match(
            type='HEARTBEAT',
            blocking=True,
            timeout=message_wait_timeout
        ) is not None


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_cs_control_long():
    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_MODE, True, mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                                       target.VehicleCustomMode.OPEN, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_MODE),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_MODE, True, mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                                       target.VehicleCustomMode.CLOSED, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_MODE),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSED),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_cs_control_set_mode():
    mavlink_instance.set_mode_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                                   target.VehicleCustomMode.OPEN)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.set_mode_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                                   target.VehicleCustomMode.CLOSED)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSED),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_param_protocol():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             'CONTROL', -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.CONTROL),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_int8(msg.param_value) == target.CONTROL_PARAMETER_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_INT8
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL)

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1, '',
                                             target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL))
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.CONTROL),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_int8(msg.param_value) == target.CONTROL_PARAMETER_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_INT8
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL)


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_cs_control_param():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             'CONTROL', -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.CONTROL),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_int8(msg.param_value) == target.CONTROL_PARAMETER_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_INT8
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL)

    mavlink_instance.param_set_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1, 'CONTROL',
                                    target.int8_to_float(target.ControlParameterCommand.CLOSE),
                                    mavlink.MAV_PARAM_TYPE_INT8)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSED),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             'CONTROL', -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.CONTROL),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_int8(msg.param_value) == target.CONTROL_PARAMETER_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_INT8
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL)

    mavlink_instance.param_set_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1, 'CONTROL',
                                             target.int8_to_float(target.ControlParameterCommand.OPEN),
                                             mavlink.MAV_PARAM_TYPE_INT8)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.param_set_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1, 'CONTROL',
                                    target.int8_to_float(target.ControlParameterCommand.STOP),
                                    mavlink.MAV_PARAM_TYPE_INT8)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.UNKNOWN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.param_set_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1, 'CONTROL',
                                    target.int8_to_float(target.ControlParameterCommand.RESTORE),
                                    mavlink.MAV_PARAM_TYPE_INT8)
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_cs_control_param_long():
    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_PARAMETER, True,
                                       target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL),
                                       target.int8_to_float(target.ControlParameterCommand.CLOSE), 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_PARAMETER),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED

    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.CLOSED),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_PARAMETER, True,
                                       target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL),
                                       target.int8_to_float(target.ControlParameterCommand.OPEN), 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_PARAMETER),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_PARAMETER, True,
                                       target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL),
                                       target.int8_to_float(target.ControlParameterCommand.STOP), 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_PARAMETER),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.UNKNOWN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_DO_SET_PARAMETER, True,
                                       target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.CONTROL),
                                       target.int8_to_float(target.ControlParameterCommand.RESTORE), 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_DO_SET_PARAMETER),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED
    assert mavlink_file.recv_match(
        type='HEARTBEAT',
        condition='HEARTBEAT.custom_mode=={0}'.format(target.VehicleCustomMode.OPEN),
        blocking=True,
        timeout=message_wait_timeout
    ) is not None


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_param_version():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.PARAM_VERSION, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.PARAM_VERSION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_int32(msg.param_value) == target.PARAM_VERSION_STATIC
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_INT32
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.PARAM_VERSION)

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.PARAM_VERSION,
        target.int32_to_float(123),
        mavlink.MAV_PARAM_TYPE_INT32
    )
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.PARAM_VERSION, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.PARAM_VERSION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert target.float_to_int32(msg.param_value) == target.PARAM_VERSION_STATIC


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_param_system_id():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SYSTEM_ID, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SYSTEM_ID),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert target.float_to_uint8(msg.param_value) == target.MAVLINK_SYSTEM_ID_DEFAULT
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_UINT8
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.SYSTEM_ID)

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.SYSTEM_ID,
        target.uint8_to_float(custom_vehicle_id),
        mavlink.MAV_PARAM_TYPE_UINT8
    )

    mavlink_instance.command_long_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN, True, 1, 0, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED

    heartbeat_retries = rospy.get_param('~mavlink_retries')

    passed = False
    for i in xrange(heartbeat_retries):
        msg = mavlink_file.recv_match(
            type='HEARTBEAT',
            blocking=True,
            timeout=message_wait_timeout
        )
        if msg.get_srcSystem() == custom_vehicle_id:
            passed = True
            break
    assert passed

    mavlink_instance.param_set_send(
        custom_vehicle_id,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.SYSTEM_ID,
        target.uint8_to_float(target.MAVLINK_SYSTEM_ID_DEFAULT),
        mavlink.MAV_PARAM_TYPE_UINT8
    )

    mavlink_instance.command_long_send(custom_vehicle_id, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                       mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN, True, 1, 0, 0, 0, 0, 0, 0)
    msg = mavlink_file.recv_match(
        type='COMMAND_ACK',
        condition='COMMAND_ACK.command=={0}'.format(mavlink.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert msg.result == mavlink.MAV_RESULT_ACCEPTED

    passed = False
    for i in xrange(heartbeat_retries):
        msg = mavlink_file.recv_match(
            type='HEARTBEAT',
            blocking=True,
            timeout=message_wait_timeout
        )
        if msg.get_srcSystem() == target.MAVLINK_SYSTEM_ID_DEFAULT:
            passed = True
            break
    assert passed


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
@pytest.mark.parametrize(
    'standard_coordinates,standard_heading',
    [
        ((55.703521, 37.724823, 100), 123),
        (target.STATION_COORDINATES_DEFAULT, target.STATION_HEADING_DEFAULT)
    ]
)
def test_params_pos(standard_coordinates, standard_heading):
    mavlink_coordinates = target.mavlink_coordinates(*standard_coordinates)

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.LATITUDE,
        standard_coordinates[0],
        mavlink.MAV_PARAM_TYPE_REAL32
    )
    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.LONGITUDE,
        standard_coordinates[1],
        mavlink.MAV_PARAM_TYPE_REAL32
    )
    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.ALTITUDE,
        standard_coordinates[2],
        mavlink.MAV_PARAM_TYPE_REAL32
    )
    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.HEADING,
        standard_heading,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    mavlink_retries = rospy.get_param('~mavlink_retries')

    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        current_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
        if isclose(current_coordinates[0], standard_coordinates[0], rel_tol=1e-07) and \
                isclose(current_coordinates[1], standard_coordinates[1], rel_tol=1e-7) and \
                isclose(current_coordinates[2], standard_coordinates[2]):
            passed = True
            break
    assert passed

    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='GLOBAL_POSITION_INT', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        current_coordinates = target.standard_coordinates(msg.lat, msg.lon, 0)
        if isclose(current_coordinates[0], standard_coordinates[0], rel_tol=1e-07) and \
                isclose(current_coordinates[1], standard_coordinates[1], rel_tol=1e-7) and \
                (msg.hdg // 100 == target.mavlink_heading(standard_heading) // 100):
            passed = True
            break
    assert passed

    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='ATTITUDE', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        if isclose(msg.yaw, target.mavlink_attitude_yaw(standard_heading)):
            passed = True
            break
    assert passed


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_params_survey():
    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_ACCURACY, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_ACCURACY),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert not msg.param_value
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_REAL32
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.SURVEY_IN_ACCURACY)

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.SURVEY_IN_ACCURACY,
        1.0,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_ACCURACY, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_ACCURACY),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert not msg.param_value

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_DURATION, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_DURATION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert not target.float_to_uint16(msg.param_value)
    assert msg.param_type == mavlink.MAV_PARAM_TYPE_UINT16
    assert msg.param_count == len(target.VEHICLE_PARAMETERS)
    assert msg.param_index == target.VEHICLE_PARAMETERS.keys().index(target.VehicleParameter.SURVEY_IN_DURATION)

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.SURVEY_IN_DURATION,
        target.uint16_to_float(1),
        mavlink.MAV_PARAM_TYPE_UINT16
    )

    mavlink_instance.param_request_read_send(target.MAVLINK_SYSTEM_ID_DEFAULT, mavlink.MAV_COMP_ID_AUTOPILOT1,
                                             target.VehicleParameter.SURVEY_IN_DURATION, -1)
    msg = mavlink_file.recv_match(
        type='PARAM_VALUE',
        condition="PARAM_VALUE.param_id=='{0}'".format(target.VehicleParameter.SURVEY_IN_DURATION),
        blocking=True,
        timeout=message_wait_timeout
    )
    assert msg is not None
    assert not target.float_to_uint16(msg.param_value)


@pytest.mark.order5
@pytest.mark.dependency(depends=['test_parameters_storage'])
def test_params_antenna_offset():
    mavlink_retries = rospy.get_param('~mavlink_retries')

    offset_x = 2.2

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DX,
        2.2,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    new_coordinates = target.correct_charging_station_position(target.STATION_COORDINATES_DEFAULT,
                                                               (offset_x, 0.0, 0.0), target.STATION_HEADING_DEFAULT)

    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        current_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
        if isclose(current_coordinates[0], new_coordinates[0], rel_tol=1e-07) and \
                isclose(current_coordinates[1], new_coordinates[1], rel_tol=1e-7):
            passed = True
            break
    assert passed

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DX,
        0.0,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    offset_y = -2.2

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DY,
        offset_y,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    new_coordinates = target.correct_charging_station_position(target.STATION_COORDINATES_DEFAULT,
                                                               (0.0, offset_y, 0.0), target.STATION_HEADING_DEFAULT)

    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        current_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
        if isclose(current_coordinates[0], new_coordinates[0], rel_tol=1e-07) and \
                isclose(current_coordinates[1], new_coordinates[1], rel_tol=1e-7):
            passed = True
            break
    assert passed

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DY,
        0.0,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    offset_z = 3.5

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DZ,
        offset_z,
        mavlink.MAV_PARAM_TYPE_REAL32
    )

    new_coordinates = target.correct_charging_station_position(target.STATION_COORDINATES_DEFAULT,
                                                               (0.0, 0.0, offset_z), target.STATION_HEADING_DEFAULT)
    passed = False
    for i in xrange(mavlink_retries):
        msg = mavlink_file.recv_match(type='GPS_RAW_INT', blocking=True, timeout=message_wait_timeout)
        assert msg is not None
        current_coordinates = target.standard_coordinates(msg.lat, msg.lon, msg.alt)
        if isclose(current_coordinates[2], new_coordinates[2]):
            passed = True
            break
    assert passed

    mavlink_instance.param_set_send(
        target.MAVLINK_SYSTEM_ID_DEFAULT,
        mavlink.MAV_COMP_ID_AUTOPILOT1,
        target.VehicleParameter.GPS_ANTENNA_DZ,
        0.0,
        mavlink.MAV_PARAM_TYPE_REAL32
    )


def teardown_module():
    sleep(0.5)  # Wait for some time before removing configuration file
    try:
        os.remove(rospy.get_param('cs_mavlink/configuration_file'))
    except OSError as e:
        if e.errno != 2:
            raise e
