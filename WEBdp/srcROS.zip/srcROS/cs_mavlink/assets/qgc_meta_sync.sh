#!/usr/bin/env bash

cp parameters.xml ../../../../../qgroundcontrol/src/FirmwarePlugin/ChargingStation/ChargingStationParameterFactMetaData.xml

