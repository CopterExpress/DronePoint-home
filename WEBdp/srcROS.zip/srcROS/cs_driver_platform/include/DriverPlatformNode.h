#ifndef CS_DRIVER_STATIC_NODE
#define CS_DRIVER_STATIC_NODE

#include <stdexcept>

#include <ros/ros.h>

#include <cs_driver_msgs/DriverState.h>
#include <cs_driver_srvs/DriverCommand.h>

// ROS message driver state type
using DriverNodeState = decltype(cs_driver_msgs::DriverState::state);

// Base platform driver node exception class
class DriverPlatformNodeException: public std::runtime_error
{
public:
  DriverPlatformNodeException(const std::string& what_arg);
};

// Invalid platform driver node configuration
class DriverPlatformNodeInvalidConfiguration: public DriverPlatformNodeException
{
public:
  DriverPlatformNodeInvalidConfiguration(const std::string& what_arg);
};

class DriverPlatformNode
{
  private:
    ros::NodeHandle &nh;

    ros::Publisher driverStatePub;  // Driver state topic pubisher

    ros::ServiceServer driverCommandService;  // Driver command service server
    // Driver command service server callback
    bool driverCommandServiceCallback(
      cs_driver_srvs::DriverCommand::Request &request,
      cs_driver_srvs::DriverCommand::Response &response
    );
  public:
    /* Static driver node constructor.
    * nh - ROS node handle.
    */
    DriverPlatformNode(ros::NodeHandle &nh);

    void run();
};

#endif  // CS_DRIVER_STATIC_NODE
