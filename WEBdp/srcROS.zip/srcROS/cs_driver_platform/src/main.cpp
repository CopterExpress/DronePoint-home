#include <ros/ros.h>

#include "DriverPlatformNode.h"

int main(int argc, char **argv)
{
  // Set up ROS
  ros::init(argc, argv, "cs_driver_platform");

  ros::NodeHandle privateNodeHandle("~");
  DriverPlatformNode node(privateNodeHandle);

  ROS_DEBUG("Node started");
  node.run();

  ROS_INFO("Node stopped");
  return 0;
}
