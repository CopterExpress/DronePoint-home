#include <unordered_map>
#include <algorithm>
#include <string>

#include <ros/console.h>
#include <ros/ros.h>

#include "DriverPlatformNode.h"

DriverPlatformNodeException::DriverPlatformNodeException(const std::string& what_arg)
: std::runtime_error(what_arg)
{
}

DriverPlatformNodeInvalidConfiguration::DriverPlatformNodeInvalidConfiguration(const std::string& what_arg)
: DriverPlatformNodeException(what_arg)
{
}

// Constant bindings for the charging station states
static const std::unordered_map<std::string, const DriverNodeState> chargingStationStatesMap =
{
  {"UNKNOWN", cs_driver_msgs::DriverState::UNKNOWN},
  {"OPEN", cs_driver_msgs::DriverState::OPEN},
  {"OPENING", cs_driver_msgs::DriverState::OPENING},
  {"CLOSED", cs_driver_msgs::DriverState::CLOSED},
  {"CLOSING", cs_driver_msgs::DriverState::CLOSING},
  {"ERROR", cs_driver_msgs::DriverState::ERROR}
};

DriverPlatformNode::DriverPlatformNode(ros::NodeHandle &nh)
: nh(nh)  // Copy a reference to a ROS node handle
// Create charging station state publisher
, driverStatePub(this->nh.advertise<cs_driver_msgs::DriverState>("state", 10, true))
// Create charging station driver command service
, driverCommandService(this->nh.advertiseService("command",
  &DriverPlatformNode::driverCommandServiceCallback, this))
{
  bool debug;

  nh.param("debug", debug, false);

  // Set a log verbosity level
  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
      (debug) ? ros::console::levels::Debug : ros::console::levels::Info))
    ros::console::notifyLoggerLevelsChanged();

  if (debug)
    ROS_DEBUG("Debug mode enabled");

  std::string staticStateStr;  // Static charging station state string value

  nh.param("static_state", staticStateStr, std::string("OPEN"));

  // Convert string to the upper case
  std::transform(staticStateStr.begin(), staticStateStr.end(), staticStateStr.begin(), ::toupper);

  // Look for the active state binding
  auto stateIter = chargingStationStatesMap.find(staticStateStr);

  // A binding doesn't exists
  if (stateIter == chargingStationStatesMap.end())
    throw DriverPlatformNodeInvalidConfiguration("Unknown charging station state: \"" + staticStateStr +'"');

  ROS_DEBUG("Static charging station state: \"%s\"", staticStateStr.c_str());

  // Publish a static state
  cs_driver_msgs::DriverState msg;
  msg.header.stamp = ros::Time::now();
  msg.state = stateIter->second;
  driverStatePub.publish(msg);
  ROS_INFO("Static state has been published");
}

void DriverPlatformNode::run()
{
  ros::spin();
}

bool DriverPlatformNode::driverCommandServiceCallback(cs_driver_srvs::DriverCommand::Request &request,
  cs_driver_srvs::DriverCommand::Response &response)
{
  // Return a static response
  response.result = cs_driver_srvs::DriverCommand::Response::ERROR;
  response.message = "Unsupported by a landing platform";
  return true;
}
