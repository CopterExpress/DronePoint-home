#include <ros/ros.h>
#include <ros/console.h>

#include "cs_gps_ubx_rtcm_node.h"

int main(int argc, char **argv)
{
  // Set up ROS
  ros::init(argc, argv, "cs_gps_ubx_rtcm");

  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug))
  {
    ros::console::notifyLoggerLevelsChanged();
  }

  ROS_DEBUG("Node has been initialized");

  ros::NodeHandle privateNodeHandle("~");

  ROS_DEBUG("Node handle has been received");

  ubxRtcmNode node(privateNodeHandle);

  // Let ROS handle all callbacks
  ros::spin();

  ROS_INFO("Node stop");

  return 0;
}
