#include <exception>
#include <thread>
#include <atomic>
#include <functional>
#include <iostream>
#include <unordered_map>
#include <algorithm>
#include <cstdio>
#include <limits>

#include <serial/serial.h>

#include <rapidjson/document.h>
#include <rapidjson/error/error.h>
#include <rapidjson/error/en.h>
#include <rapidjson/filereadstream.h>
#include <rapidjson/filewritestream.h>
#include <rapidjson/prettywriter.h>

#include "ubx.h"

#include "cs_gps_ubx_rtcm_node.h"

// Timeout between regular PX4 UBX/RTCM3 driver receive calls
#define GPS_RECEIVE_TIMEOUT 1200

// Maximum PX4 UBX/RTCM3 driver timeout before read
#define GPS_WAIT_BEFORE_READ_MAX  50

// static void ros_data_dump(void *data, size_t len)
// {
//   if (!len)
//     return;

//   static std::stringstream debugMessageStream;

//   debugMessageStream << "DATA DUMP: ";
//   for (int i = 0; i < len; i++)
//     debugMessageStream << std::uppercase << std::setfill('0') << std::setw(2) << std::hex
//       << (int)*((uint8_t *)data + i) << ' ';
//   ROS_DEBUG("%s", debugMessageStream.str().c_str());
//   debugMessageStream.str("");
// }

ubxRtcmNodeException::ubxRtcmNodeException(const std::string& what_arg)
: std::runtime_error(what_arg)
{
}

ubxRtcmNodeConfigSaveFailed::ubxRtcmNodeConfigSaveFailed(const std::string& what_arg)
: ubxRtcmNodeException(what_arg)
{
}

int ubxRtcmNode::gpsCallback(GPSCallbackType type, void *data1, int data2, void *user)
{
  static ubxRtcmNode *node;

  node = static_cast<ubxRtcmNode *>(user);  // User pointer is a calling ubxRtcmNode *

  // Depending on the callback type
  switch (type)
  {
    /* Serial port read request
    * data1: points to a buffer to be written to. The first sizeof(int) bytes contain the
	  *        timeout in ms when calling the method.
	  * data2: buffer length in bytes. Less bytes than this can be read.
	  * return: num read bytes, 0 on timeout (the method can actually also return 0 before
	  *         the timeout happens).
    */
    case GPSCallbackType::readDeviceData:
      // ROS_DEBUG("Read request: buffer size = %i byte(s), timeout = %i ms", data2,
      //   node->gpsCallbackTimeouts.read_timeout_constant);

      // Retrieve a requested read timeout from data1 pointer
      node->gpsCallbackTimeouts.read_timeout_constant = *static_cast<uint32_t *>(data1);

      // Limit read timeout (implemented in PX4)
      if (node->gpsCallbackTimeouts.read_timeout_constant > GPS_WAIT_BEFORE_READ_MAX)
        node->gpsCallbackTimeouts.read_timeout_constant = GPS_WAIT_BEFORE_READ_MAX;

      // Set new serial library timeouts
      node->ublox_serial->setTimeout(node->gpsCallbackTimeouts);

      // Read data from a serial port with timeout (has been set before), if timeout
      //  happens read as much data as possible
      return static_cast<int>(node->ublox_serial->read(static_cast<uint8_t *>(data1),
        static_cast<size_t>(data2)));
    /*
    * Write data to device
    * data1: data to be written
    * data2: number of bytes to write
    * return: num written bytes
    */
    case GPSCallbackType::writeDeviceData:
      // ROS_INFO("Actually written: %i byte(s)", recieved);
      
      // Write data to the serial port, return number of bytes that were actually written
      return static_cast<int>(node->ublox_serial->write(
        static_cast<const uint8_t *>(data1), static_cast<size_t>(data2)));
    /*
    * Serial port baudrate set requested
    * data1: ignored
    * data2: baudrate
    * return: 0 on success
    */
    case GPSCallbackType::setBaudrate:
      {
        ROS_DEBUG("Baudrate set request: %i", data2);

        try
        {
          // Set the serial port baudrate
          node->ublox_serial->setBaudrate(static_cast<uint32_t>(data2));
          
          ROS_DEBUG("Baudrate was set successfully");
          return 0;  // Success
        }
        // Failed to set the requested baudrate (it's actually normal, PX4 UBX/RTCM driver
        //  will try to set another one)
        catch (const serial::SerialException &e)
        {
          ROS_ERROR("Failed to set a serial port baudrate");
          return -1;  // Failed
        }
      }
    /**
     * RTCM message was recieved
     * data1: pointer to the message (just a data block)
     * data2: message length
     * return: ignored
     */
    case GPSCallbackType::gotRTCMMessage:
      {
        // ROS_DEBUG("RTCM Message");

        // Set a message timestamp
        node->rtcmMessage.header.stamp = ros::Time::now();

        // Resize the internal std::vector data buffer
        node->rtcmMessage.data.resize(static_cast<std::size_t>(data2));

        // Copy RTCM message from PX4 UBX/RTCM data buffer to the std::vector buffer
        std::memcpy(static_cast<void *>(node->rtcmMessage.data.data()),
          data1, static_cast<std::size_t>(data2));

        // Publish the resulting ROS message
        node->rtcmDataPublisher.publish(node->rtcmMessage);

        // Clear the std::vector buffer
        node->rtcmMessage.data.clear();
      }
      break;
    /**
    * Survey-in status was recieved
    * data1: points to a SurveyInStatus struct
    * data2: ignored
    * return: ignored
    */
    case GPSCallbackType::surveyInStatus:
      {
        static SurveyInStatus *status;

        // data1 points to SurveyInStatus
        status = static_cast<SurveyInStatus *>(data1);

        // Set a message timestamp
        node->surveyInMessage.header.stamp = ros::Time::now();

        // Calculate mean accuracy in meters
        node->surveyInMessage.mean_accuracy = static_cast<double>(status->mean_accuracy) / 1000;

        // Copy servey-in duration
        node->surveyInMessage.duration = status->duration;

        // Get a servey-in active flag from a bitmask
        node->surveyInMessage.active = static_cast<bool>(status->flags & (1 << 1));

        // Get a servey-in valid flag from a bitmask
        node->surveyInMessage.valid = static_cast<bool>(status->flags & (1 << 0));

        // Publish the resulting ROS message
        node->surveyInPublisher.publish(node->surveyInMessage);

        //ROS_DEBUG("Survey-in status");
      }
      break;
    /**
	  * can be used to set the current clock accurately
	  * data1: pointer to a timespec struct
	  * data2: ignored
	  * return: ignored
	  */
    case GPSCallbackType::setClock:
      //ROS_DEBUG("Clock set request");
      break;
  }

  return 0;  // Success
}

// Charging station UBX/RTCM node thread loop
void ubxRtcmNode::nodeThreadLoop()
{
  // Work until the node thread stop request flag is set
  while (!this->nodeThreadStop)
  {
    // Ask PX4 UBX/RTCM node to parse incoming data from the module, if no new data wait for
    //  a selected timeout
    // TODO: An exception handling should be implemented!
    int helperRet = this->ublox_driver->receive(GPS_RECEIVE_TIMEOUT);

    // Vehicle GPS position was updated
    if (helperRet & (1 << 0))
    {
      //ROS_INFO("GPS Position ready");

      // Set a message timestamp
      vehicleGpsPositionMessage.header.stamp = ros::Time::now();

      // Copy all fields line by line
      // FIXME: It should be a better way to do that. std::memcpy not a solution: we can
      // FIXME: change a field set or the field content.
      vehicleGpsPositionMessage.time_utc_usec = this->gpsPos.time_utc_usec;
      vehicleGpsPositionMessage.lat = this->gpsPos.lat;
      vehicleGpsPositionMessage.lon = this->gpsPos.lon;
      vehicleGpsPositionMessage.alt = this->gpsPos.alt;
      vehicleGpsPositionMessage.alt_ellipsoid = this->gpsPos.alt_ellipsoid;
      vehicleGpsPositionMessage.s_variance_m_s = this->gpsPos.s_variance_m_s;
      vehicleGpsPositionMessage.eph = this->gpsPos.eph;
      vehicleGpsPositionMessage.epv = this->gpsPos.epv;
      vehicleGpsPositionMessage.hdop = this->gpsPos.hdop;
      vehicleGpsPositionMessage.vdop = this->gpsPos.vdop;
      vehicleGpsPositionMessage.noise_per_ms = this->gpsPos.noise_per_ms;
      vehicleGpsPositionMessage.jamming_indicator = this->gpsPos.jamming_indicator;
      vehicleGpsPositionMessage.vel_m_s = this->gpsPos.vel_m_s;
      vehicleGpsPositionMessage.vel_n_m_s = this->gpsPos.vel_n_m_s;
      vehicleGpsPositionMessage.vel_e_m_s = this->gpsPos.vel_e_m_s;
      vehicleGpsPositionMessage.vel_d_m_s = this->gpsPos.vel_d_m_s;
      vehicleGpsPositionMessage.cog_rad = this->gpsPos.cog_rad;
      vehicleGpsPositionMessage.timestamp_time_relative = this->gpsPos.timestamp_time_relative;
      vehicleGpsPositionMessage.fix_type = this->gpsPos.fix_type;
      vehicleGpsPositionMessage.vel_ned_valid = this->gpsPos.vel_ned_valid;
      vehicleGpsPositionMessage.satellites_used = this->gpsPos.satellites_used;

      // Publish the resulting ROS message
      this->vehicleGpsPositionPublisher.publish(vehicleGpsPositionMessage);
    }

    // Satellite information was updated
    if (helperRet & (1 << 1))
    {
      //ROS_INFO("Sat info ready");

      // Set a message timestamp
      satelliteInformationMessage.header.stamp = ros::Time::now();

      // Copy fields line by line
      satelliteInformationMessage.count = this->satInfo.count;

      // Copy data from a C array to the boost::array buffer
      // TODO: Is there a way to get boost::array size in bytes to implement std::memcpy_s?
      std::memcpy(static_cast<void *>(satelliteInformationMessage.svid.data()),
        static_cast<void *>(this->satInfo.svid), sizeof(this->satInfo.svid));

      // Copy data from a C array to the boost::array buffer
      // TODO: Is there a way to get boost::array size in bytes to implement std::memcpy_s?
      std::memcpy(static_cast<void *>(satelliteInformationMessage.used.data()),
        static_cast<void *>(this->satInfo.used), sizeof(this->satInfo.used));

      // Copy data from a C array to the boost::array buffer
      // TODO: Is there a way to get boost::array size in bytes to implement std::memcpy_s?
      std::memcpy(static_cast<void *>(satelliteInformationMessage.elevation.data()),
        static_cast<void *>(this->satInfo.elevation), sizeof(this->satInfo.elevation));

      // Copy data from a C array to the boost::array buffer
      // TODO: Is there a way to get boost::array size in bytes to implement std::memcpy_s?
      std::memcpy(static_cast<void *>(satelliteInformationMessage.azimuth.data()),
        static_cast<void *>(this->satInfo.azimuth), sizeof(this->satInfo.azimuth));

      // Copy data from a C array to the boost::array buffer
      // TODO: Is there a way to get boost::array size in bytes to implement std::memcpy_s?
      std::memcpy(static_cast<void *>(satelliteInformationMessage.snr.data()),
        static_cast<void *>(this->satInfo.snr), sizeof(this->satInfo.snr));

      // Publish the resulting ROS message
      this->satelliteInfoPublisher.publish(satelliteInformationMessage);
    }

    // Node thread reconfigure request is not empty
    if (nodeThreadReconfigureRequest)
    {
      // Set PX4 UBX/RTCM driver survey-in parameters
      ublox_driver->setSurveyInSpecs(
        round(this->surveyInAccuracy * 10000), this->surveyInDuration);
      ROS_DEBUG("New ublox survey-in parameters have been set");

      // New module baudrate
      unsigned int moduleBaudrate;

      if (ublox_driver->configure(moduleBaudrate, GPSDriverUBX::OutputMode::RTCM,
        true) < 0)
      {
        // Set a negative promise result
        this->nodeThreadReconfigurePromise.set_value(false);
        ROS_DEBUG("Failed to restart survey-in");
      
        continue;  // Continue the thread execution
		  };

      ROS_DEBUG("ublox module has been reconfigured with a baudrate: %u",
        moduleBaudrate);

      // Set false to prevent multiple reconfigure for the same request
      this->nodeThreadReconfigureRequest = false;

      // Set a positive promise result
      this->nodeThreadReconfigurePromise.set_value(true);
      ROS_DEBUG("Module reconfigured");
    }
  }
}

// Constant bindings for rosparam values
static const std::unordered_map<int, serial::bytesize_t> byteSizeMap =
{
  {5, serial::fivebits},
  {6, serial::sixbits},
  {7, serial::sevenbits},
  {8, serial::eightbits}
};

static const std::unordered_map<std::string, serial::parity_t> parityMap =
{
  {"n", serial::parity_none},
  {"o", serial::parity_odd},
  {"e", serial::parity_even}
};

static const std::unordered_map<std::string, serial::stopbits_t> stopBitsMap =
{
  {"1", serial::stopbits_one},
  {"1.5", serial::stopbits_one_point_five},
  {"2", serial::stopbits_two}
};

static const std::unordered_map<std::string, serial::flowcontrol_t> flowControlMap =
{
  {"n", serial::flowcontrol_none},
  {"s", serial::flowcontrol_software},
  {"h", serial::flowcontrol_hardware}
};
//

const size_t ubxRtcmNode::jsonConfigurationBufferSize = 2048;

const unsigned int ubxRtcmNode::jsonConfigurationIndentCount = 2;

const float ubxRtcmNode::surveyInAccuracyDefault = 5.0;
const uint32_t ubxRtcmNode::surveyInDurationDefault = 300;

const float ubxRtcmNode::surveyInAccuracyLimitMax =
  std::floor(std::numeric_limits<uint32_t>::max() / 10000.0);

const std::string ubxRtcmNode::surveyInAccuracyConfigKey = "survey_in_accuracy";
const std::string ubxRtcmNode::surveyInDurationConfigKey = "survey_in_duration";

ubxRtcmNode::ubxRtcmNode(ros::NodeHandle &nh)
: nh(nh)  // Copy a reference to a ROS node handle
, gpsPos()  // Fill vehicle GPS position structure with zeros
, satInfo()  // Fill satellite information structure with zeros
  // Prepare timeouts structure for wjwwood/serial library (unlimited interbyte timeout and
  //  and unlimited timeout for writing)
, gpsCallbackTimeouts(serial::Timeout::max(), 0, 0, serial::Timeout::max(), 0)
  // Initialise node thread stop request flag
, nodeThreadStop(false)
  // Create RTCM data ROS publisher
, rtcmDataPublisher(this->nh.advertise<cs_gps_msgs::Rtcm>("rtcm", 10))
  // Create survey-in status ROS publisher
, surveyInPublisher(this->nh.advertise<cs_gps_msgs::SurveyIn>("survey_in", 10, true))
  // Create vehicle GPS position ROS publisher
, vehicleGpsPositionPublisher(
    this->nh.advertise<cs_gps_msgs::VehicleGpsPosition>("vehicle_gps_position", 10))
  // Create satellite information ROS publisher
, satelliteInfoPublisher(
    this->nh.advertise<cs_gps_msgs::SatelliteInformation>("satellite_information", 10))
, restartSurveyInService(this->nh.advertiseService("restart_survey_in",
    &ubxRtcmNode::restartSurveyInServiceCallback, this))
, getSurveyInParametersService(this->nh.advertiseService("get_survey_in_parameters",
    &ubxRtcmNode::getSurveyInParametersServiceCallback, this))
, setSurveyInParametersService(this->nh.advertiseService("set_survey_in_parameters",
    &ubxRtcmNode::setSurveyInParametersServiceCallback, this))
, resetSurveyInParametersService(this->nh.advertiseService("reset_survey_in_parameters",
    &ubxRtcmNode::resetSurveyInParametersServiceCallback, this))
  // Initial node thread request value
, nodeThreadReconfigureRequest(false)
{
  this->vehicleGpsPositionMessage.header.seq = 0;
  this->vehicleGpsPositionMessage.header.frame_id = "";

  this->satelliteInformationMessage.header.seq = 0;
  this->satelliteInformationMessage.header.frame_id = "";

  this->rtcmMessage.header.seq = 0;
  this->rtcmMessage.header.frame_id = "";

  this->surveyInMessage.header.seq = 0;
  this->surveyInMessage.header.frame_id = "";

  std::string serialPort;

  if (!nh.getParam("serial_port", serialPort))
    throw std::runtime_error("No serial port presented!");

  ROS_DEBUG("Serial port: \"%s\"", serialPort.c_str());

  int byteSizeParamValue;  // Serial port byte size parameter value

  // Load from a ROS parameter
  nh.param("serial_port_byte_size", byteSizeParamValue, 8);

  // Look for the ROS parameter value binding
  auto byteSizeIter = byteSizeMap.find(byteSizeParamValue);

  // Binding doesn't exists
  if (byteSizeIter == byteSizeMap.end())
    throw std::runtime_error("Unknown serial port bytes size: " +
      std::to_string(byteSizeParamValue));

  ROS_DEBUG("Serial port byte size: %i", byteSizeParamValue);

  std::string parityParamValue;  // Serial port prity parameter value

  // Load from a ROS parameter
  nh.param("serial_port_parity", parityParamValue, std::string("n"));

  // Convert string to the lower case
  std::transform(parityParamValue.begin(), parityParamValue.end(), parityParamValue.begin(),
    ::tolower);

  // Look for a ROS parameter value binding
  auto parityIter = parityMap.find(parityParamValue);

  // Binding doesn't exists
  if (parityIter == parityMap.end())
    throw std::runtime_error("Unknown parity: \"" + parityParamValue +'"');

  ROS_DEBUG("Serial port parity: \"%s\"", parityParamValue.c_str());

  std::string stopBitsParamValue;  // Serial port stop bits parameter value

  // Load from a ROS parameter
  nh.param("serial_port_stop_bits", stopBitsParamValue, std::string("1"));

  // Convert string to the lower case
  std::transform(stopBitsParamValue.begin(), stopBitsParamValue.end(), stopBitsParamValue.begin(),
    ::tolower);

  // Look for the ROS parameter value binding
  auto stopBitsIter = stopBitsMap.find(stopBitsParamValue);

  // Binding doesn't exists
  if (stopBitsIter == stopBitsMap.end())
    throw std::runtime_error("Unknown stop bits value: \"" + stopBitsParamValue +'"');

  ROS_DEBUG("Serial port stop bits: %s", stopBitsParamValue.c_str());

  std::string flowControlParamValue;  // Serial port flow control parameter value

  // Load from a ROS parameter
  nh.param("serial_port_flow_control", flowControlParamValue, std::string("n"));

  // Convert string to the lower case
  std::transform(flowControlParamValue.begin(), flowControlParamValue.end(),
    flowControlParamValue.begin(), ::tolower);

  // Look for the ROS parameter value binding
  auto flowControlIter = flowControlMap.find(flowControlParamValue);

  // Binding doesn't exists
  if (flowControlIter == flowControlMap.end())
    throw std::runtime_error("Unknown flow control: \"" + flowControlParamValue +'"');

  ROS_DEBUG("Serial port flow control: \"%s\"", flowControlParamValue.c_str());

  bool surveyInNeeded;

  // Load from a ROS parameter
  nh.param("survey_in", surveyInNeeded, true);

  ROS_DEBUG("Survey-in needed: %s", surveyInNeeded ? "true" : "false");

  // Load configuration file path from a ROS parameter
  if (!nh.getParam("configuration_file", this->configurationFileName))
    throw std::runtime_error("Configuration file path is not set!");

  ROS_DEBUG("Configuration file: %s", this->configurationFileName.c_str());
  
  // Open configuration file for reading
  // HINT: rapidjson::IStreamWrapper always throws "Resource temporarily unavailable"
  // HINT: trying to read ifstream (no problems reading to the buffer without rapidjson).
  std::FILE* configurationFile = std::fopen(this->configurationFileName.c_str(), "rb");

  if (!configurationFile)  // Failed to open file
  {
    ROS_ERROR("Failed to open configuration file: \"%s\". Loading defaults.",
      strerror(errno));

    this->surveyInAccuracy = ubxRtcmNode::surveyInAccuracyDefault;
    this->surveyInDuration = ubxRtcmNode::surveyInDurationDefault;
  }
  else  // File was open successfully
  {
    ROS_DEBUG("Configuration file was open");

    // Buffer for rapidjson::FileReadStream
    char buffer[ubxRtcmNode::jsonConfigurationBufferSize];

    // Create rapidjson::FileReadStream
    rapidjson::FileReadStream configurationFileStream(configurationFile, buffer,
      sizeof(buffer));
    
    // JSON document instance
    rapidjson::Document configurationFileJson;

    // Parse file content from the file read stream
    rapidjson::ParseResult ok =
      configurationFileJson.ParseStream(configurationFileStream);

    if (!ok)  // Failed to parse data
    {
      ROS_ERROR("JSON parse error: \"%s\" (%zu). Loading defaults.",
        rapidjson::GetParseError_En(ok.Code()), ok.Offset());

      // Close configuration file
      std::fclose(configurationFile);
      ROS_DEBUG("Configuration file was closed");
      
      this->surveyInAccuracy = ubxRtcmNode::surveyInAccuracyDefault;
      this->surveyInDuration = ubxRtcmNode::surveyInDurationDefault;
    }
    else
    {
      ROS_DEBUG("Configuration file was parsed");

      // Close configuration file
      std::fclose(configurationFile);
      ROS_DEBUG("Configuration file was closed");

      // Check if the survey-in accuracy record is presented and it has a valid type
      if (configurationFileJson.HasMember(ubxRtcmNode::surveyInAccuracyConfigKey) &&
        configurationFileJson[ubxRtcmNode::surveyInAccuracyConfigKey].IsFloat())
      {
        // Extract value from the JSON document
        this->surveyInAccuracy = 
          configurationFileJson[ubxRtcmNode::surveyInAccuracyConfigKey].GetFloat();

        // Integrity check
        if ((this->surveyInAccuracy <= 0) ||
          (this->surveyInAccuracy > ubxRtcmNode::surveyInAccuracyLimitMax))
        {
          ROS_ERROR("Invalid configuration file value. Survey-in accuracy has to be "
                    "greater than zero and less than %f! Loading default.",
                    ubxRtcmNode::surveyInAccuracyLimitMax);

          this->surveyInAccuracy = ubxRtcmNode::surveyInAccuracyDefault;
        }
      }
      else  // No record presented or it has an invalid type
      {
        ROS_ERROR("No survey-in accuracy record in the configuration file or it has an "
                  "invalid type. Loading default.");

        this->surveyInAccuracy = ubxRtcmNode::surveyInAccuracyDefault;
      }

      // Check if the survey-in duration record is presented and it has a valid type
      if (configurationFileJson.HasMember(ubxRtcmNode::surveyInDurationConfigKey) &&
        configurationFileJson[ubxRtcmNode::surveyInDurationConfigKey].IsUint())
      {
        // Extract value from the JSON document
        this->surveyInDuration = static_cast<uint32_t>(
          configurationFileJson[ubxRtcmNode::surveyInDurationConfigKey].GetUint());

        // Integrity check
        if (!this->surveyInDuration)
        {
          ROS_ERROR("Invalid configuration file value. Survey-in duration has to be greater "
                    "than zero!");

          this->surveyInDuration = ubxRtcmNode::surveyInDurationDefault;
        }
      }
      else  // No record presented or it has an invalid type
      {
        ROS_ERROR("No survey-in duration record in the configuration file or it has an "
                  "invalid type. Loading default.");

        this->surveyInDuration = ubxRtcmNode::surveyInDurationDefault;
      }
    }
  }

  ROS_DEBUG("Survey-in accuracy: %f", this->surveyInAccuracy);
  
  ROS_DEBUG("Survey-in duration: %i", this->surveyInDuration);

  // Create a wjwwood/serial library serial port instance dynamically
  // HINT: PX4 UBX driver sets serial port baudrate automatically
  this->ublox_serial = new serial::Serial(serialPort, 9600, this->gpsCallbackTimeouts,
    byteSizeIter->second, parityIter->second, stopBitsIter->second,
    flowControlIter->second);

  try
  {
    // Cteate PX4 UBX/RTCM driver instance dynamically
    this->ublox_driver = new GPSDriverUBX(GPSDriverUBX::Interface::UART,
      &ubxRtcmNode::gpsCallback, this, &this->gpsPos, &this->satInfo);
  }
  catch(...)  // In case of any exception
  {
    // Delete the dynamically allocated wjwwood/serial library serial port instance
    delete this->ublox_serial;

    throw;  // Pass the exception further 
  }

  // Set PX4 UBX/RTCM driver survey-in parameters
  ublox_driver->setSurveyInSpecs(static_cast<uint32_t>(
      round(this->surveyInAccuracy * 10000)),
    this->surveyInDuration);
  ROS_DEBUG("ublock survey-in parameters have been set");

  // Autoconfigured ublox module baudrate will be placed here
  unsigned int moduleBaudrate;

  try
  {
    // Configure PX4 UBX/RTCM driver in RTCM mode
    if (ublox_driver->configure(moduleBaudrate, GPSDriverUBX::OutputMode::RTCM,
        surveyInNeeded))
      throw std::runtime_error("Failed to configure ublox module!");
  }
  catch(...)  // In case of any exception
  {
    // Delete the dynamically allocated PX4 UBX/RTCM driver instance
    delete this->ublox_driver;

    // Delete the dynamically allocated wjwwood/serial library serial port instance
    delete this->ublox_serial;

    throw;  // Pass the exception further 
  }

  ROS_DEBUG("ublox module has been configured with a baudrate: %u", moduleBaudrate);

  // Dynamically create a node thread
  nodeThread = new std::thread(&ubxRtcmNode::nodeThreadLoop, this);
}

bool ubxRtcmNode::restartSurveyInServiceCallback(
  std_srvs::Trigger::Request &request,
  std_srvs::Trigger::Response &response)
{
  ROS_DEBUG("Survey in restart service call");

  response.success = false;

  // We can't restart survey in module if node thread stop request is set
  if (this->nodeThreadStop)
  {
    response.message = "Node thread is going to stop";

    ROS_ERROR("%s!", response.message.c_str());

    return true;
  }

  // Retrieve a future from the promise
  auto nodeThreadReconfigureFuture = this->nodeThreadReconfigurePromise.get_future();

  // Set node reconfigure request (it will start a reconfiguration process)
  this->nodeThreadReconfigureRequest = true;

  // Wait until reconfiguration process is finished
  if (!nodeThreadReconfigureFuture.get())
  {
    response.message = "Failed to reconfigure module";

    ROS_ERROR("%s!", response.message.c_str());

    return true;
  }

  // Reset promise
  this->nodeThreadReconfigurePromise = std::promise<bool>();

  ROS_DEBUG("Survey in restart service call has finished");

  response.success = true;

  return true;
}

bool ubxRtcmNode::getSurveyInParametersServiceCallback(
  cs_gps_srvs::GetSurveyInParameters::Request &request,
  cs_gps_srvs::GetSurveyInParameters::Response &response)
{
  ROS_DEBUG("Get survey-in parameters service call");

  response.success = false;

  response.accuracy = 0;
  response.duration = 0;

  // We can't get survey in parameters if the node thread stop request is set
  if (this->nodeThreadStop)
  {
    response.message = "Node thread is going to stop";

    ROS_ERROR("%s!", response.message.c_str());

    return true;
  }

  response.accuracy = this->surveyInAccuracy;
  response.duration = this->surveyInDuration;

  ROS_DEBUG("Get survey-in parameters service call has finished");

  response.success = true;

  return true;
}

void ubxRtcmNode::saveSurveyInParameters(float accuracy, uint32_t duration)
{
  // Open configuration file for writing
  std::FILE* configurationFile = std::fopen(this->configurationFileName.c_str(), "wb");

  if (!configurationFile)  // Failed to open the configuration file
    throw ubxRtcmNodeConfigSaveFailed(std::string("Failed to open configuration file: ") +
      strerror(errno));

  ROS_DEBUG("Confguration file was open");

  // Buffer for rapidjson::FileWriteStream
  char buffer[ubxRtcmNode::jsonConfigurationBufferSize];

  // Create a write file stream
  rapidjson::FileWriteStream configurationFileStream(configurationFile, buffer,
    sizeof(buffer));

  // Prepare a human-readable JSON writer
  rapidjson::PrettyWriter<rapidjson::FileWriteStream>
    configurationFileWriter(configurationFileStream);

  // Set the JSON writer indent
  configurationFileWriter.SetIndent(' ', ubxRtcmNode::jsonConfigurationIndentCount);
  
  // JSON document instance
  rapidjson::Document configurationFileJson;

  // Switch JSON document to the onject mode
  configurationFileJson.SetObject();

  // Extract JSOn document allocator
  rapidjson::Document::AllocatorType& allocator = configurationFileJson.GetAllocator();

  // Create a key for a new record
  rapidjson::Value surveyInAccuracyConfigKeyValue(
    ubxRtcmNode::surveyInAccuracyConfigKey, allocator);

  // Add the record
  configurationFileJson.AddMember(surveyInAccuracyConfigKeyValue,
    accuracy, allocator);

  // Create a key for a new record
  rapidjson::Value surveyInDurationConfigKeyValue(
    ubxRtcmNode::surveyInDurationConfigKey, allocator);

  // Add the record
  configurationFileJson.AddMember(surveyInDurationConfigKeyValue,
    duration, allocator);

  // Write JSON content to the configuration file
  if (!configurationFileJson.Accept(configurationFileWriter))
  {
    // Close configuration file
    std::fclose(configurationFile);
    ROS_DEBUG("Confguration file was closed");

    throw ubxRtcmNodeConfigSaveFailed("Failed to write JSON content to the file");
  }

  ROS_DEBUG("Confguration file was updated");

  // Close configuration file
  std::fclose(configurationFile);
  ROS_DEBUG("Confguration file was closed");
}

bool ubxRtcmNode::setSurveyInParametersServiceCallback(
  cs_gps_srvs::SetSurveyInParameters::Request &request,
  cs_gps_srvs::SetSurveyInParameters::Response &response)
{
  ROS_DEBUG("Set survey-in parameters service call: %f, %u", request.accuracy,
    request.duration);

  response.success = false;

  // We can't set survey in parameters if node thread stop request is set
  if (this->nodeThreadStop)
  {
    response.message = "Node thread is going to stop";

    ROS_ERROR("%s!", response.message.c_str());

    return true;
  }

  try
  {
    // Save parameters to the configuration file
    saveSurveyInParameters(request.accuracy, request.duration);
  }
  catch (const ubxRtcmNodeConfigSaveFailed &e)  // Failed to save
  {
    response.message = "UBX/RTCM node failed to save configuration file";

    ROS_ERROR("%s!", e.what());

    return true;
  }

  // Update values in memory
  this->surveyInAccuracy = request.accuracy;
  this->surveyInDuration = request.duration;

  ROS_DEBUG("Set survey-in parameters service call has finished");

  response.success = true;

  return true;
}

bool ubxRtcmNode::resetSurveyInParametersServiceCallback(
  cs_gps_srvs::ResetSurveyInParameters::Request &request,
  cs_gps_srvs::ResetSurveyInParameters::Response &response)
{
  ROS_DEBUG("Reset survey-in parameters service call");

  response.success = false;

  response.accuracy = ubxRtcmNode::surveyInAccuracyDefault;
  response.duration = ubxRtcmNode::surveyInDurationDefault;

  // We can't reset survey in parameters if node thread stop request is set
  if (this->nodeThreadStop)
  {
    response.message = "Node thread is going to stop";

    ROS_ERROR("%s!", response.message.c_str());

    return true;
  }

  try
  {
    // Save parameters to the configuration file
    saveSurveyInParameters(ubxRtcmNode::surveyInAccuracyDefault,
      ubxRtcmNode::surveyInDurationDefault);
  }
  catch (const ubxRtcmNodeConfigSaveFailed &e)  // Failed to save
  {
    response.message = "UBX/RTCM node failed to save configuration file";

    ROS_ERROR("%s!", e.what());

    return true;
  }

  // Update values in memory
  this->surveyInAccuracy = ubxRtcmNode::surveyInAccuracyDefault;
  this->surveyInDuration = ubxRtcmNode::surveyInDurationDefault;

  ROS_DEBUG("Reset survey-in parameters service call has finished");

  response.success = true;

  return true;
}

ubxRtcmNode::~ubxRtcmNode()
{
  try
  {
    // Set node thread stop request flag
    this->nodeThreadStop = true;

    // Wait until the node threa will stop
    this->nodeThread->join();

    // Delete the dynamically allocated node thread
    delete this->nodeThread;

    // Delete the dynamically allocated PX4 UBX/RTCM driver instance
    delete this->ublox_driver;

    // Delete the dynamically allocated wjwwood/serial library serial port instance
    delete this->ublox_serial;
  }
  // Prevent exception to be thrown out of the destructor
  catch (...)
  {
  }
}
