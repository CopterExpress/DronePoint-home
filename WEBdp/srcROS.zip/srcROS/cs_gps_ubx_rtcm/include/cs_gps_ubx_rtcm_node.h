#ifndef CS_UBX_RTCM_NODE
#define CS_UBX_RTCM_NODE

#include <thread>
#include <atomic>
#include <future>

#include "ros/ros.h"

// Use wjwwood/serial library for serial port access
#include "serial/serial.h"

// Use PX4 UBX/RTCM3 driver
#include "ubx.h"

#include <std_srvs/Trigger.h>
#include <cs_gps_srvs/GetSurveyInParameters.h>
#include <cs_gps_srvs/SetSurveyInParameters.h>
#include <cs_gps_srvs/ResetSurveyInParameters.h>

#include <cs_gps_msgs/SurveyIn.h>
#include <cs_gps_msgs/Rtcm.h>
#include <cs_gps_msgs/VehicleGpsPosition.h>
#include <cs_gps_msgs/SatelliteInformation.h>

// Base UBX/RTCM node exception class
class ubxRtcmNodeException: public std::runtime_error
{
public:
  ubxRtcmNodeException(const std::string& what_arg);
};

// UBX/RTCM node failed to save survey-in parameters
class ubxRtcmNodeConfigSaveFailed: public ubxRtcmNodeException
{
public:
  ubxRtcmNodeConfigSaveFailed(const std::string& what_arg);
};

class ubxRtcmNode
{
  private:
    // Buffer size for rapidjs streams
    static const size_t jsonConfigurationBufferSize;

    // Indent count for JSON output
    static const unsigned int jsonConfigurationIndentCount;

    // Node JSON configuration file keys
    static const std::string surveyInAccuracyConfigKey;
    static const std::string surveyInDurationConfigKey;

    // Node JSON configuration file default values
    static const float surveyInAccuracyDefault;
    static const uint32_t surveyInDurationDefault;

    // Survey-in accuracy upper limit (PX4 module accepts value after multiplication)
    static const float surveyInAccuracyLimitMax;

    std::string configurationFileName;  // Node JSON configuration file path

    float surveyInAccuracy;  // Survey-in accurace (m)

    int surveyInDuration;  // Survey-in duration (s)

    ros::NodeHandle &nh;  // Current instance handle

    serial::Timeout gpsCallbackTimeouts;  // Serial port timeouts

    serial::Serial *ublox_serial;  // Serial port instance

    struct vehicle_gps_position_s gpsPos;  // PX4 vehicle GPS position structure

    struct satellite_info_s satInfo;  // PX4 satellite information

    GPSDriverUBX *ublox_driver;  // PX4 UBX/RTCM3 driver instance

    // PX4 UBX/RTCM3 driver static callback
    static int gpsCallback(GPSCallbackType type, void *data1, int data2, void *user);

    std::atomic_bool nodeThreadStop;  // Node thread stop request flag

    std::thread *nodeThread;  // Node thread

    void nodeThreadLoop();  // Node thread loop

    ros::Publisher vehicleGpsPositionPublisher;  // Vehicle GPS postion publisher

    cs_gps_msgs::VehicleGpsPosition vehicleGpsPositionMessage;  // Vehicle GPS position ROS message

    ros::Publisher satelliteInfoPublisher;  // Satellite information publisher

    cs_gps_msgs::SatelliteInformation satelliteInformationMessage;  // Satellite information ROS message

    ros::Publisher surveyInPublisher;  // Survey-in publisher

    cs_gps_msgs::SurveyIn surveyInMessage;  // Survey-in ROS message

    ros::Publisher rtcmDataPublisher;  // RTCM data block publisher

    cs_gps_msgs::Rtcm rtcmMessage;  // RTCM data block message

    // Atomic node thread module reconfigure request
    std::atomic_bool nodeThreadReconfigureRequest;

    // Node thread module reconfigure result promise
    std::promise<bool> nodeThreadReconfigurePromise;

    ros::ServiceServer restartSurveyInService;  // Survey in restart ROS service server

    // Survey in restart ROS service server callback
    bool restartSurveyInServiceCallback(
      std_srvs::Trigger::Request &request,
      std_srvs::Trigger::Response &response);

    // Get survey-in parameters ROS service server
    ros::ServiceServer getSurveyInParametersService;

    // Get survey-in parameters ROS service server callback
    bool getSurveyInParametersServiceCallback(
      cs_gps_srvs::GetSurveyInParameters::Request &request,
      cs_gps_srvs::GetSurveyInParameters::Response &response);

    // Get survey-in parameters ROS service server
    ros::ServiceServer setSurveyInParametersService;

    void saveSurveyInParameters(float accuracy, uint32_t duration);

    // Set survey-in parameters ROS service server callback
    bool setSurveyInParametersServiceCallback(
      cs_gps_srvs::SetSurveyInParameters::Request &request,
      cs_gps_srvs::SetSurveyInParameters::Response &response);

    // Reset survey-in parameters ROS service server
    ros::ServiceServer resetSurveyInParametersService;

    // Reset survey-in parameters ROS service server callback
    bool resetSurveyInParametersServiceCallback(
      cs_gps_srvs::ResetSurveyInParameters::Request &request,
      cs_gps_srvs::ResetSurveyInParameters::Response &response);
  public:
    /* RTCM node constructor
    * nh - ROS node handle
    */
    ubxRtcmNode(ros::NodeHandle &nh);

    // Stops the node thread, join it and delete a dynamically allocated std::thread
    ~ubxRtcmNode();
};

#endif  // CS_UBX_RTCM_NODE
