#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""COEX ground charging station driver for A1"""

import serial
import json
from enum import Enum, unique
import threading

import rospy

from cs_driver_srvs.srv import DriverCommand, DriverCommandRequest, DriverCommandResponse
from cs_driver_msgs.msg import DriverState

from cs_driver_software.CsAction import CsAction, CsActionSequenceExecutor

STATE_BUFFER_LIMIT = 100  # JSON state message buffer limit

# Prevents subscriber's thread to create new sequence executors during node shutdown
node_shutdown_event = threading.Event()

error_event = threading.Event()  # Charging station sequence failure event


class ArduinoLidDriverState(object):
    """
    Namespace for Arduino lid states.
    """
    OPEN = 'open'
    CLOSED = 'closed'
    OPENING = 'opening'
    CLOSING = 'closing'
    UNKNOWN = 'unknown'


# Charging station lid state (will be initialised on the first Arduino state heartbeat) (str)
lid_state = None
lid_state_lock = threading.Lock()  # Charging station lid state lock (multiple thread accessible)


def get_lid_state():
    """
    Returns a lid state in a thread-safe manner.
    WARNING: Asynchronous call (CsActionExecutor)!
    :return: An actual lid state (str or unicode)
    """
    with lid_state_lock:  # Synchronising using a lock
        return lid_state


class ArduinoLockDriverState(object):
    """
    Namespace for Arduino lock states.
    """
    RELEASED = 'uncenter'
    LOCKED = 'center'
    RELEASING = 'moveuncenter'
    LOCKING = 'movecenter'
    UNKNOWN = 'unknown'


# Charging station lock state (will be initialised on the first Arduino state heartbeat) (str)
lock_state = None
# Charging station lock state lock (multiple threads accessible)
lock_state_lock = threading.Lock()


def get_lock_state():
    """
    Returns a lock state in a thread-safe manner.
    WARNING: Asynchronous call (CsActionExecutor)!
    :return: An actual lock state (str or unicode)
    """
    with lock_state_lock:  # Synchronise using a lock
        return lock_state


@unique
class CsHardwareType(Enum):
    """
    Describes charging station hardware type.
    """
    LID_ONLY = 0  # Charging station with a lid only
    LID_LOCK = 1  # Charging station with a lid and locking mechanics


# Charging station hardware type (will be created on the first state message from Arduino)
#   (CsHardwareType)
# HINT: We need to determine charging station hardware first
cs_hardware_type = None

cs_hardware_type_lock = threading.Lock()  # Lock for synchronisation

# Hardware state (will be initialised on the first Arduino status heartbeat)
#   (DriverState)
# HINT: It's better to report to MAVLink charging station node only status updates
current_hardware_state = None

# Hardware state override disables driver state updates during the action sequence
# HINT: None - enable driver state updates
hardware_state_override = None

# For synchronisation between threads for: current_hardware_state, hardware_state_override
hardware_state_lock = threading.Lock()

state_publisher = None  # DriverState publisher object (will be created during initialisation)

arduino_port = None  # Arduino serial port (will be created during initialisation)

# Arduino executor class (will be initialised on the first charging station action sequence)
# WARNING: On each action sequence that will be a new object
action_sequence_executor = None

# Lock for sequence executor variable
# HINT: Executors change each other on new commands. It's possible multiple thread access from
#   the main thread and the command listener.
action_sequence_executor_lock = threading.Lock()


class ArduinoCommand(object):
    """
    Namespace for the Arduino commands.
    """
    # Lid commands
    LID_OPEN = 'open'  # Open charging station lid
    LID_CLOSE = 'close'  # Close charging station lid
    LID_STOP = 'stop'  # Stop lid motor

    # Lock commands
    LOCK_RELEASE = 'uncentr'  # Release charging station lock
    LOCK_LOCK = 'centr'  # Lock charging station lock
    LOCK_STOP = 'stopcentr'  # Stop lock motor


def arduino_send_command(command):
    """
    Send a command to Arduino using serial port.
    WARNING: Asynchronous call (CsActionExecutor)!
    HINT: It's thread safe if you don't use write outside of the sequence executor
    :param command: A command to send (str).
    :return: None
    """
    if not isinstance(command, str):
        raise TypeError('command has to be a string')

    # Send a JSON-serialised command to Arduino, add \n to the end
    arduino_port.write(json.dumps({"command": command}) + '\n')
    rospy.logdebug('Arduino command sent: "%s"', command)


# A command sequence to stop charging station mechanics (tuple(str))
# WARNING: It's not an action sequence!
ARDUINO_STOP_SEQUENCE = ArduinoCommand.LID_STOP, ArduinoCommand.LOCK_STOP


def arduino_stop():
    """
    Stop Arduino mechanics using serial port.
    WARNING: Asynchronous call (CsActionExecutor)!
    :return: None
    """
    for command in ARDUINO_STOP_SEQUENCE:  # For every command from the command sequence
        arduino_send_command(command)  # Send a command using serial port


class ArduinoHardwareActions(object):
    """
    Namespace for the Arduino action set.
    """
    # Open charging station lid
    LID_OPEN = CsAction(
        lambda: arduino_send_command(ArduinoCommand.LID_OPEN),  # Command
        30,  # Maximum timeout
        lambda: get_lid_state() == ArduinoLidDriverState.OPEN  # Goal check
    )

    # Close charging station lid
    LID_CLOSE = CsAction(
        lambda: arduino_send_command(ArduinoCommand.LID_CLOSE),  # Command
        60,  # Maximum timeout
        lambda: get_lid_state() == ArduinoLidDriverState.CLOSED  # Goal check
    )

    # Unlock UAV from from charging station
    LOCK_RELEASE = CsAction(
        lambda: arduino_send_command(ArduinoCommand.LOCK_RELEASE),  # Command
        30,  # Maximum timeout
        lambda: get_lock_state() == ArduinoLockDriverState.RELEASED  # Goal check
    )

    # Lock UAV on the charging station
    LOCK_LOCK = CsAction(
        lambda: arduino_send_command(ArduinoCommand.LOCK_LOCK),  # Command
        60,  # Maximum timeout
        lambda: get_lock_state() == ArduinoLockDriverState.LOCKED  # Goal check
    )


class ArduinoDriverStateKey(object):
    """
    Namespace for the Arduino status message keys.
    """
    LID = 'statelid'  # DriverState message charging station lid state key
    LOCK = 'statelock'  # DriverState message charging station lock state key


# Status matrix to decode final charging station state (for CsHardwareType.LID_LOCK)
# WARNING: DriverState matrix concept was imported from the coex project!
# WARNING: You have to modify state matrix after each action sequence modification!
STATE_MATRIX_LID_LOCK = \
    {
        # Lid state
        ArduinoLidDriverState.OPEN:
            {
                # Lock state
                ArduinoLockDriverState.RELEASED: DriverState.OPEN,
                ArduinoLockDriverState.LOCKED: DriverState.UNKNOWN,
                ArduinoLockDriverState.RELEASING: DriverState.OPENING,
                ArduinoLockDriverState.LOCKING: DriverState.CLOSING,
                ArduinoLockDriverState.UNKNOWN: DriverState.UNKNOWN
            },

        # Lid state
        ArduinoLidDriverState.CLOSED:
            {
                # Lock state
                ArduinoLockDriverState.RELEASED: DriverState.ERROR,
                ArduinoLockDriverState.LOCKED: DriverState.CLOSED,
                ArduinoLockDriverState.RELEASING: DriverState.ERROR,
                ArduinoLockDriverState.LOCKING: DriverState.ERROR,
                ArduinoLockDriverState.UNKNOWN: DriverState.UNKNOWN
            },

        # Lid state
        ArduinoLidDriverState.OPENING:
            {
                # Lock state
                ArduinoLockDriverState.RELEASED: DriverState.ERROR,
                ArduinoLockDriverState.LOCKED: DriverState.OPENING,
                ArduinoLockDriverState.RELEASING: DriverState.ERROR,
                ArduinoLockDriverState.LOCKING: DriverState.ERROR,
                ArduinoLockDriverState.UNKNOWN: DriverState.UNKNOWN
            },

        # Lid state
        ArduinoLidDriverState.CLOSING:
            {
                # Lock state
                ArduinoLockDriverState.RELEASED: DriverState.ERROR,
                ArduinoLockDriverState.LOCKED: DriverState.CLOSING,
                ArduinoLockDriverState.RELEASING: DriverState.ERROR,
                ArduinoLockDriverState.LOCKING: DriverState.ERROR,
                ArduinoLockDriverState.UNKNOWN: DriverState.UNKNOWN
            },

        # Lid state
        ArduinoLidDriverState.UNKNOWN:
            {
                # Lock state
                ArduinoLockDriverState.RELEASED: DriverState.UNKNOWN,
                ArduinoLockDriverState.LOCKED: DriverState.UNKNOWN,
                ArduinoLockDriverState.RELEASING: DriverState.UNKNOWN,
                ArduinoLockDriverState.LOCKING: DriverState.UNKNOWN,
                ArduinoLockDriverState.UNKNOWN: DriverState.UNKNOWN
            }
    }

# DriverState dictionary for the lid only charging station (for CsHardwareType.LID_ONLY)
STATE_DICT_LID = {
    # Lid state
    ArduinoLidDriverState.OPEN: DriverState.OPEN,
    ArduinoLidDriverState.CLOSED: DriverState.CLOSED,
    ArduinoLidDriverState.OPENING: DriverState.OPENING,
    ArduinoLidDriverState.CLOSING: DriverState.CLOSING,
    ArduinoLidDriverState.UNKNOWN: DriverState.UNKNOWN
}


class ArduinoActionSequencesLidLock(object):
    """
    Namespace for the Arduino action sequences (charging station with lid and lock).
    HINT: Sequence is a tuple of CsAction.
    """
    OPEN = ArduinoHardwareActions.LID_OPEN, ArduinoHardwareActions.LOCK_RELEASE
    CLOSE = ArduinoHardwareActions.LOCK_LOCK, ArduinoHardwareActions.LID_CLOSE


class ArduinoActionSequencesLidOnly(object):
    """
    Namespace for the Arduino action sequences (charging station with lid and lock)
    HINT: Sequence is a tuple of CsAction.
    HINT: Even if it contains only one element!
    """
    OPEN = ArduinoHardwareActions.LID_OPEN,
    CLOSE = ArduinoHardwareActions.LID_CLOSE,


def cs_state_message_callback(msg):
    """
    Status message callback from Arduino.
    WARNING: Synchronous callback (main)!
    :param msg: A message from the charging station hardware (dict(str: str))
    :return: None
    """
    global cs_hardware_type
    global lid_state
    global lock_state
    global current_hardware_state

    # rospy.logdebug("Incoming state message from Arduino: '%s'", msg)

    if (ArduinoDriverStateKey.LID in msg) and (ArduinoDriverStateKey.LOCK in msg):  # Lid ans lock
        try:
            # Extracting lid state
            lid_state_local = msg[ArduinoDriverStateKey.LID]
            with lid_state_lock:  # Synchronise with a sequence executor
                lid_state = lid_state_local  # Update lid state

            # Extracting lock state
            lock_state_local = msg[ArduinoDriverStateKey.LOCK]
            with lock_state_lock:  # Synchronise with a sequence executor
                lock_state = lock_state_local  # Update lock state

            with action_sequence_executor_lock:  # Synchronise with other threads
                # If action sequence executor exists and running
                if (action_sequence_executor is not None) and \
                        action_sequence_executor.is_alive():
                    # Notify the action executor about the lid and lock states update
                    action_sequence_executor.goal_check_notify()

            # Calculate hardware state using state matrix
            # TODO: Actually, we can do it without local copies of states.
            if not lock_always_released:
                new_hardware_state = STATE_MATRIX_LID_LOCK[lid_state_local][lock_state_local]
            else:
                # If lock locking was disabled we have to use lid only state interpretation
                new_hardware_state = STATE_DICT_LID[lid_state_local]

            with cs_hardware_type_lock:  # Synchronise with a command callback
                if cs_hardware_type is None:  # Hardware type is unknown at this moment
                    cs_hardware_type = CsHardwareType.LID_LOCK  # Update hardware type

                    rospy.loginfo('Charging station hardware type: lid and lock')
        except KeyError as e:  # One of states is unknown
            rospy.logerr('Status message with unknown state. Problem state value: "%s"',
                         e.args[0])

            return  # Ignoring this state message
    elif ArduinoDriverStateKey.LID in msg:  # Lid only
        try:
            # Extracting lid state
            lid_state_local = msg[ArduinoDriverStateKey.LID]
            with lid_state_lock:  # Synchronise with a sequence executor
                lid_state = lid_state_local  # Update lid state

            with action_sequence_executor_lock:  # Synchronise with other threads
                # If action sequence executor exists and running
                if (action_sequence_executor is not None) and \
                        action_sequence_executor.is_alive():
                    # Notify the action executor about the lid and lock states update
                    action_sequence_executor.goal_check_notify()

            # Get hardware state using state dictionary
            # TODO: Actually, we can do it without local a copy of a state.
            new_hardware_state = STATE_DICT_LID[lid_state_local]

            with cs_hardware_type_lock:  # Synchronise with a command callback
                if cs_hardware_type is None:  # Hardware type is unknown at this moment
                    cs_hardware_type = CsHardwareType.LID_ONLY  # Update hardware type

                    rospy.loginfo('Charging station hardware type: lid only')
        except KeyError as e:  # Unknown hardware state
            rospy.logerr('Unknown state: "%s"', e.args[0])

            return  # Ignoring this state message
    else:
        rospy.logerr('Incorrect state message format!')

        return  # Ignoring this state message

    with hardware_state_lock:
        # If the hardware state was changed from the last time
        if current_hardware_state != new_hardware_state:
            # HINT: There is no write operation to the current hardware state except the one below

                current_hardware_state = new_hardware_state  # Update state value

                # Driver state updates from Arduino are not disabled
                if hardware_state_override is None:
                    # Publish state into driver's state ROS topic
                    state_publisher.publish(new_hardware_state)
                    rospy.loginfo('New charging station hardware state: %s',
                                  new_hardware_state)
                else:  # DriverState updates from Arduino are blocked
                    rospy.loginfo(
                        'New charging station hardware state (updates were disabled): %s, '
                        'override by %s', new_hardware_state, hardware_state_override)


def cs_action_sequence_completed(sender):
    """
    Successful action sequence execution callback.
    :param sender: A callback sender (CsActionSequenceExecutor)
    WARNING: Asynchronous callback (CsActionSequenceExecutor)!
    WARNING: Action sequence executor lock! Finish callback asap!
    :return: None
    """
    global hardware_state_override

    rospy.loginfo('Action sequence has been completed!')

    # Removing of a state override is a little tricky:
    # 1) State update before the block below. Update will be ignored due to the state
    #   override. The updated state will be published in the block below.
    # 2) State update during the block below. Update will wait for the block execution.
    #   Two updates will appear consistently: old state, new update.
    # 3) State update after the block below. Two consistent updates will appear.
    # HINT: This happens because the current hardware state and the hardware state override are
    # HINT:     sharing the same lock.

    with hardware_state_lock:
        # Force previous state updates
        state_publisher.publish(current_hardware_state)
        rospy.logdebug('Force current state update.')

        # Enable driver state updates
        hardware_state_override = None
        rospy.logdebug('Arduino state updates are enabled.')


def cs_action_sequence_failed(sender):
    """
    Action sequence execution failure callback.
    :param sender: A callback sender (CsActionSequenceExecutor)
    WARNING: Asynchronous callback (CsActionSequenceExecutor)!
    WARNING: Action sequence executor lock! Finish callback asap!
    :return: None
    """
    global error_event
    global hardware_state_override

    rospy.logerr('Action sequence execution has failed!')

    error_event.set()  # Set an error event
    rospy.logdebug('Error flag was set.')

    with hardware_state_lock:
        # Disable driver state updates
        hardware_state_override = DriverState.ERROR
    rospy.logdebug('Driver state updates are disabled.')

    # Publish error state into driver's state ROS topic
    # HINT: From this point MAVLink CS node will always report error state
    state_publisher.publish(DriverState.ERROR)
    rospy.logdebug('Error state was reported to MAVLink CS node.')


def cs_action_sequence_stopped(sender):
    """
    Action sequence execution stop callback.
    :param sender: A callback sender (CsActionSequenceExecutor)
    WARNING: Asynchronous callback (CsActionSequenceExecutor)!
    WARNING: Action sequence executor lock! Finish callback asap!
    :return: None
    """
    rospy.loginfo('Action sequence execution has been stopped!')


# Enable in using ROS parameter if you want charging station to keep the lock always in the
#   released state (will be set during the node initialisation)
# WARNING: Only for charging station debug purposes!
lock_always_released = None


def cs_driver_command_callback(req):
    """
    MAVLink charging station node command callback.
    WARNING: Asynchronous callback (ROS service server)!
    :param req: A request from the MAVLink charging station node (DriverCommandRequest)
    :return: None
    """
    global action_sequence_executor  # Using global
    global error_event
    global hardware_state_override

    with cs_hardware_type_lock:  # Synchronise with the main thread
        if cs_hardware_type is None:  # Hardware state is still unknown
            rospy.loginfo('Charging station hardware is still unknown. Ignoring command.')
            # Ignoring the command
            return DriverCommandResponse(
                DriverCommandResponse.ERROR,
                'Charging station hardware is still unknown'
            )
    # WARNING: cs_hardware_type is static once set. No need in lock below.

    with action_sequence_executor_lock:  # Synchronise with the main thread
        if node_shutdown_event.is_set():  # Node shutdown process is in progress
            rospy.logdebug('Command callback during a node shutdown. Ignoring.')
            # Ignoring the command
            return DriverCommandResponse(
                DriverCommandResponse.ERROR,
                'Command callback during a node shutdown'
            )

        # If an sequence executor exists and the other action is in progress
        # HINT: We have to interrupt previous action to start a new one
        if (action_sequence_executor is not None) and (action_sequence_executor.is_alive()):
            # It's a good idea to prevent user restart the same action again and again
            if req.command in {DriverCommandRequest.OPEN, DriverCommandRequest.RESTORE}:
                # OPEN and RESTORE commands are starting the OPEN sequences
                if action_sequence_executor.action_sequence in {
                    ArduinoActionSequencesLidLock.OPEN,
                    ArduinoActionSequencesLidOnly.OPEN
                }:
                    rospy.logdebug('Open sequence is already in action. Ignoring.')

                    return DriverCommandResponse(
                        DriverCommandResponse.ALREADY_DONE,
                        'Charging station is already opening'
                    )
            elif req.command == DriverCommandRequest.CLOSE:
                # OPEN command is starting the CLOSE sequences
                if action_sequence_executor.action_sequence in {
                    ArduinoActionSequencesLidLock.CLOSE,
                    ArduinoActionSequencesLidOnly.CLOSE
                }:
                    rospy.logdebug('Close sequence is already in action. Ignoring.')

                    return DriverCommandResponse(
                        DriverCommandResponse.ALREADY_DONE,
                        'Charging station is already closing'
                    )

            rospy.logdebug('The other sequence execution is in progress!')

            # Requesting sequence execution stop
            action_sequence_executor.stop_executor()
            rospy.logdebug('Stopping the sequence execution!')

            # Wait until the executor stops
            action_sequence_executor.join()
            rospy.logdebug('The sequence execution has stopped!')

            if req.command == DriverCommandRequest.STOP:  # Stop command
                # Removing of a state override is a little tricky:
                # 1) State update before the block below. Update will be ignored due to the state
                #   override. The updated state will be published in the block below.
                # 2) State update during the block below. Update will wait for the block execution.
                #   Two updates will appear consistently: old state, new update.
                # 3) State update after the block below. Two consistent updates will appear.
                # HINT: This happens because the current hardware state and the hardware state override are
                # HINT:     sharing the same lock.

                with hardware_state_lock:
                    # Force previous state updates
                    state_publisher.publish(current_hardware_state)
                    rospy.logdebug('Force current state update.')

                    # Enable driver state updates
                    hardware_state_override = None
                    rospy.logdebug('Arduino state updates are enabled.')

                # Nothing to do for this command
                return DriverCommandResponse(DriverCommandResponse.SUCCESS, '')
        else:  # Previous sequence is not in progress
            if req.command == DriverCommandRequest.STOP:  # Stop command
                if not error_event.is_set():  # If no error event
                    rospy.logdebug('No active sequences to stop. Ignoring.')

                    return DriverCommandResponse(
                        DriverCommandResponse.ALREADY_DONE,
                        'No active sequence to stop'
                    )
                else:  # Error state
                    rospy.logerr('Command is not applicable in the error state: %s', req.command)

                    return DriverCommandResponse(
                        DriverCommandResponse.ERROR_STATE,
                        'Command is not applicable in the error state'
                    )

        # Restore charging station from the error state
        # HINT: Applicable in all states
        if req.command == DriverCommandRequest.RESTORE:
            # Create a new sequence executor
            # HINT: We will try to open charging station
            action_sequence_executor = CsActionSequenceExecutor(
                # Selecting a sequence depending on the hardware type
                ArduinoActionSequencesLidLock.OPEN
                if cs_hardware_type == CsHardwareType.LID_LOCK
                else ArduinoActionSequencesLidOnly.OPEN,
                arduino_stop,  # Actor stop function
                cs_action_sequence_completed,  # Action sequence completed callback
                cs_action_sequence_failed,  # Action sequence failed callback
                cs_action_sequence_stopped  # Action sequence stopped callback
            )
            rospy.logdebug('Arduino action executor created: %s', action_sequence_executor)

            with hardware_state_lock:
                # Disable driver state updates
                hardware_state_override = DriverState.OPENING
            rospy.logdebug('Driver state updates from Arduino are disabled')

            # Publish opening state into driver's state ROS topic
            # HINT: Publish is thread-safe
            # https://answers.ros.org/question/257245/is-rospypublisherpublish
            # -thread-safe/
            state_publisher.publish(DriverState.OPENING)
            rospy.logdebug('DriverState OPENING was reported to the MAVLink CS node')

            error_event.clear()  # Remove an error event
            rospy.logdebug('Error event was removed')

            action_sequence_executor.start()  # Start selected sequence

            # HINT: It's not a problem if charging station in some random state
            # HINT:     action sequence executor will ignore already completed actions.

            return DriverCommandResponse(DriverCommandResponse.SUCCESS, '')

        if not error_event.is_set():  # If no error event
            # Open charging station command
            if req.command == DriverCommandRequest.OPEN:
                with hardware_state_lock:
                    if current_hardware_state == DriverState.OPEN:
                        rospy.logdebug('Open sequence is already completed. Ignoring.')

                        return DriverCommandResponse(
                            DriverCommandResponse.ALREADY_DONE,
                            'Charging station is already open'
                        )

                # Create a new sequence executor
                action_sequence_executor = CsActionSequenceExecutor(
                    # Selecting a sequence depending on the hardware type
                    ArduinoActionSequencesLidLock.OPEN
                    if cs_hardware_type == CsHardwareType.LID_LOCK
                    else ArduinoActionSequencesLidOnly.OPEN,
                    arduino_stop,  # Actor stop function
                    cs_action_sequence_completed,  # Action sequence completed callback
                    cs_action_sequence_failed,  # Action sequence failed callback
                    cs_action_sequence_stopped  # Action sequence stopped callback
                )
                rospy.logdebug('Arduino action executor created: %s',
                               action_sequence_executor)

                with hardware_state_lock:
                    # Disable driver state updates
                    hardware_state_override = DriverState.OPENING
                rospy.logdebug('Driver state updates from Arduino are disabled')

                # Publish unknown state into driver's state ROS topic
                # HINT: Publish is thread-safe
                # https://answers.ros.org/question/257245/is-rospypublisherpublish
                # -thread-safe/
                state_publisher.publish(DriverState.OPENING)
                rospy.logdebug('DriverState OPENING was reported to the MAVLink CS node')

                action_sequence_executor.start()  # Start selected sequence
            # Close charging station command
            elif req.command == DriverCommandRequest.CLOSE:
                with hardware_state_lock:
                    if current_hardware_state == DriverState.CLOSED:
                        rospy.logdebug('Close sequence is already completed. Ignoring.')

                        return DriverCommandResponse(
                            DriverCommandResponse.ALREADY_DONE,
                            'Charging station is already closed'
                        )

                action_sequence_executor = CsActionSequenceExecutor(
                    # Selecting a sequence depending on the hardware type
                    ArduinoActionSequencesLidLock.CLOSE
                    if (cs_hardware_type == CsHardwareType.LID_LOCK) and not lock_always_released
                    else ArduinoActionSequencesLidOnly.CLOSE,
                    arduino_stop,  # Actor stop function
                    cs_action_sequence_completed,  # Action sequence completed callback
                    cs_action_sequence_failed,  # Action sequence failed callback
                    cs_action_sequence_stopped  # Action sequence stopped callback
                )
                rospy.logdebug('Arduino action executor created: %s',
                               action_sequence_executor)

                with hardware_state_lock:
                    # Disable driver state updates
                    hardware_state_override = DriverState.CLOSING
                rospy.logdebug('Driver state updates from Arduino are disabled')

                # Publish unknown state into driver's state ROS topic
                # HINT: Publish is thread-safe
                # https://answers.ros.org/question/257245/is-rospypublisherpublish
                # -thread-safe/
                state_publisher.publish(DriverState.CLOSING)
                rospy.logdebug('DriverState CLOSING was reported to the MAVLink CS node')

                action_sequence_executor.start()  # Start selected sequence
            # Implement new commands here
            else:  # Command is not supported
                rospy.logerr('Unknown command: %s', req.command)
                return DriverCommandResponse(
                    DriverCommandResponse.ERROR,
                    'Unknown command'
                )
        else:  # Error flag is set
            rospy.logerr('Command is not applicable in the error state: %s', req.command)
            return DriverCommandResponse(
                DriverCommandResponse.ERROR_STATE,
                'Command is not applicable in the error state'
            )

    return DriverCommandResponse(DriverCommandResponse.SUCCESS, '')


# Main function
if __name__ == '__main__':
    # Initialize the node, name it, set log verbosity level
    rospy.init_node('cs_driver_a1', log_level=rospy.DEBUG)
    rospy.logdebug('Node initialized')

    node_prefix = rospy.get_param("~prefix", default='')  # Extracting topic prefix

    if not isinstance(node_prefix, str):
        raise EnvironmentError('Node topic prefix parameter value has to be a string!')

    rospy.logdebug('Node prefix: %s', node_prefix)

    # Creating a topic publisher for commands addressed to actuation driver with latching
    state_publisher = rospy.Publisher('{0}/state'.format(node_prefix),
                                      DriverState, queue_size=10, latch=True)
    rospy.logdebug('Publisher for a state topic ready: %s', state_publisher)

    # Create a command service server
    rospy.Service('{0}/command'.format(node_prefix), DriverCommand, cs_driver_command_callback)
    rospy.logdebug('Created a driver command service server')

    lock_always_released = rospy.get_param("~lock_always_released", default=False)
    rospy.logdebug('Lock always released: %s', lock_always_released)

    try:
        serial_port = rospy.get_param('~serial_port')  # Retrieving serial port path
    except KeyError:
        raise EnvironmentError('No serial port presented!')

    if not isinstance(serial_port, str):
        raise EnvironmentError('Serial port parameter value has to be a string!')

    rospy.logdebug('Serial port: "%s"', serial_port)

    serial_baudrate = rospy.get_param('~serial_baudrate', 115200)

    if not isinstance(serial_baudrate, int):
        raise EnvironmentError('Serial port baudrate value has to be an integer!')

    rospy.logdebug('Serial port baudrate: %s', serial_baudrate)

    serial_bytesize = rospy.get_param('~serial_bytesize', 8)

    if not isinstance(serial_bytesize, int):
        raise EnvironmentError('Serial port bytesize value has to be an integer!')

    rospy.logdebug('Serial port bytesize: %s', serial_bytesize)

    serial_parity = rospy.get_param('~serial_parity', 'N')

    if not isinstance(serial_parity, str):
        raise EnvironmentError('Serial port parity value has to be a string!')

    rospy.logdebug('Serial port parity: "%s"', serial_parity)

    serial_stopbits = rospy.get_param('~serial_stopbits', 1)

    if not isinstance(serial_stopbits, (int, float)):
        raise EnvironmentError('Serial port stop bits number has to be an integer or a float!')

    rospy.logdebug('Serial port stop bits: "%s"', serial_stopbits)

    serial_xonxoff = rospy.get_param('~serial_xonxoff', False)

    if not isinstance(serial_xonxoff, bool):
        raise EnvironmentError('Serial port XON/XOFF value has to be a bool!')

    rospy.logdebug('Serial port XON/XOFF: %s', serial_xonxoff)

    serial_rtscts = rospy.get_param('~serial_rtscts', False)

    if not isinstance(serial_rtscts, bool):
        raise EnvironmentError('Serial port RTS/CTS value has to be a bool!')

    rospy.logdebug('Serial port RTS/CTS: %s', serial_rtscts)

    read_timeout = rospy.get_param('~read_timeout', 1.0)

    if not isinstance(read_timeout, float):
        raise EnvironmentError('Read timeout value has to be a bool!')

    rospy.logdebug('Read timeout: "%s"', read_timeout)

    arduino_port = serial.Serial(
        port=serial_port,
        baudrate=serial_baudrate,
        bytesize=serial_bytesize,
        parity=serial_parity,
        stopbits=serial_stopbits,
        xonxoff=serial_xonxoff,
        rtscts=serial_rtscts,
        # Blocking mode
        # WARNING: We have to keep a timeout for the correct node shutdown!
        timeout=read_timeout
    )
    rospy.logdebug('Arduino serial port ready: %s', arduino_port)

    # No need in these variables from this moment
    del serial_port
    del serial_baudrate
    del serial_bytesize
    del serial_parity
    del serial_stopbits
    del serial_xonxoff
    del serial_rtscts
    del read_timeout

    state_buffer = ''  # Buffer for the incoming JSON state message

    serial_byte = None  # Storage for a serial port byte

    try:
        while not rospy.is_shutdown():  # While the ROS is up
            try:
                # Get a byte from the serial port
                # HINT: It's a blocking routine
                serial_byte = arduino_port.read()

                if not serial_byte:  # No data in the serial port buffer (read timeout)
                    pass  # Just ignore
                elif serial_byte == '\n':  # End of the JSON state message
                    if len(state_buffer):  # Not an empty JSON state message
                        #  rospy.logdebug('Got JSON state message from Arduino: "%s"',
                        #   state_buffer)

                        try:
                            cs_state = json.loads(state_buffer)  # Decode JSON
                            #  rospy.logdebug("Decoded state message from Arduino: '%s'",
                            #    cs_state)

                            # JSON loads method correctly parses any JSON value without
                            # a parameter ('123', '0.2', '"ABC"'). We need an additional type
                            # check.
                            if not isinstance(cs_state, dict):  # We expect to get dict
                                rospy.logerr('Invalid state message: %s', cs_state)
                            else:
                                cs_state_message_callback(cs_state)  # Passing to the callback
                        except ValueError as e:  # Incorrect JSON message
                            rospy.logerr('Failed to parse JSON message "%s": %s',
                                         state_buffer, e)
                    else:
                        rospy.logerr('Empty JSON state message!')

                    state_buffer = ''  # Clean the JSON state message buffer
                else:  # Not an end of the JSON state message
                    # JSON status massage is too big (abnormal Arduino firmware?)
                    if len(state_buffer) > STATE_BUFFER_LIMIT:
                        rospy.logerr('Too big JSON state message: "%s"', state_buffer)

                        state_buffer = ''  # Clean the JSON state message buffer

                        # TODO: It's better to set a flag after buffer overflow and ignore
                        # TODO:     new data until the message end ('\n'). But in fact it
                        # TODO:     doesn't matter what we do with the rest of this message.

                    # Collect a character inside the state message buffer
                    state_buffer += serial_byte
            except serial.serialutil.SerialException as e:
                # TODO: When the ROS is down by Ctrl-C we will get an exception
                # TODO:     caused by EINTR (signal interrupt). The better way to avoid this is
                # TODO:     to place read operation in the separate thread.

                # Check if it is an interrupted system call
                # TODO: That's an ugly solution... Do we have other options with PySerial?
                if str(e).find("Interrupted system call") == -1:
                    rospy.logerr('Failed to read from the serial device: %s', e)
                else:
                    rospy.logdebug('Interrupted read')

                break  # Stop the ROS node
    finally:  # Cleaning up
        node_shutdown_event.set()  # All new command callbacks will be cancel after this point

        with action_sequence_executor_lock:  # Synchronise with the subscriber's thread
            # Action sequence executor exists and it's running
            if (action_sequence_executor is not None) \
                    and (action_sequence_executor.is_alive()):
                rospy.logdebug('The sequence execution is in progress!')

                # Requesting sequence execution stop
                action_sequence_executor.stop_executor()
                rospy.logdebug('Stopping the sequence execution!')

                # Wait until the executor stops
                action_sequence_executor.join()
                rospy.logdebug('The sequence execution has stopped!')

        arduino_port.close()  # Closing serial port
        rospy.logdebug('Arduino serial port closed')
