#ifndef CS_CHARGER_GPIO_NODE
#define CS_CHARGER_GPIO_NODE

#include <mutex>

#include <ros/ros.h>

#include <sensor_msgs/BatteryState.h>

// Base chrager GPIO node exception class
class chargerGpioNodeException: public std::runtime_error
{
public:
  chargerGpioNodeException(const std::string& what_arg);
};

// Invalid node configuration
class chargerGpioInvalidConfiguration: public chargerGpioNodeException
{
public:
  chargerGpioInvalidConfiguration(const std::string& what_arg);
};

// pigpio library initialisation failed
class chargerGpioPigpioFailed: public chargerGpioNodeException
{
public:
  chargerGpioPigpioFailed(const std::string& what_arg);
};

// GPIO pin setup failed
class chargerGpioPinSetupFailed: public chargerGpioNodeException
{
public:
  chargerGpioPinSetupFailed(const std::string& what_arg);
};

class chargerGpioNode
{
  private:
    ros::NodeHandle &nh;  // Current instance handle

    int pigpiodHandle;
    int pinStateChangedCallbackHandle;

    double chargedStateDebounceTime;
    ros::Timer chargedStateDebounceTimer;

    sensor_msgs::BatteryState batteryState;

    bool signalInversed;  // GPIO pin signal inversed flag

    std::mutex postBatteryStateMutex;

    // Guarded by postBatteryStateMutex
    bool firstSupplyStatePost;
    uint8_t supplyStateLastPosted;
    uint8_t supplyStatePended;

    ros::Publisher batteryStatePublisher;
    //

    /* GPIO state changed callback
    * pi - pigpiod handle;
    * gpio - GPIO pin number;
    * level - new GPIO pin level;
    * tick - an event timestamp;
    * userdata - a user payload.
    */
    static void gpioStateChangedCallback(int pi, unsigned gpio, unsigned level, uint32_t tick, void *userdata);

    /* Charged state debounce finished callback
    * caller - a calling ROS timer.
    */
    void chargedStateDebounceTimerCallback(const ros::TimerEvent &caller);

    /* Post a new battery state
    * supplyState - a supply state to post.
    * WARNING: Call this only if you own postBatteryStateMutex.
    */
    void postBatteryState(uint8_t supplyState);

    /* Convert a pin state to a supply state
    * state - a pin state to convert.
    * Return:
    *   a power supply state.
    */
    inline uint8_t pinStateToSupplyState(int state)
    {
      return (state ^ this->signalInversed) ? sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_CHARGING :
        sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_NOT_CHARGING;
    }
  public:
    /* Charger GPIO node constructor
    * nh - ROS node handle.
    */
    chargerGpioNode(ros::NodeHandle &nh);

    // Stops the node thread, join it and delete a dynamically allocated std::thread
    ~chargerGpioNode();
};

#endif  // CS_CHARGER_GPIO_NODE
