#include <exception>
#include <functional>
#include <unordered_map>

#include "cs_charger_gpio_node.h"

#include <sensor_msgs/BatteryState.h>

#include <pigpiod_if2.h>

chargerGpioNodeException::chargerGpioNodeException(const std::string& what_arg)
: std::runtime_error(what_arg)
{
}

chargerGpioInvalidConfiguration::chargerGpioInvalidConfiguration(const std::string& what_arg)
: chargerGpioNodeException(what_arg)
{
}

chargerGpioPigpioFailed::chargerGpioPigpioFailed(const std::string& what_arg)
: chargerGpioNodeException(what_arg)
{
}

chargerGpioPinSetupFailed::chargerGpioPinSetupFailed(const std::string& what_arg)
: chargerGpioNodeException(what_arg)
{
}

// Constant bindings for GPIO pull up / pull down
static const std::unordered_map<std::string, unsigned> pullUpDownMap =
{
  {"none", PI_PUD_OFF},
  {"down", PI_PUD_DOWN},
  {"up", PI_PUD_UP}
};

chargerGpioNode::chargerGpioNode(ros::NodeHandle &nh)
: nh(nh)  // Copy a reference to a ROS node handle
, firstSupplyStatePost(true)  // Set a first supply state post flag
// Create a publisher with enabled latch
, batteryStatePublisher(this->nh.advertise<sensor_msgs::BatteryState>("battery_state", 10, true))
{
  // Reset a battery state message
  this->batteryState.header.seq = 0;
  this->batteryState.header.frame_id = "";

  this->batteryState.voltage = NAN;
  this->batteryState.current = NAN;
  this->batteryState.charge = NAN;
  this->batteryState.capacity = NAN;
  this->batteryState.percentage = NAN;
  this->batteryState.power_supply_health = sensor_msgs::BatteryState::POWER_SUPPLY_HEALTH_UNKNOWN;
  this->batteryState.power_supply_technology = sensor_msgs::BatteryState::POWER_SUPPLY_TECHNOLOGY_UNKNOWN;
  this->batteryState.present = true;
  this->batteryState.cell_voltage = {0, };
  this->batteryState.location = "";
  this->batteryState.serial_number = "";
  //

  bool debug;  // Serial port byte size parameter value

  // Load from a ROS parameter
  nh.param("debug", debug, false);

  // Set a log verbosity level
  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
      (debug) ? ros::console::levels::Debug : ros::console::levels::Info))
    ros::console::notifyLoggerLevelsChanged();

  if (debug)
    ROS_DEBUG("Debug mode enabled");

  std::string pigpiodIP;

  nh.param("pigpiod_ip", pigpiodIP, std::string("localhost"));

  ROS_DEBUG("pigpiod IP: \"%s\"", pigpiodIP.c_str());

  int pigpiodPort;

  nh.param("pigpiod_port", pigpiodPort, 8888);

  ROS_DEBUG("pigpiod port: %i", pigpiodPort);

  if (pigpiodPort <= 0)
    throw chargerGpioInvalidConfiguration("pigpiod port can't be less or equal to 0!");

  int inputPin;

  if (!nh.getParam("pin", inputPin))
    throw chargerGpioInvalidConfiguration("No input pin number presented!");

  ROS_DEBUG("Input pin: %i", inputPin);

  if (inputPin < 0)
    throw chargerGpioInvalidConfiguration("Input pin number can't be less than 0!");

  std::string pullUpDownStr;  // Pull up/pull down option value

  nh.param("pull_up_down", pullUpDownStr, std::string("none"));

  // Convert string to the lower case
  std::transform(pullUpDownStr.begin(), pullUpDownStr.end(), pullUpDownStr.begin(), ::tolower);

  // Look for the ROS parameter value binding
  auto pullUpDownIter = pullUpDownMap.find(pullUpDownStr);

  // A binding doesn't exists
  if (pullUpDownIter == pullUpDownMap.end())
    throw std::runtime_error("Unknown pull up / down value: \"" + pullUpDownStr +'"');

  ROS_DEBUG("Pull up/pull down: \"%s\"", pullUpDownStr.c_str());

  int debounceTime;  // Glitch filter steady time

  nh.param("debounce_time", debounceTime, 100000);

  ROS_DEBUG("Debounce time: %i", debounceTime);

  if (debounceTime < 0)
    throw chargerGpioInvalidConfiguration("Debounce can't be less than 0!");

  nh.param("charged_state_debounce_time", this->chargedStateDebounceTime, 30.0);

  ROS_DEBUG("Charged state debounce time: %f", this->chargedStateDebounceTime);

  if (this->chargedStateDebounceTime && (this->chargedStateDebounceTime < 5.0))
    throw chargerGpioInvalidConfiguration("Charged state debounce time can't be less than 5!");

  nh.param("inversed_signal", this->signalInversed, false);

  ROS_DEBUG("Inversed signal: %s", (signalInversed) ? "true" : "false");

  // HINT: pigpiod expects port number as a C string
  std::string pigpiodPortStr(std::to_string(pigpiodPort));

  // Connect to the pigpiod server
  // HINT: Function expects string as a char *, const_cast is needed
  this->pigpiodHandle = pigpio_start(const_cast<char *>(pigpiodIP.c_str()),
    const_cast<char *>(pigpiodPortStr.c_str()));
  if (this->pigpiodHandle < 0)
    throw chargerGpioPigpioFailed("pigpiod connection has failed");

  // Set a charger pin as an INPUT
  if (set_mode(this->pigpiodHandle, inputPin, PI_INPUT))
    throw chargerGpioPinSetupFailed("Failed to set pin mode");

  // Enable pull up if requested
  if (set_pull_up_down(this->pigpiodHandle, inputPin, pullUpDownIter->second))
    throw chargerGpioPinSetupFailed("Failed to set pin pull up / pull down");

  // Set up a debounce (on the server side) if debounce time is not zero
  if (debounceTime && set_glitch_filter(this->pigpiodHandle, inputPin, debounceTime))
    throw chargerGpioPinSetupFailed("Failed to set glitch filter");

  // Charged state debounce time is not zero 
  if (this->chargedStateDebounceTime)
    // Create a charged state debounce timer without autostart
    this->chargedStateDebounceTimer = this->nh.createTimer(ros::Duration(this->chargedStateDebounceTime),
      &chargerGpioNode::chargedStateDebounceTimerCallback, this, true, false);

  // Register a callback for the charger pin state change
  this->pinStateChangedCallbackHandle = callback_ex(this->pigpiodHandle, inputPin, EITHER_EDGE,
      &chargerGpioNode::gpioStateChangedCallback, this);
  if (this->pinStateChangedCallbackHandle < 0)
    throw chargerGpioPinSetupFailed("Failed to set GPIO pin state change callback");

  // Get the mutex before a first battery state post (shared with the pigpiod thread)
  std::lock_guard<std::mutex> lock(this->postBatteryStateMutex);

  // Retrieve a charger pin state
  int currentLevel = gpio_read(this->pigpiodHandle, inputPin);
  if (this->pinStateChangedCallbackHandle < 0)
    throw chargerGpioPinSetupFailed("Failed to read initial pin state");

  // Convert a GPIO pin state to a supply state
  uint8_t currentSupplyState = pinStateToSupplyState(currentLevel);

  // There is a chance that the GPIO change callback could post the same supply state before
  // the initial post code block, we need this check to ommit the duplicate post
  if (!this->firstSupplyStatePost && this->supplyStateLastPosted == currentLevel)
    return;

  this->postBatteryState(currentSupplyState);
}

// HINT: pigpiod doesn't have its own consts for GPIO states
enum pigpiodGpioLevelChangedEvent
{
  PGLCE_FALLING = 0,
  PGLCE_RISING,
  PGLCE_WATCHDOG
};

void chargerGpioNode::gpioStateChangedCallback(int pi, unsigned gpio, unsigned level, uint32_t tick, void *userdata)
{
  ROS_DEBUG("Pin changed: %i, %u, %i, %u", pi, gpio, level, tick);

  // No battery change (watchdog), ignore
  if (level == PGLCE_WATCHDOG)
    return;

  // Extract the owner object
  chargerGpioNode *owner = static_cast<chargerGpioNode *>(userdata);

  // Cancel the charged state debouncer
  owner->chargedStateDebounceTimer.stop();

  // Convert a pin state to a supply state
  uint8_t supplyState = owner->pinStateToSupplyState(level);

  // Get the mutex (shared with the main thread and the charged state timer threads)
  std::lock_guard<std::mutex> lock(owner->postBatteryStateMutex);

  // Return if it's a duplicate state
  if (!owner->firstSupplyStatePost && (owner->supplyStateLastPosted == supplyState))
    return;

  // If a new state is NOT CHARGING and a charged state time is not zero, we can't
  // post the supply state immidiately, we need to start the debounce timer
  if (owner->chargedStateDebounceTime &&
    (supplyState == sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_NOT_CHARGING))
  {
    // Save a power supply state
    owner->supplyStatePended = supplyState;
    
    owner->chargedStateDebounceTimer.start();
  }
  else
    owner->postBatteryState(supplyState);
}

void chargerGpioNode::chargedStateDebounceTimerCallback(const ros::TimerEvent &caller)
{
  // Get the mutex (shared with the main thread and the pigpiod thread)
  std::lock_guard<std::mutex> lock(this->postBatteryStateMutex);

  this->postBatteryState(this->supplyStatePended);
}

void chargerGpioNode::postBatteryState(uint8_t supplyState)
{
  this->firstSupplyStatePost = false;

  // Save the last posted state
  this->supplyStateLastPosted = supplyState;

  ROS_INFO("Charger state updated: %s",
    (supplyState == sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_CHARGING) ?
      "CHARGING" : "CHARGED / NO VEHICLE");

  // Update a ROS message header
  this->batteryState.power_supply_status = supplyState;
  this->batteryState.header.stamp = ros::Time::now();
  
  this->batteryStatePublisher.publish(this->batteryState);
}

chargerGpioNode::~chargerGpioNode()
{
  try
  {
    // Remove the registered callback
    // HINT: I'm not sure we need to do that before pigpio_stop call. Just in case.
    if (event_callback_cancel(this->pinStateChangedCallbackHandle) < 0)
      ROS_ERROR("Failed to cancel pigpiod callback!");

    // Disconnect from the pigpiod service
    pigpio_stop(this->pigpiodHandle);
  }
  // Prevent exception to be thrown out of the destructor
  catch (...)
  {
  }
}
