#!/usr/bin/env python
# -*- coding: utf-8 -*

from dronepoint_driver_node import *

class ScenarioCommandTypes:
    """
    Types of commands in scenarios
    """
    SEND_UART = 0 # Send command to dronepoint and wait for states or timeout (default)
    SLEEP = 1 # Wait for some time
    GET_INFO = 2 # Request for something (DB or Mavlink, for example)

class PrecheckTypes:
    """
    Types of prechecks
    """
    UART_STATE = 0 # State which we receive from Arduino
    STORAGE_STATE = 1 # State which we store in cells_states file

class CellTypes:
    PAYLOAD = 0
    CHARGING = 1

# Test scenario for debugging on emulator
TestScenario = {
    'name': 'TEST',
    'prechecks': {
        PrecheckTypes.UART_STATE: {
            ArduinoDriverStateKey.PLATFORM_PAYLOAD: ArduinoPlatformPayloadDriverState.EMPTY,
            ArduinoDriverStateKey.TOP_HATCH: ArduinoTopHatchDriverState.CLOSED
        },
        PrecheckTypes.STORAGE_STATE: {
            'state': 'empty'
        }
    },
    'commands': [
        {
            'command': ArduinoCommand.OPEN_TOP_HATCH,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.TOP_HATCH: ArduinoTopHatchDriverState.OPEN
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
        {
            'command': ArduinoCommand.GOTO_CELL,
            'cell_type': CellTypes.CHARGING,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.PLATFORM: ArduinoPlatformDriverState.ON_CELL
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
        {
            'command': ArduinoCommand.GOTO_CELL,
            'cell_type': CellTypes.PAYLOAD,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.PLATFORM: ArduinoPlatformDriverState.ON_CELL
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
        {
            'command': ArduinoCommand.UNLOAD_PAYLOAD_CELL,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.PLATFORM: ArduinoPlatformDriverState.ON_CELL,
                ArduinoDriverStateKey.PLATFORM_PAYLOAD: ArduinoPlatformPayloadDriverState.LOADED
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
        {
            'command': ArduinoCommand.LOAD_PAYLOAD_CELL,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.PLATFORM: ArduinoPlatformDriverState.ON_CELL,
                ArduinoDriverStateKey.PLATFORM_PAYLOAD: ArduinoPlatformPayloadDriverState.EMPTY
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
        {
            'command': ArduinoCommand.CLOSE_TOP_HATCH,
            'timeout': 15,
            'pending_states': {
                ArduinoDriverStateKey.TOP_HATCH: ArduinoTopHatchDriverState.CLOSED
            },
            'type': ScenarioCommandTypes.SEND_UART
        },
    ]
}


# Test scenario for debugging on emulator
Test2S = {
    'name': 'TEST2S',
    'prechecks': {
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    },
    'commands': [
         {  'command': ArduinoCommand.GOTO_CELL,
            'timeout': 45,
            'cell_coordinates': {'x': 0, 'z': 5, 'y': 2},
            'pending_states': {
                ArduinoDriverStateKey.Z_AXIS_STATE: ArduinoZAxisState[5],
                ArduinoDriverStateKey.X_AXIS_STATE: ArduinoXAxisState[0],
                ArduinoDriverStateKey.Y_FLAG_STATE: ArduinoYFlagState[2],
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.GOTO_CELL,
            'timeout': 45,
            'cell_coordinates': {'x': 2, 'z': 5, 'y': 2},
            'pending_states': {
                ArduinoDriverStateKey.Z_AXIS_STATE: ArduinoZAxisState[5],
                ArduinoDriverStateKey.X_AXIS_STATE: ArduinoXAxisState[2],
                ArduinoDriverStateKey.Y_FLAG_STATE: ArduinoYFlagState[2],
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
       
        {  'command': ArduinoCommand.KR6,
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.KRPOS: ArduinoKRposDriverState.KR6
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.KR3,
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.KRPOS: ArduinoKRposDriverState.KR3
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.OV, 
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.POV: ArduinoOVposDriverState.OV
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.DN, 
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.PDN: ArduinoDNposDriverState.DN
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.KR3,
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.KRPOS: ArduinoKRposDriverState.KR3
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {   # Place battery to charge
            'command': ArduinoCommand.LOAD_CHARGING_CELL,
            'timeout': 30,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
        },
        { # Wait for several seconds
            'command': 'sleep',
            'timeout': 10,
            'type': ScenarioCommandTypes.SLEEP,
        },
        {  'command': ArduinoCommand.GOTO_CELL,
            'timeout': 45,
            'cell_coordinates': {'x': 1, 'z': 5, 'y': 3},
            'pending_states': {
                ArduinoDriverStateKey.Z_AXIS_STATE: ArduinoZAxisState[5],
                ArduinoDriverStateKey.X_AXIS_STATE: ArduinoXAxisState[1],
                ArduinoDriverStateKey.Y_FLAG_STATE: ArduinoYFlagState[3],
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {   # Placing payload to it's cell
            'command': ArduinoCommand.LOAD_PAYLOAD_CELL,
            'timeout': 30,
            'pending_states': {
                ArduinoDriverStateKey.Y_AXIS_STATE: ArduinoYAxisState[2], # Check if platform returned to the middle
                ArduinoDriverStateKey.PLATFORM_PAYLOAD: ArduinoPlatformPayloadDriverState.EMPTY,
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
         {   # Getting payload back from it's cell
            'command': ArduinoCommand.UNLOAD_PAYLOAD_CELL,
            'timeout': 30,
            'pending_states': {
                ArduinoDriverStateKey.Y_AXIS_STATE: ArduinoYAxisState[2], # Check if platform returned to the middle
                ArduinoDriverStateKey.PLATFORM_PAYLOAD: ArduinoPlatformPayloadDriverState.LOADED,
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {  'command': ArduinoCommand.KR3,
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.KRPOS: ArduinoKRposDriverState.KR3
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {   # Get battery 
            'command': ArduinoCommand.UNLOAD_CHARGING_CELL,
            'timeout': 30,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
        },
        { # Wait for several seconds
            'command': 'sleep',
             'timeout': 10,
             'type': ScenarioCommandTypes.SLEEP,
        },   

       {  'command': ArduinoCommand.DN, 
            'timeout': 45,
            'pending_states': {
             ArduinoDriverStateKey.PDN: ArduinoDNposDriverState.DN
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
        {   # Inserting container into drone
            'command': ArduinoCommand.INSERT_PAYLOAD_INTO_DRONE,
            'timeout': 80,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
        },  
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 20,
             'type': ScenarioCommandTypes.SLEEP,
         },
    ]
}


 


LoadDroneScenario = {
    'name': 'LOAD_DRONE', # vynet iz iacheyki snimet kryshku zagruzit v dron
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_LD, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PLD: ArduinoSTldDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
        },
    ]
}


UnloadDroneScenario = {
    'name': 'UNLOAD_DRONE', # snimet s drona vstavit krishku zagruzut v iacheyku
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_UD, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PUD: ArduinoSTudDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
     ]
}


UnloadToUserScenario = {
    'name': 'UNLOAD_TO_USER', # vynet iz iacheyki i vygruzit polzavatelu
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_UNTU, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PUNTU: ArduinoSTuntuDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
    ]
}

GetFromUserScenario = {
    'name': 'GET_FROM_USER', # primet u polzovatelai i vstavit v iacheyku
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
          { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_GETFU, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PGETFU: ArduinoSTgetfuDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
    ]
}

cmOopn = {
    'name': 'cmOopn', #OPEN vozmet u polsovatelia, snimet kryshku zagruzit v dron
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
          { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_OPEN, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PVOPN: ArduinoSTvOpenDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
    ]
}

cmOcls = {
    'name': 'cmOcls', #CLOSE snimet s drona vstavit krishku, vydast polsovatelu
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
          { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_CLOSE, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PVCLS: ArduinoSTvCloseDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
    ]
}

cmOchan = {
    'name': 'cmOchan', #CHANGING_BATTERY
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
          { # Wait for several seconds
            'command': 'sleep',
             'timeout': 1,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.CMO_CHAN, 
            'timeout': 160,
            'pending_states': {
             ArduinoDriverStateKey.PCHAN: ArduinoSTchanDriverState.COMPL
            },
            'type': ScenarioCommandTypes.SEND_UART,
         },
    ]
}


Test3S = {
    'name': 'Test3S', # Test3S
    'prechecks': { 
        PrecheckTypes.UART_STATE: {},
        PrecheckTypes.STORAGE_STATE: {}
    }, 
    'commands': [
         {  'command': ArduinoCommand.UNLOAD_TO_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.GET_FROM_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.UNLOAD_TO_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.GET_FROM_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.UNLOAD_TO_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
         {  'command': ArduinoCommand.GET_FROM_USER,
            'timeout': 45,
            'pending_states': {},
            'type': ScenarioCommandTypes.SEND_UART,
         },
         { # Wait for several seconds
            'command': 'sleep',
             'timeout': 152,
             'type': ScenarioCommandTypes.SLEEP,
         },
    ]
}

class CommandExitCodes:
    """
    Exit codes for command handlers
    """
    SUCCESS = 0
    TIMEOUT = 1
    ERROR = 2
    SHUTDOWN = 3