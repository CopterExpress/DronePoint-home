# coex_ros_cs/cs_meteo/cs_meteo_msgs
